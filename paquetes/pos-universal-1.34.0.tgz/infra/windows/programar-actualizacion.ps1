# Programa la actualizacion nocturna de una instalacion por paquetes (D-063, fase 3).
# Ejecutar como administrador:  powershell -ExecutionPolicy Bypass -File programar-actualizacion.ps1 [-Raiz C:\POS] [-Hora 03:00]
# La tarea corre "node iniciar.ts --actualizar": si no hay caja ni cuentas abiertas, instala la version nueva del canal
# (CANAL_ACTUALIZACION en datos\.env) y, si falla, regresa sola a la anterior. El boton "Buscar actualizacion" usa esta misma tarea.
param([string]$Raiz = 'C:\POS', [string]$Hora = '03:00')
$ErrorActionPreference = 'Stop'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Ejecute como administrador.' }
if (-not (Test-Path (Join-Path $Raiz 'iniciar.ts'))) { throw "$Raiz no es una instalacion por paquetes (falta iniciar.ts)." }
$node = (Get-Command node).Source
$accion = New-ScheduledTaskAction -Execute 'cmd.exe' -WorkingDirectory $Raiz `
  -Argument "/c `"`"$node`" iniciar.ts --actualizar >> datos\logs\actualizador-salida.log 2>&1`""
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest -LogonType ServiceAccount
$ajustes = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1)
Register-ScheduledTask -TaskName 'GOM POS TM - Actualizar' -Action $accion -Trigger (New-ScheduledTaskTrigger -Daily -At $Hora) `
  -Principal $principal -Settings $ajustes -Force | Out-Null
Write-Host "Listo: el POS buscara actualizaciones todos los dias a las $Hora."
