var o=Object.defineProperty;var r=(e,i)=>o(e,"name",{value:i,configurable:!0});const n=`
WITH active_modules AS (
  SELECT mo.key FROM modules mo
   WHERE (mo.is_core
          -- Algunos giros (caja de ahorro) solo usan parte del n\xFAcleo.
          AND NOT EXISTS (SELECT 1 FROM businesses b JOIN business_types bt ON bt.key = b.business_type
                           WHERE b.id = app.current_business() AND bt.core_modules IS NOT NULL AND NOT mo.key = ANY (bt.core_modules)))
      OR (EXISTS (SELECT 1 FROM business_modules bm WHERE bm.module_key = mo.key AND bm.enabled
                    AND bm.business_id = app.current_business())
          -- Si el plan del negocio lista m\xF3dulos, solo esos quedan disponibles.
          AND NOT EXISTS (SELECT 1 FROM subscriptions s JOIN plans p ON p.key = s.plan_key
                           WHERE p.modules IS NOT NULL AND NOT mo.key = ANY (p.modules)))
)
SELECT m.id AS membership_id, m.role_id, r.key AS role_key, r.rank, r.is_system, m.branch_ids,
       ARRAY(
         SELECT p.key FROM permissions p
          WHERE p.module_key IN (SELECT key FROM active_modules)
            AND (r.is_system
                 OR p.key = ANY (m.extra_permissions)
                 OR EXISTS (SELECT 1 FROM role_permissions rp WHERE rp.role_id = r.id AND rp.permission_key = p.key))
            AND (r.is_system OR NOT p.key = ANY (m.denied_permissions))
          ORDER BY p.key
       ) AS permissions,
       ARRAY(SELECT key FROM active_modules ORDER BY key) AS modules
  FROM memberships m
  JOIN roles r ON r.business_id = m.business_id AND r.id = m.role_id
  JOIN users u ON u.id = m.user_id
 WHERE m.user_id = $1 AND m.business_id = app.current_business()
   AND m.is_active AND u.is_active`;async function t(e,i){const s=(await e.query(n,[i])).rows[0];return s?{membershipId:s.membership_id,userId:i,roleId:s.role_id,roleKey:s.role_key,rank:s.rank,isOwner:s.is_system,branchIds:s.branch_ids,permissions:new Set(s.permissions),modules:new Set(s.modules)}:null}r(t,"loadAccess");const d=r((e,i)=>e.permissions.has(i),"can"),p=r((e,i)=>e.isOwner||e.rank<i,"outranks");export{d as can,t as loadAccess,p as outranks};
