var C=Object.defineProperty;var d=(t,e)=>C(t,"name",{value:e,configurable:!0});import{fromCents as S,toCents as E}from"@pos/shared";import{byBucket as L,dayRollups as v,sumFinancial as M,sumKpis as h,sumPairs as A,sumProducts as I,usesRollup as x}from"./rollup.ts";class p{static{d(this,"Sql")}values=[];add(e){return this.values.push(e),`$${this.values.length}`}}const j=["pagada","pendiente","parcial","cancelada","devuelta"],J=["efectivo","tarjeta","transferencia","mixto","otros","sin_pago"],F=d(t=>`tz AS (
    SELECT br.id AS branch_id, coalesce(br.timezone, b.timezone) AS zone
      FROM branches br JOIN businesses b ON b.id = br.business_id
     WHERE ${t}::uuid IS NULL OR br.id = ${t}::uuid
  )`,"tzCte");function _(t,e){const o=e.add(t.sucursal),s=e.add(t.desde),c=e.add(t.hasta),i=[];if(t.vendedor&&i.push(`s.seller_id = ${e.add(t.vendedor)}::uuid`),t.servicio&&i.push(`s.channel = ${e.add(t.servicio)}`),t.folio&&i.push(`s.folio = ${e.add(t.folio)}::bigint`),t.propias){const l=e.add(t.propias);i.push(`(s.seller_id = ${l}::uuid OR s.cashier_id = ${l}::uuid OR s.created_by = ${l}::uuid)`)}const r=d(l=>t.folio?`${s}::date IS NOT NULL AND ${c}::date IS NOT NULL`:`${l}.op_day BETWEEN ${s}::date AND ${c}::date`,"period"),a=[];t.estado&&a.push(`estado_op = ${e.add(t.estado)}`),t.metodo&&a.push(`metodo_op = ${e.add(t.metodo)}`);const n=[r("s"),...i].join(" AND ");return`${F(o)},
  raw AS MATERIALIZED (
    SELECT s.id, s.folio, s.status, s.channel, s.opened_at, s.closed_at, s.table_id, s.customer_id, s.seller_id, s.branch_id, s.delivery_info,
           s.subtotal, s.discount_total, s.tax_total, s.delivery_fee, s.total, s.paid_total, s.refunded_total, s.balance, s.tip_total, s.cost_total,
           s.op_day, coalesce(s.closed_at, s.opened_at) AT TIME ZONE tz.zone AS local_ts,
           CASE WHEN s.status IN ('cancelada','devuelta','pagada') THEN s.status
                WHEN s.paid_total > 0 AND s.balance > 0 THEN 'parcial'
                WHEN s.balance <= 0 AND s.total > 0 THEN 'pagada'
                ELSE 'pendiente' END AS estado_op,
           s.status IN ('pagada','credito','devuelta') AS efectiva
      FROM sales s JOIN tz ON tz.branch_id = s.branch_id
     WHERE ${n}
  ),
  pm AS MATERIALIZED (
    SELECT p.sale_id, count(DISTINCT p.method) AS n, min(p.method) AS m, sum(p.amount) AS cobrado
      FROM payments p WHERE p.sale_id IN (SELECT id FROM raw) AND p.voided_at IS NULL AND p.kind IN ('pago','abono','anticipo')
     GROUP BY 1
  ),
  v AS MATERIALIZED (
    SELECT * FROM (
      SELECT r.*, coalesce(pm.cobrado, 0) AS cobrado,
             CASE WHEN pm.n > 1 THEN 'mixto' WHEN pm.m IS NULL THEN 'sin_pago'
                  WHEN pm.m IN ('efectivo','tarjeta','transferencia') THEN pm.m ELSE 'otros' END AS metodo_op
        FROM raw r LEFT JOIN pm ON pm.sale_id = r.id
    ) y ${a.length?`WHERE ${a.join(" AND ")}`:""}
  ),
  ef AS (SELECT * FROM v WHERE efectiva),
  ref AS (
    SELECT f.id, f.total, f.op_day, s.branch_id
      FROM refunds f JOIN sales s ON s.id = f.sale_id JOIN tz ON tz.branch_id = s.branch_id
     WHERE ${[r("f"),...i].join(" AND ")}
  )`}d(_,"salesCte");const O=d((t,e="op_day",o="local_ts")=>({hora:`to_char(date_trunc('hour', ${o}), 'YYYY-MM-DD"T"HH24:00')`,dia:`to_char(${e}, 'YYYY-MM-DD')`,semana:`to_char(date_trunc('week', ${e})::date, 'YYYY-MM-DD')`,mes:`to_char(date_trunc('month', ${e})::date, 'YYYY-MM-DD')`,trimestre:`to_char(date_trunc('quarter', ${e})::date, 'YYYY-MM-DD')`,anio:`to_char(date_trunc('year', ${e})::date, 'YYYY-MM-DD')`})[t],"bucketExpr"),D=`SELECT count(*)::int AS operaciones, coalesce(sum(total),0)::text AS total, coalesce(sum(subtotal),0)::text AS bruto,
    coalesce(sum(discount_total),0)::text AS descuentos, coalesce(sum(total - tax_total),0)::text AS netas, coalesce(sum(tax_total),0)::text AS impuestos,
    coalesce(sum(cobrado),0)::text AS cobrado, coalesce(sum(greatest(balance, 0)),0)::text AS saldos, coalesce(sum(tip_total),0)::text AS propinas,
    coalesce(round(sum(cost_total), 2),0)::text AS costo FROM ef`,f=d(t=>({...t,ticketPromedio:t.operaciones?S(E(t.total)/BigInt(t.operaciones)):"0.00"}),"withTicket");async function y(t,e,o){const s=new p,c=_(e,s),r=(await t.query(`WITH ${c}
     SELECT (SELECT row_to_json(k) FROM (${D}) k) AS kpis,
            (SELECT coalesce(sum(total),0)::numeric(14,2)::text FROM ref) AS devoluciones,
            (SELECT coalesce(json_agg(x), '[]') FROM (SELECT estado_op AS estado, count(*)::int AS operaciones, sum(total)::text AS total FROM v GROUP BY 1) x) AS estados,
            (SELECT coalesce(json_agg(x ORDER BY clave), '[]') FROM (
               SELECT ${O(o)} AS clave, count(*)::int AS operaciones, sum(total)::text AS total, sum(total - tax_total)::text AS netas FROM ef GROUP BY 1) x) AS evolucion`,s.values)).rows[0];return{kpis:f({...r.kpis,devoluciones:r.devoluciones}),estados:r.estados,evolucion:r.evolucion}}d(y,"salesSummaryBase");async function $(t,e){const o=new p,s=_(e,o);return(await t.query(`WITH ${s},
     pr AS (
       SELECT i.variant_id, sum(i.qty) AS qty, sum(i.line_total - i.tax_amount) AS revenue, sum(i.unit_cost * i.qty) AS cost, sum(i.line_total) AS importe
         FROM sale_items i JOIN ef ON ef.id = i.sale_id WHERE i.status = 'activo' GROUP BY 1
     ),
     prn AS (
       SELECT pr.*, p.name AS producto, nullif(va.name, '\xDAnica') AS variante, coalesce(k.name, 'Sin categor\xEDa') AS categoria
         FROM pr JOIN product_variants va ON va.id = pr.variant_id JOIN products p ON p.id = va.product_id LEFT JOIN categories k ON k.id = p.category_id
     )
     SELECT
       (SELECT coalesce(json_agg(x ORDER BY total DESC), '[]') FROM (SELECT metodo_op AS metodo, count(*)::int AS operaciones, sum(cobrado)::text AS total, sum(cobrado) AS o FROM ef GROUP BY 1) x) AS metodos,
       (SELECT coalesce(json_agg(x ORDER BY hora), '[]') FROM (SELECT extract(hour FROM local_ts)::int AS hora, count(*)::int AS operaciones, sum(total)::text AS total FROM ef GROUP BY 1) x) AS horas,
       (SELECT coalesce(json_agg(x), '[]') FROM (SELECT channel AS servicio, count(*)::int AS operaciones, sum(total)::text AS total FROM ef GROUP BY 1 ORDER BY sum(total) DESC) x) AS servicios,
       (SELECT coalesce(json_agg(x), '[]') FROM (SELECT producto, variante, qty::text AS cantidad, importe::text AS importe, revenue::text AS ingreso FROM prn ORDER BY qty DESC, producto LIMIT 10) x) AS "masVendidos",
       (SELECT coalesce(json_agg(x), '[]') FROM (SELECT producto, variante, qty::text AS cantidad, importe::text AS importe, revenue::text AS ingreso FROM prn ORDER BY qty, producto LIMIT 10) x) AS "menosVendidos",
       (SELECT coalesce(json_agg(x), '[]') FROM (SELECT producto, variante, qty::text AS cantidad, importe::text AS importe, revenue::text AS ingreso FROM prn ORDER BY importe DESC, producto LIMIT 10) x) AS "mayorIngreso",
       (SELECT coalesce(json_agg(x), '[]') FROM (SELECT categoria, sum(qty)::text AS cantidad, sum(importe)::text AS importe, sum(revenue)::text AS ingreso, round(sum(revenue - cost), 2)::text AS utilidad FROM prn GROUP BY 1 ORDER BY sum(importe) DESC) x) AS categorias`,o.values)).rows[0]}d($,"salesBreakdownBase");const Y={folio:"v.folio",fecha:"v.local_ts",total:"v.total",saldo:"v.balance",cliente:"cliente",vendedor:"vendedor",estado:"v.estado_op",servicio:"v.channel",metodo:"v.metodo_op"},H={folio:"s.folio",fecha:"coalesce(s.closed_at, s.opened_at)",total:"s.total",saldo:"s.balance",servicio:"s.channel"};async function q(t,e,o){const s=H[o.orden];if(!e.estado&&!e.metodo&&s){const l=new p,m=l.add(e.sucursal),g=l.add(e.desde),N=l.add(e.hasta),u=[e.folio?`${g}::date IS NOT NULL AND ${N}::date IS NOT NULL`:`s.op_day BETWEEN ${g}::date AND ${N}::date`];if(e.vendedor&&u.push(`s.seller_id = ${l.add(e.vendedor)}::uuid`),e.servicio&&u.push(`s.channel = ${l.add(e.servicio)}`),e.folio&&u.push(`s.folio = ${l.add(e.folio)}::bigint`),e.propias){const T=l.add(e.propias);u.push(`(s.seller_id = ${T}::uuid OR s.cashier_id = ${T}::uuid OR s.created_by = ${T}::uuid)`)}u.push(`(${m}::uuid IS NULL OR s.branch_id = ${m}::uuid)`);const b=(await t.query(`SELECT count(*)::int AS n FROM sales s WHERE ${u.join(" AND ")}`,l.values)).rows[0].n;return{filas:(await t.query(`WITH pg AS (
         SELECT s.* FROM sales s WHERE ${u.join(" AND ")}
          ORDER BY ${s} ${o.dir==="asc"?"ASC":"DESC"} NULLS LAST, s.folio DESC
          LIMIT ${l.add(o.limite)} OFFSET ${l.add((o.pagina-1)*o.limite)}
       )
       SELECT s.id, s.folio, to_char(s.op_day, 'YYYY-MM-DD') AS "diaOperativo",
              to_char(coalesce(s.closed_at, s.opened_at) AT TIME ZONE coalesce(br.timezone, b.timezone), 'YYYY-MM-DD') AS fecha,
              to_char(coalesce(s.closed_at, s.opened_at) AT TIME ZONE coalesce(br.timezone, b.timezone), 'HH24:MI') AS hora,
              s.status AS "estadoVenta",
              CASE WHEN s.status IN ('cancelada','devuelta','pagada') THEN s.status WHEN s.paid_total > 0 AND s.balance > 0 THEN 'parcial'
                   WHEN s.balance <= 0 AND s.total > 0 THEN 'pagada' ELSE 'pendiente' END AS estado,
              s.channel AS servicio,
              CASE WHEN pm.n > 1 THEN 'mixto' WHEN pm.m IS NULL THEN 'sin_pago' WHEN pm.m IN ('efectivo','tarjeta','transferencia') THEN pm.m ELSE 'otros' END AS metodo,
              s.total, s.balance AS saldo, s.refunded_total AS devuelto,
              coalesce(cu.name, t.name, s.delivery_info->>'cliente', s.delivery_info->>'destinatario') AS cliente, us.full_name AS vendedor
         FROM pg s JOIN branches br ON br.id = s.branch_id JOIN businesses b ON b.id = br.business_id
         LEFT JOIN customers cu ON cu.id = s.customer_id LEFT JOIN dining_tables t ON t.id = s.table_id LEFT JOIN users us ON us.id = s.seller_id
         LEFT JOIN LATERAL (
           SELECT count(DISTINCT p.method) AS n, min(p.method) AS m FROM payments p
            WHERE p.sale_id = s.id AND p.voided_at IS NULL AND p.kind IN ('pago','abono','anticipo')) pm ON true
        ORDER BY ${s} ${o.dir==="asc"?"ASC":"DESC"} NULLS LAST, s.folio DESC`,l.values)).rows,total:b,pagina:o.pagina,limite:o.limite}}const c=new p,i=_(e,c),r=Y[o.orden]??"v.local_ts",a=await t.query(`WITH ${i}
     SELECT v.id, v.folio, to_char(v.op_day, 'YYYY-MM-DD') AS "diaOperativo", to_char(v.local_ts, 'YYYY-MM-DD') AS fecha, to_char(v.local_ts, 'HH24:MI') AS hora,
            v.status AS "estadoVenta", v.estado_op AS estado, v.channel AS servicio, v.metodo_op AS metodo, v.total, v.balance AS saldo, v.refunded_total AS devuelto,
            coalesce(cu.name, t.name, v.delivery_info->>'cliente', v.delivery_info->>'destinatario') AS cliente, us.full_name AS vendedor,
            count(*) OVER()::int AS "totalFilas"
       FROM v LEFT JOIN customers cu ON cu.id = v.customer_id LEFT JOIN dining_tables t ON t.id = v.table_id LEFT JOIN users us ON us.id = v.seller_id
      ORDER BY ${r} ${o.dir==="asc"?"ASC":"DESC"} NULLS LAST, v.folio DESC
      LIMIT ${c.add(o.limite)} OFFSET ${c.add((o.pagina-1)*o.limite)}`,c.values),n=a.rows[0]?.totalFilas??0;return{filas:a.rows.map(({totalFilas:l,...m})=>m),total:n,pagina:o.pagina,limite:o.limite}}d(q,"salesPage");const w=d(t=>t.replace(/[\\%_]/g,e=>`\\${e}`),"likeEscape");function R(t,e){const o=e.add(t.sucursal),s=e.add(t.desde),c=e.add(t.hasta),i="e.op_day",r=[`e.op_day BETWEEN ${s}::date AND ${c}::date`];return t.grupo&&r.push(`k.grp = ${e.add(t.grupo)}`),t.categoria&&r.push(`e.category_id = ${e.add(t.categoria)}::uuid`),t.metodo&&r.push(`e.method = ${e.add(t.metodo)}`),t.responsable&&r.push(`e.responsible_id = ${e.add(t.responsable)}::uuid`),t.montoMin&&r.push(`e.amount >= ${e.add(t.montoMin)}::numeric`),t.montoMax&&r.push(`e.amount <= ${e.add(t.montoMax)}::numeric`),t.concepto&&r.push(`e.description ILIKE ${e.add(`%${w(t.concepto)}%`)}`),`${F(o)},
  x AS MATERIALIZED (
    SELECT * FROM (
      SELECT e.id, e.folio, e.description, e.amount, e.method, e.status, e.is_paid, e.void_reason, e.category_id, e.responsible_id, e.scheduled_id, e.purchase_id,
             k.name AS categoria, k.grp AS grupo, k.in_cost_of_goods, u.full_name AS responsable, a.full_name AS autorizo, sch.name AS programado,
             ${i} AS op_day, e.paid_at AT TIME ZONE tz.zone AS local_ts,
             CASE WHEN e.status = 'anulado' THEN 'anulado' WHEN e.status = 'por_autorizar' THEN 'por_autorizar'
                  WHEN e.is_paid THEN 'pagado' ELSE 'pendiente' END AS estado_op,
             CASE WHEN sch.kind = 'nomina' OR k.grp = 'nomina' THEN 'nomina' WHEN sch.kind = 'fijo' THEN 'fijo' ELSE 'operativo' END AS tipo_op
        FROM expenses e JOIN tz ON tz.branch_id = e.branch_id JOIN expense_categories k ON k.id = e.category_id
        JOIN users u ON u.id = e.responsible_id LEFT JOIN users a ON a.id = e.authorized_by
        LEFT JOIN scheduled_expenses sch ON sch.id = e.scheduled_id
       WHERE ${r.join(" AND ")}
    ) y ${t.estado?`WHERE estado_op = ${e.add(t.estado)}`:""}
  ),
  ok AS (SELECT * FROM x WHERE status <> 'anulado')`}d(R,"expensesCte");async function G(t,e,o){const s=new p,c=R(e,s),r=(await t.query(`WITH ${c}
     SELECT (SELECT row_to_json(k) FROM (SELECT coalesce(sum(amount),0)::text AS total, count(*)::int AS numero,
               coalesce(sum(amount) FILTER (WHERE tipo_op = 'operativo'),0)::text AS operativos,
               coalesce(sum(amount) FILTER (WHERE tipo_op = 'nomina'),0)::text AS nomina,
               coalesce(sum(amount) FILTER (WHERE tipo_op = 'fijo'),0)::text AS fijos,
               coalesce(sum(amount) FILTER (WHERE estado_op <> 'pagado'),0)::text AS pendientes,
               coalesce(sum(amount) FILTER (WHERE estado_op = 'pagado'),0)::text AS pagados FROM ok) k) AS kpis,
            (SELECT row_to_json(m) FROM (SELECT categoria, sum(amount)::text AS total FROM ok GROUP BY 1 ORDER BY sum(amount) DESC, categoria LIMIT 1) m) AS mayor,
            (SELECT coalesce(json_agg(z ORDER BY clave), '[]') FROM (SELECT ${O(o)} AS clave, count(*)::int AS operaciones, sum(amount)::text AS total FROM ok GROUP BY 1) z) AS evolucion`,s.values)).rows[0];return{kpis:{...r.kpis,categoriaMayor:r.mayor},evolucion:r.evolucion}}d(G,"expensesSummary");async function K(t,e){const o=new p,s=R(e,o);return(await t.query(`WITH ${s}
     SELECT
       (SELECT coalesce(json_agg(z), '[]') FROM (SELECT categoria, grupo, count(*)::int AS cantidad, sum(amount)::text AS total FROM ok GROUP BY 1, 2 ORDER BY sum(amount) DESC) z) AS categorias,
       (SELECT coalesce(json_agg(z), '[]') FROM (SELECT tipo_op AS tipo, count(*)::int AS cantidad, sum(amount)::text AS total FROM ok GROUP BY 1 ORDER BY sum(amount) DESC) z) AS tipos,
       (SELECT coalesce(json_agg(z), '[]') FROM (SELECT method AS metodo, count(*)::int AS cantidad, sum(amount)::text AS total FROM ok GROUP BY 1 ORDER BY sum(amount) DESC) z) AS metodos,
       (SELECT coalesce(json_agg(z), '[]') FROM (SELECT coalesce(programado, description) AS concepto, count(*)::int AS cantidad, sum(amount)::text AS total FROM ok GROUP BY 1 ORDER BY sum(amount) DESC LIMIT 10) z) AS conceptos`,o.values)).rows[0]}d(K,"expensesBreakdown");const k={fecha:"x.local_ts",folio:"x.folio",monto:"x.amount",concepto:"x.description",categoria:"x.categoria",estado:"x.estado_op"};async function V(t,e,o){const s=new p,c=R(e,s),i=O(o.agrupar==="hora"?"dia":o.agrupar,"x.op_day","x.local_ts"),r=k[o.orden]??"x.local_ts",a=await t.query(`WITH ${c}
     SELECT x.id, x.folio, ${i} AS grupo, to_char(x.op_day, 'YYYY-MM-DD') AS "diaOperativo", to_char(x.local_ts, 'YYYY-MM-DD') AS fecha, to_char(x.local_ts, 'HH24:MI') AS hora,
            x.description AS concepto, x.grupo AS categoria, x.categoria AS subcategoria, x.method AS metodo, x.amount AS monto, x.responsable, x.estado_op AS estado,
            x.autorizo AS "autorizadoPor", x.void_reason AS "motivoAnulacion", x.tipo_op AS tipo, x.scheduled_id AS "programadoId", x.purchase_id AS "compraId",
            count(*) OVER()::int AS "totalFilas"
       FROM x
      ORDER BY ${i} DESC, ${r} ${o.dir==="asc"?"ASC":"DESC"}, x.folio DESC
      LIMIT ${s.add(o.limite)} OFFSET ${s.add((o.pagina-1)*o.limite)}`,s.values),n=new p,l=R(e,n),m=await t.query(`WITH ${l}
     SELECT ${i} AS grupo, count(*) FILTER (WHERE x.status <> 'anulado')::int AS cantidad, coalesce(sum(x.amount) FILTER (WHERE x.status <> 'anulado'), 0) AS total
       FROM x GROUP BY 1 ORDER BY 1 DESC`,n.values),g=a.rows[0]?.totalFilas??0;return{filas:a.rows.map(({totalFilas:N,...u})=>u),grupos:m.rows,total:g,pagina:o.pagina,limite:o.limite,agrupar:o.agrupar==="hora"?"dia":o.agrupar}}d(V,"expensesPage");async function B(t,e,o){const s=new p,c=_(e,s),i=s.add(e.desde),r=s.add(e.hasta),a=d(l=>O(o==="hora"?"dia":o,l),"b");return(await t.query(`WITH ${c},
     ref_d AS (
       SELECT r.op_day, r.total,
              coalesce(sum(round(ri.amount * (si.line_total - si.tax_amount) / nullif(si.line_total, 0), 2)), 0) AS net,
              coalesce(sum(CASE WHEN ri.restock AND va.stock_item_id IS NOT NULL THEN round(ri.qty * si.unit_cost, 4) ELSE 0 END), 0) AS cost
         FROM ref r JOIN refund_items ri ON ri.refund_id = r.id JOIN sale_items si ON si.id = ri.sale_item_id
         JOIN product_variants va ON va.id = si.variant_id
        GROUP BY r.id, r.op_day, r.total
     ),
     gx AS (
       SELECT e.op_day, e.amount, k.grp, k.in_cost_of_goods
         FROM expenses e JOIN tz ON tz.branch_id = e.branch_id JOIN expense_categories k ON k.id = e.category_id
        WHERE e.status <> 'anulado' AND e.op_day BETWEEN ${i}::date AND ${r}::date
     ),
     todo AS (
       SELECT ${a("op_day")} AS periodo, 1 AS operaciones, total, cobrado, (total - tax_total) AS netas, 0::numeric AS devoluciones, cost_total AS costo, 0::numeric AS compras, 0::numeric AS gastos, 0::numeric AS egresos FROM ef
       UNION ALL
       SELECT ${a("op_day")}, 0, 0, 0, 0, net, -cost, 0, 0, 0 FROM ref_d
       UNION ALL
       SELECT ${a("op_day")}, 0, 0, 0, 0, 0, 0,
              CASE WHEN grp = 'compras' AND NOT in_cost_of_goods THEN amount ELSE 0 END,
              CASE WHEN grp <> 'compras' AND NOT in_cost_of_goods THEN amount ELSE 0 END,
              amount
         FROM gx WHERE op_day BETWEEN ${i}::date AND ${r}::date
     )
     SELECT periodo, sum(operaciones)::int AS operaciones, sum(total)::numeric(14,2)::text AS total, sum(cobrado)::numeric(14,2)::text AS cobrado,
            sum(netas)::numeric(14,2)::text AS netas, sum(devoluciones)::numeric(14,2)::text AS devoluciones, round(sum(costo), 2)::text AS costo,
            sum(compras)::numeric(14,2)::text AS compras, sum(gastos)::numeric(14,2)::text AS gastos, sum(egresos)::numeric(14,2)::text AS egresos
       FROM todo GROUP BY 1 ORDER BY 1`,s.values)).rows}d(B,"financialRowsBase");function Z(t,e){const o=E(String(t)),s=E(String(e)),c=o-s,i=s===0n?null:(Number(c*10000n/(s<0n?-s:s))/100).toFixed(2);return{actual:S(o),anterior:S(s),diferencia:S(c),variacionPct:i,tendencia:c>0n?"sube":c<0n?"baja":"igual"}}d(Z,"variation");const X=d(t=>S(E(t.netas)-E(t.devoluciones)-E(t.costo)-E(t.compras)-E(t.gastos)),"utilidadEstimada");async function Q(t,e,o){if(o==="hora"||!x(e))return y(t,e,o);const s=await v(t,e);return{kpis:h(s),estados:A(s,"est").map(i=>({estado:i.k,operaciones:i.n,total:i.t})),evolucion:L(s,o).map(([i,r])=>{const a=h(r);return{clave:i,operaciones:a.operaciones,total:a.total,netas:a.netas}}).filter(i=>i.operaciones!==0)}}d(Q,"salesSummary");async function tt(t,e){if(!x(e))return $(t,e);const o=await v(t,e),s=await I(t,o),c=d(a=>({producto:a.producto,variante:a.variante==="\xDAnica"?null:a.variante,cantidad:a.qty.toFixed(3),importe:a.importe.toFixed(2),ingreso:a.revenue.toFixed(2)}),"row"),i=d((a,n)=>a.producto.localeCompare(n.producto),"byName"),r=new Map;for(const a of s){const n=r.get(a.categoria)??{cantidad:0,importe:0,ingreso:0,costo:0};n.cantidad+=a.qty,n.importe+=a.importe,n.ingreso+=a.revenue,n.costo+=a.cost,r.set(a.categoria,n)}return{metodos:A(o,"met").map(a=>({metodo:a.k,operaciones:a.n,total:a.t})),horas:A(o,"hr").map(a=>({hora:Number(a.k),operaciones:a.n,total:a.t})).sort((a,n)=>a.hora-n.hora),servicios:A(o,"srv").map(a=>({servicio:a.k,operaciones:a.n,total:a.t})),masVendidos:[...s].sort((a,n)=>n.qty-a.qty||i(a,n)).slice(0,10).map(c),menosVendidos:[...s].sort((a,n)=>a.qty-n.qty||i(a,n)).slice(0,10).map(c),mayorIngreso:[...s].sort((a,n)=>n.importe-a.importe||i(a,n)).slice(0,10).map(c),categorias:[...r].sort((a,n)=>n[1].importe-a[1].importe).map(([a,n])=>({categoria:a,cantidad:n.cantidad.toFixed(3),importe:n.importe.toFixed(2),ingreso:n.ingreso.toFixed(2),utilidad:(n.ingreso-n.costo).toFixed(2)}))}}d(tt,"salesBreakdown");async function et(t,e,o){if(!x(e))return B(t,e,o);const s=await v(t,e);return L(s,o==="hora"?"dia":o).map(([c,i])=>({periodo:c,...M(i)}))}d(et,"financialRows");export{J as SALE_METHODS,j as SALE_STATES,p as Sql,O as bucketExpr,K as expensesBreakdown,R as expensesCte,V as expensesPage,G as expensesSummary,et as financialRows,tt as salesBreakdown,_ as salesCte,q as salesPage,Q as salesSummary,X as utilidadEstimada,Z as variation};
