var m=Object.defineProperty;var s=(e,n)=>m(e,"name",{value:n,configurable:!0});async function S(e,n){const i=await e.query(`WITH ex AS (SELECT stock_item_id, sum(qty) AS q FROM stock_levels WHERE branch_id = $1 GROUP BY 1),
          camino AS (SELECT pi.stock_item_id, sum(pi.qty_ordered - pi.qty_received) AS q
                       FROM purchase_items pi JOIN purchases p ON p.id = pi.purchase_id
                      WHERE p.branch_id = $1 AND p.status IN ('pedido', 'recibida_parcial') GROUP BY 1),
          base AS (
            SELECT i.*, coalesce(ex.q, 0) AS existencia, coalesce(camino.q, 0) AS en_camino,
                   p.id AS pres_id, p.name AS pres_name, p.content, p.price, p.supplier_id AS pres_supplier,
                   (CASE WHEN i.max_stock > 0 THEN i.max_stock ELSE 2 * i.min_stock END) - coalesce(ex.q, 0) - coalesce(camino.q, 0) AS falta
              FROM stock_items i
              LEFT JOIN ex ON ex.stock_item_id = i.id LEFT JOIN camino ON camino.stock_item_id = i.id
              -- La principal; si no hay, la activa con precio m\xE1s barata por unidad (igual que el costo de recetas, D-061).
              LEFT JOIN LATERAL (SELECT * FROM supplier_presentations sp WHERE sp.stock_item_id = i.id AND sp.is_active
                                  ORDER BY sp.is_default DESC, sp.price IS NULL, sp.price / sp.content LIMIT 1) p ON true
             WHERE i.is_active AND i.min_stock > 0 AND coalesce(ex.q, 0) + coalesce(camino.q, 0) <= i.min_stock)
     SELECT b.id AS "insumoId", b.name AS insumo, b.brand AS marca, b.unit_code AS unidad,
            b.existencia, b.en_camino AS "enCamino", b.min_stock AS minimo, b.max_stock AS maximo,
            b.pres_id AS "presentacionId", b.pres_name AS presentacion, b.content AS contenido,
            (ceil(b.falta / b.content))::int AS presentaciones,
            coalesce(ceil(b.falta / b.content) * b.content, b.falta) AS cantidad,
            coalesce(round(b.price / b.content, 4), b.avg_cost) AS "costoUnitario",
            round(coalesce(ceil(b.falta / b.content) * b.content, b.falta) * coalesce(round(b.price / b.content, 4), b.avg_cost), 2) AS importe,
            s.id AS "proveedorId", s.name AS proveedor, s.phone AS telefono, coalesce(s.delivery_days, '{}') AS "diasEntrega", coalesce(s.min_order, 0) AS "pedidoMinimo"
       FROM base b LEFT JOIN suppliers s ON s.id = coalesce(b.supplier_id, b.pres_supplier)
      ORDER BY s.name NULLS LAST, b.name`,[n]),o=new Map;for(const{proveedorId:t,proveedor:r,telefono:a,diasEntrega:p,pedidoMinimo:l,...u}of i.rows){const c=t??"";o.has(c)||o.set(c,{proveedorId:t,proveedor:r,telefono:a,diasEntrega:p,pedidoMinimo:l,partidas:[],total:"0"}),o.get(c).partidas.push(u)}for(const t of o.values())t.total=(t.partidas.reduce((r,a)=>r+Math.round(Number(a.importe)*100),0)/100).toFixed(2);return[...o.values()]}s(S,"sugerirRequisicion");const d=s(e=>Number(e).toLocaleString("es-MX",{maximumFractionDigits:3}),"cant");function b(e){const n=[`Hola${e.proveedor?` ${e.proveedor}`:""}, le escribe *${e.negocio}*.`,`Le hago el siguiente pedido (folio ${e.folio}):`,""];for(const i of e.partidas){const o=i.contenido?Number(i.cantidad)/Number(i.contenido):NaN,t=Number.isInteger(o)&&i.presentacion?`${o} \xD7 ${i.presentacion} de ${d(i.contenido)} ${i.unidad}`:`${d(i.cantidad)} ${i.unidad}`;n.push(`\u2022 ${t} \u2014 ${i.insumo}${i.marca?` (${i.marca})`:""}`)}return e.notas.trim()&&n.push("",e.notas.trim()),n.push("","\xA1Gracias!"),n.join(`
`)}s(b,"mensajeRequisicion");export{b as mensajeRequisicion,S as sugerirRequisicion};
