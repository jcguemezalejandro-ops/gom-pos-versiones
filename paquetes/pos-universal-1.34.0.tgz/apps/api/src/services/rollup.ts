var R=Object.defineProperty;var d=(o,e)=>R(o,"name",{value:e,configurable:!0});import{withTenant as A}from"../db/tenant.ts";import{fromCents as c,toCents as N}from"@pos/shared";import{salesCte as w,Sql as T}from"./metrics.ts";import{addDays as g}from"./periods.ts";const U=d(o=>!o.vendedor&&!o.estado&&!o.metodo&&!o.servicio&&!o.folio&&!o.propias,"usesRollup");function k(o,e){const t=w(o,e),a=e.add(o.desde),r=e.add(o.hasta),n=d((i,u,p,m="")=>`SELECT branch_id, op_day, json_object_agg(g, json_build_array(n, t)) AS j FROM (
       SELECT branch_id, op_day, ${u} AS g, count(*) AS n, sum(${p}) AS t FROM ${i} ${m} GROUP BY 1, 2, 3) x GROUP BY 1, 2`,"pairs");return`WITH ${t},
  kk AS (
    SELECT branch_id, op_day, json_build_object(
      'n', count(*), 'total', sum(total), 'bruto', sum(subtotal), 'desc', sum(discount_total), 'netas', sum(total - tax_total), 'imp', sum(tax_total),
      'cobrado', sum(cobrado), 'saldos', sum(greatest(balance, 0)), 'prop', sum(tip_total), 'costo', round(sum(cost_total), 4),
      'grav', coalesce(sum(total - tax_total) FILTER (WHERE tax_total > 0), 0), 'siniva', coalesce(sum(total) FILTER (WHERE tax_total = 0), 0)) AS j
      FROM ef GROUP BY 1, 2
  ),
  est AS (${n("v","estado_op","total")}),
  met AS (${n("ef","metodo_op","cobrado")}),
  hr AS (${n("ef","extract(hour FROM local_ts)::int","total")}),
  srv AS (${n("ef","channel","total")}),
  prod AS (
    SELECT branch_id, op_day, json_object_agg(variant_id, json_build_array(q, r, c, t)) AS j FROM (
      SELECT ef.branch_id, ef.op_day, i.variant_id, sum(i.qty) AS q, sum(i.line_total - i.tax_amount) AS r, sum(i.unit_cost * i.qty) AS c, sum(i.line_total) AS t
        FROM sale_items i JOIN ef ON ef.id = i.sale_id WHERE i.status = 'activo' GROUP BY 1, 2, 3) x GROUP BY 1, 2
  ),
  rd AS (
    SELECT r.branch_id, r.op_day, sum(r.total) AS total, sum(rn.net) AS net, sum(rn.cost) AS cost, sum(rn.iva) AS iva
      FROM ref r LEFT JOIN LATERAL (
        SELECT coalesce(sum(round(ri.amount * (si.line_total - si.tax_amount) / nullif(si.line_total, 0), 2)), 0) AS net,
               coalesce(sum(CASE WHEN ri.restock AND va.stock_item_id IS NOT NULL THEN round(ri.qty * si.unit_cost, 4) ELSE 0 END), 0) AS cost,
               coalesce(sum(ri.amount - round(ri.amount * (si.line_total - si.tax_amount) / nullif(si.line_total, 0), 2)), 0) AS iva
          FROM refund_items ri JOIN sale_items si ON si.id = ri.sale_item_id JOIN product_variants va ON va.id = si.variant_id
         WHERE ri.refund_id = r.id) rn ON true
     GROUP BY 1, 2
  ),
  gx AS (
    SELECT e.branch_id, e.op_day,
           sum(CASE WHEN k.grp = 'compras' AND NOT k.in_cost_of_goods THEN e.amount ELSE 0 END) AS compras,
           sum(CASE WHEN k.grp <> 'compras' AND NOT k.in_cost_of_goods THEN e.amount ELSE 0 END) AS gastos,
           sum(e.amount) AS egresos
      FROM expenses e JOIN tz ON tz.branch_id = e.branch_id JOIN expense_categories k ON k.id = e.category_id
     WHERE e.status <> 'anulado' AND e.op_day BETWEEN ${a}::date AND ${r}::date
     GROUP BY 1, 2
  ),
  keys AS (SELECT branch_id, op_day FROM v UNION SELECT branch_id, op_day FROM rd UNION SELECT branch_id, op_day FROM gx)
  SELECT keys.branch_id, to_char(keys.op_day, 'YYYY-MM-DD') AS op_day, json_strip_nulls(json_build_object(
           'k', kk.j, 'est', est.j, 'met', met.j, 'hr', hr.j, 'srv', srv.j, 'prod', prod.j,
           'dev', CASE WHEN rd.op_day IS NOT NULL THEN json_build_object('total', rd.total, 'net', rd.net, 'cost', rd.cost, 'iva', rd.iva) END,
           'gx', CASE WHEN gx.op_day IS NOT NULL THEN json_build_object('compras', gx.compras, 'gastos', gx.gastos, 'egresos', gx.egresos) END)) AS data
    FROM keys
    LEFT JOIN kk USING (branch_id, op_day) LEFT JOIN est USING (branch_id, op_day) LEFT JOIN met USING (branch_id, op_day)
    LEFT JOIN hr USING (branch_id, op_day) LEFT JOIN srv USING (branch_id, op_day) LEFT JOIN prod USING (branch_id, op_day)
    LEFT JOIN rd USING (branch_id, op_day) LEFT JOIN gx USING (branch_id, op_day)`}d(k,"rollupSql");async function f(o,e){const t=new T;return(await o.query(k(e,t),t.values)).rows}d(f,"compute");const O=d(()=>new Date().toISOString().slice(0,10),"utcToday");async function I(o,e,t){const a=[],r=[...new Set(t.map(i=>i[1]))].sort(),n=new Set(t.map(([i,u])=>`${i}|${u}`));for(let i=0;i<r.length;){const u=r[i],p=g(u,30);let m=i;for(;m+1<r.length&&r[m+1]<=p;)m++;const b=r[m],_=await f(o,{...e,sucursal:e.sucursal,desde:u,hasta:b}),y=new Map(_.map(s=>[`${s.branch_id}|${s.op_day}`,s])),E=t.filter(([,s])=>s>=u&&s<=b).map(([s,S])=>y.get(`${s}|${S}`)??{branch_id:s,op_day:S,data:{}});E.length&&await o.query(`INSERT INTO op_day_rollup (business_id, branch_id, op_day, data)
         SELECT app.current_business(), b, d, x FROM unnest($1::uuid[], $2::date[], $3::jsonb[]) AS u(b, d, x)
         ON CONFLICT (business_id, branch_id, op_day) DO UPDATE SET data = EXCLUDED.data, computed_at = now()`,[E.map(s=>s.branch_id),E.map(s=>s.op_day),E.map(s=>JSON.stringify(s.data))]),a.push(...E.filter(s=>n.has(`${s.branch_id}|${s.op_day}`))),i=m+1}return a}d(I,"fillMissing");async function q(o,e,t=400){const a=(await o.query("SELECT app.all_business_ids() AS id")).rows.map(n=>n.id),r=g(O(),-5);for(const n of a)for(let i=g(r,-t);i<=r;i=g(i,31)){const u=g(i,30)<r?g(i,30):r;try{await A(o,{businessId:n,userId:null},async p=>{await p.query("SET LOCAL statement_timeout = '120s'"),await L(p,{desde:i,hasta:u,corte:"00:00",sucursal:null})})}catch(p){e(`Res\xFAmenes de ${n} (${i}): ${p.message}`)}}}d(q,"warmRollups");async function L(o,e){const t=g(O(),-4),a=[],r=e.hasta<t?e.hasta:g(t,-1);if(e.desde<=r){const n=(await o.query("SELECT id FROM branches WHERE $1::uuid IS NULL OR id = $1",[e.sucursal])).rows.map(_=>_.id),i=d(_=>Object.values(_.data.prod??{}).every(y=>y.length>=4),"current"),u=d(async()=>(await o.query(`SELECT branch_id, to_char(op_day, 'YYYY-MM-DD') AS op_day, data FROM op_day_rollup
        WHERE op_day BETWEEN $1 AND $2 AND ($3::uuid IS NULL OR branch_id = $3)`,[e.desde,r,e.sucursal])).rows.filter(i),"read"),p=d(_=>{const y=new Set(_.map(s=>`${s.branch_id}|${s.op_day}`)),E=[];for(let s=e.desde;s<=r;s=g(s,1))for(const S of n)y.has(`${S}|${s}`)||E.push([S,s]);return E},"missingOf");let m=await u(),b=p(m);if(b.length){for(let _=0;!(await o.query("SELECT pg_try_advisory_xact_lock(hashtext('rollup:' || app.current_business()::text)) AS ok")).rows[0].ok;_++){if(_>=240)throw new Error("Los res\xFAmenes del periodo se est\xE1n preparando. Intente de nuevo en un momento.");await o.query("SELECT pg_sleep(0.5)")}m=await u(),b=p(m),m.push(...await I(o,e,b))}for(const _ of m)Object.keys(_.data).length&&a.push(_)}return e.hasta>=t&&a.push(...await f(o,{...e,desde:e.desde>t?e.desde:t})),a}d(L,"dayRollups");const D=d(o=>c(BigInt(Math.round(o*100))),"money"),l=d(o=>BigInt(Math.round((o??0)*100)),"cents"),F=d((o,e)=>{for(const[t,[a,r]]of Object.entries(e??{})){const n=o.get(t)??[0,0];o.set(t,[n[0]+a,n[1]+r])}},"add");function x(o,e){if(e==="dia"||e==="hora")return o;const[t,a]=o.split("-").map(Number);if(e==="semana"){const r=new Date(`${o}T12:00:00Z`).getUTCDay();return g(o,-((r+6)%7))}return e==="mes"?`${o.slice(0,7)}-01`:e==="trimestre"?`${t}-${String(Math.floor((a-1)/3)*3+1).padStart(2,"0")}-01`:`${t}-01-01`}d(x,"bucketOf");const h=d(o=>BigInt(Math.round((o??0)*1e4)),"c4"),v=d(o=>c(o>=0n?(o+50n)/100n:-((-o+50n)/100n)),"round4");function H(o){let e=0;const t={total:0n,bruto:0n,desc:0n,netas:0n,imp:0n,cobrado:0n,saldos:0n,prop:0n,costo:0n,dev:0n};for(const{data:a}of o)a.k&&(e+=a.k.n,t.total+=l(a.k.total),t.bruto+=l(a.k.bruto),t.desc+=l(a.k.desc),t.netas+=l(a.k.netas),t.imp+=l(a.k.imp),t.cobrado+=l(a.k.cobrado),t.saldos+=l(a.k.saldos),t.prop+=l(a.k.prop),t.costo+=h(a.k.costo)),t.dev+=l(a.dev?.total);return{operaciones:e,total:c(t.total),bruto:c(t.bruto),descuentos:c(t.desc),netas:c(t.netas),impuestos:c(t.imp),cobrado:c(t.cobrado),saldos:c(t.saldos),propinas:c(t.prop),costo:v(t.costo),devoluciones:c(t.dev),ticketPromedio:e?c(t.total/BigInt(e)):"0.00"}}d(H,"sumKpis");function J(o,e){const t=new Map;for(const a of o)F(t,a.data[e]);return[...t].map(([a,[r,n]])=>({k:a,n:r,t:D(n)})).sort((a,r)=>N(r.t)>N(a.t)?1:N(r.t)<N(a.t)?-1:0)}d(J,"sumPairs");function W(o,e){const t=new Map;for(const a of o){const r=x(a.op_day,e),n=t.get(r);n?n.push(a):t.set(r,[a])}return[...t].sort((a,r)=>a[0]<r[0]?-1:1)}d(W,"byBucket");async function Y(o,e){const t=new Map;for(const r of e)for(const[n,[i,u,p,m]]of Object.entries(r.data.prod??{})){const b=t.get(n)??[0,0,0,0];t.set(n,[b[0]+i,b[1]+u,b[2]+p,b[3]+(m??0)])}return t.size?(await o.query(`SELECT va.id, p.id AS producto_id, p.name AS producto, va.name AS variante, p.category_id AS categoria_id, coalesce(k.name, 'Sin categor\xEDa') AS categoria
       FROM product_variants va JOIN products p ON p.id = va.product_id LEFT JOIN categories k ON k.id = p.category_id
      WHERE va.id = ANY($1::uuid[])`,[[...t.keys()]])).rows.map(r=>{const[n,i,u,p]=t.get(r.id);return{variantId:r.id,productoId:r.producto_id,producto:r.producto,variante:r.variante,categoriaId:r.categoria_id,categoria:r.categoria,qty:Number(n.toFixed(3)),revenue:Number(i.toFixed(2)),importe:Number(p.toFixed(2)),cost:Number(u.toFixed(6))}}):[]}d(Y,"sumProducts");function G(o){let e=0;const t={total:0n,cobrado:0n,netas:0n,dev:0n,costo4:0n,compras:0n,gastos:0n,egresos:0n};for(const{data:a}of o)a.k&&(e+=a.k.n,t.total+=l(a.k.total),t.cobrado+=l(a.k.cobrado),t.netas+=l(a.k.netas),t.costo4+=h(a.k.costo)),a.dev&&(t.dev+=l(a.dev.net),t.costo4-=h(a.dev.cost)),a.gx&&(t.compras+=l(a.gx.compras),t.gastos+=l(a.gx.gastos),t.egresos+=l(a.gx.egresos));return{operaciones:e,total:c(t.total),cobrado:c(t.cobrado),netas:c(t.netas),devoluciones:c(t.dev),costo:v(t.costo4),compras:c(t.compras),gastos:c(t.gastos),egresos:c(t.egresos)}}d(G,"sumFinancial");export{x as bucketOf,W as byBucket,L as dayRollups,G as sumFinancial,H as sumKpis,J as sumPairs,Y as sumProducts,U as usesRollup,q as warmRollups};
