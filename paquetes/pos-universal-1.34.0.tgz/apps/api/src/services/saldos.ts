var r=Object.defineProperty;var o=(e,a)=>r(e,"name",{value:a,configurable:!0});import{fromCents as i,toCents as c}from"@pos/shared";const m=["caja","efectivo","banco","otro"],p={caja:"Caja (efectivo en cajas)",efectivo:"Efectivo fuera de caja",banco:"Banco",otro:"Otros"},N={saldo_inicial:"Saldo inicial",cobros:"Cobros",reembolsos:"Reembolsos",egresos:"Egresos pagados",retiros:"Retiros de caja",entradas_caja:"Entradas de caja",salidas_caja:"Salidas de caja",gastos_caja:"Gastos de caja (versi\xF3n anterior)",diferencias_corte:"Diferencias de corte",aportacion:"Aportaciones del due\xF1o",retiro_dueno:"Retiros del due\xF1o",traspaso:"Traspasos entre cuentas",ajuste:"Ajustes",reversion:"Reversiones"};async function u(e){return(await e.query("SELECT to_char(start_day, 'YYYY-MM-DD') AS d FROM accounting_start")).rows[0]?.d??null}o(u,"startDay");async function _(e){return(await e.query(`SELECT id, name AS nombre, kind AS tipo, is_primary AS principal, is_active AS activa
       FROM money_accounts ORDER BY is_primary DESC, array_position(ARRAY['caja','efectivo','banco','otro'], kind), sort_order, name`)).rows}o(_,"listAccounts");async function A(e,a,t){return(await e.query(`WITH pa AS (SELECT kind, id FROM money_accounts WHERE is_primary),
     sess AS (SELECT id, branch_id FROM cash_sessions),
     f AS (
       SELECT CASE p.method WHEN 'efectivo' THEN 'caja' WHEN 'tarjeta' THEN 'banco' WHEN 'transferencia' THEN 'banco' ELSE 'otro' END AS k,
              p.op_day AS d, CASE WHEN p.kind = 'reembolso' THEN 'reembolsos' ELSE 'cobros' END AS concepto, p.amount AS amount
         FROM payments p
        WHERE p.voided_at IS NULL AND p.kind <> 'propina' AND p.method <> 'saldo_cliente' AND p.op_day BETWEEN $1 AND $2
       UNION ALL
       SELECT 'caja', x.d, CASE x.kind WHEN 'entrada' THEN 'entradas_caja' WHEN 'reintegro' THEN 'entradas_caja' WHEN 'retiro' THEN 'retiros'
                                       WHEN 'gasto' THEN 'gastos_caja' ELSE 'salidas_caja' END,
              CASE WHEN x.kind IN ('entrada','reintegro') THEN x.amount ELSE -x.amount END
         FROM (SELECT m.kind, m.amount, app.op_day(s.branch_id, m.created_at) AS d FROM cash_movements m JOIN sess s ON s.id = m.cash_session_id
                WHERE m.status IN ('registrado','por_autorizar') AND m.created_at >= $1::date - 3) x
        WHERE x.d BETWEEN $1 AND $2
       UNION ALL
       SELECT 'efectivo', x.d, 'retiros', x.amount
         FROM (SELECT m.amount, app.op_day(s.branch_id, m.created_at) AS d FROM cash_movements m JOIN sess s ON s.id = m.cash_session_id
                WHERE m.kind = 'retiro' AND m.status IN ('registrado','por_autorizar') AND m.created_at >= $1::date - 3) x
        WHERE x.d BETWEEN $1 AND $2
       UNION ALL
       SELECT 'caja', x.d, 'diferencias_corte', x.difference
         FROM (SELECT app.op_day(s.branch_id, s.closed_at) AS d, k.difference
                 FROM cash_sessions s
                 JOIN LATERAL (SELECT difference FROM cash_counts z WHERE z.cash_session_id = s.id AND z.kind = 'final' ORDER BY z.counted_at DESC LIMIT 1) k ON true
                WHERE s.status = 'cerrada' AND s.closed_at >= $1::date - 3 AND k.difference <> 0) x
        WHERE x.d BETWEEN $1 AND $2
       UNION ALL
       SELECT CASE x.method WHEN 'efectivo' THEN 'efectivo' WHEN 'otro' THEN 'otro' ELSE 'banco' END, x.d, 'egresos', -x.amount
         FROM (SELECT e.method, e.amount,
                      -- Pagado al registrarse: cuenta el d\xEDa del egreso. Marcado como pagado despu\xE9s: el d\xEDa en que se pag\xF3.
                      CASE WHEN e.settled_at > e.created_at THEN app.op_day(e.branch_id, e.settled_at) ELSE e.op_day END AS d
                 FROM expenses e WHERE e.status <> 'anulado' AND e.is_paid AND coalesce(e.settled_at, e.paid_at) >= $1::date - 3) x
        WHERE x.d BETWEEN $1 AND $2
     ),
     auto AS (
       SELECT pa.id AS account_id, f.d, f.concepto, sum(f.amount) AS amount FROM f JOIN pa ON pa.kind = f.k GROUP BY 1, 2, 3
     ),
     manual AS (
       -- Una reversi\xF3n cuenta en el concepto del movimiento que revierte.
       SELECT m.account_id, m.op_day AS d, coalesce(o.kind, m.kind) AS concepto, sum(m.amount) AS amount
         FROM money_movements m LEFT JOIN money_movements o ON o.id = m.reverses_id
        WHERE m.op_day BETWEEN $1 AND $2 GROUP BY 1, 2, 3
     )
     SELECT account_id, to_char(d, 'YYYY-MM-DD') AS d, concepto, amount::text AS amount FROM (SELECT * FROM auto UNION ALL SELECT * FROM manual) t
      WHERE amount <> 0 ORDER BY d`,[a,t])).rows}o(A,"flows");function S(e,a,t){const s=new Map(a.map(n=>[n.id,0n]));for(const n of e)n.d<=t&&s.set(n.account_id,(s.get(n.account_id)??0n)+c(n.amount));return s}o(S,"balances");async function l(e,a,t){return(await e.query("SELECT coalesce(sum(amount), 0)::numeric(14,2)::text AS t FROM payments WHERE kind = 'propina' AND voided_at IS NULL AND op_day BETWEEN $1 AND $2",[a,t])).rows[0].t}o(l,"tipsBetween");const R=o(e=>e.reduce((a,t)=>a+t,0n),"sumCents"),T=o(e=>i(e),"money");export{m as ACCOUNT_KINDS,N as CONCEPTS,p as DEFAULT_ACCOUNT_NAMES,S as balances,A as flows,_ as listAccounts,T as money,u as startDay,R as sumCents,l as tipsBetween};
