var m=Object.defineProperty;var a=(o,t)=>m(o,"name",{value:t,configurable:!0});import{fromCents as p}from"@pos/shared";import{salesCte as d,Sql as u}from"./metrics.ts";import{dayRollups as l,sumProducts as _,usesRollup as g}from"./rollup.ts";const E=`
  SELECT i.id, CASE WHEN i.avg_cost > 0 THEN i.avg_cost ELSE (
           SELECT round(sp.price / sp.content, 4) FROM supplier_presentations sp
            WHERE sp.stock_item_id = i.id AND sp.is_active AND sp.price IS NOT NULL
            ORDER BY sp.is_default DESC, sp.price / sp.content LIMIT 1) END AS c,
         i.avg_cost > 0 AS de_compras
    FROM stock_items i`;async function S(o,t=null){return(await o.query(`WITH k AS (${E}),
          lineas AS (
            SELECT r.variant_id, s.name, k.c, k.de_compras, r.qty * (1 + r.waste_pct / 100) AS q
              FROM recipe_items r JOIN stock_items s ON s.id = r.stock_item_id JOIN k ON k.id = r.stock_item_id),
          opciones AS (
            -- Por cada grupo obligatorio, la opci\xF3n m\xE1s barata y la m\xE1s cara; se suman los grupos.
            SELECT pmg.product_id, sum(g.mn) AS mn, sum(g.mx) AS mx
              FROM product_modifier_groups pmg
              JOIN (SELECT m.group_id, min(coalesce(m.stock_qty * k.c, 0)) AS mn, max(coalesce(m.stock_qty * k.c, 0)) AS mx
                      FROM modifiers m JOIN modifier_groups mg ON mg.id = m.group_id LEFT JOIN k ON k.id = m.stock_item_id
                     WHERE m.is_active AND mg.min_select >= 1 GROUP BY m.group_id) g ON g.group_id = pmg.group_id
             GROUP BY pmg.product_id)
     SELECT p.id AS "productoId", p.name AS producto, cat.name AS categoria, v.id AS "varianteId", v.name AS variante, v.price AS precio,
            round(CASE WHEN t.is_included THEN v.price / (1 + t.rate) ELSE v.price END, 2) AS "precioSinImpuesto",
            round(sum(l.q * coalesce(l.c, 0)), 2) AS costo,
            count(*)::int AS insumos, count(*) FILTER (WHERE l.de_compras)::int AS "deCompras",
            coalesce(array_agg(l.name ORDER BY l.name) FILTER (WHERE l.c IS NULL), '{}') AS "sinCosto",
            CASE WHEN o.product_id IS NOT NULL THEN json_build_object('min', round(o.mn, 2)::text, 'max', round(o.mx, 2)::text) END AS opciones
       FROM products p JOIN product_variants v ON v.product_id = p.id JOIN lineas l ON l.variant_id = v.id
       LEFT JOIN categories cat ON cat.id = p.category_id LEFT JOIN tax_rates t ON t.id = p.tax_rate_id
       LEFT JOIN opciones o ON o.product_id = p.id
      WHERE p.is_active AND v.is_active AND ($1::uuid[] IS NULL OR p.id = ANY($1))
      GROUP BY p.id, p.name, cat.name, v.id, v.name, v.price, t.is_included, t.rate, o.product_id, o.mn, o.mx
      ORDER BY cat.name NULLS LAST, p.name, v.name`,[t])).rows.map(s=>{const e=Number(s.costo)+Number(s.opciones?.max??0),r=Number(s.precioSinImpuesto);return{...s,foodCost:r>0?(e/r*100).toFixed(1):null,utilidad:(r-e).toFixed(2)}})}a(S,"costosDeProduccion");async function N(o){return new Map((await S(o)).map(t=>[t.varianteId,Number(t.costo)+Number(t.opciones?.max??0)]))}a(N,"costoUnitarioRecetas");async function R(o,t,c){const s=c??await N(o);if(!s.size)return null;let e;if(g(t))e=(await _(o,await l(o,t))).map(i=>({v:i.variantId,qty:i.qty,cost:i.cost}));else{const i=new u,n=d(t,i);e=(await o.query(`WITH ${n} SELECT i.variant_id AS v, sum(i.qty)::float8 AS qty, sum(i.unit_cost * i.qty)::float8 AS cost
         FROM sale_items i JOIN ef ON ef.id = i.sale_id WHERE i.status = 'activo' GROUP BY 1`,i.values)).rows}let r=0n;for(const i of e){const n=s.get(i.v);r+=BigInt(Math.round((n===void 0?i.cost:i.qty*n)*100))}return p(r)}a(R,"costoVentaRecetas");export{N as costoUnitarioRecetas,R as costoVentaRecetas,S as costosDeProduccion};
