-- Decisiones de operación (2026-11-08).

-- Categorías cuyos pagos no pasan por la caja: no alteran el corte aunque se paguen en efectivo.
ALTER TABLE expense_categories ADD COLUMN outside_cash_count boolean NOT NULL DEFAULT false;
-- Exigía turno de caja a todo gasto en efectivo. La regla ahora depende de la categoría y la aplica createExpense.
ALTER TABLE expenses DROP CONSTRAINT expenses_check;

-- Fechas de pago capturadas a mano (nómina). Si hay, tienen prioridad sobre la frecuencia.
ALTER TABLE scheduled_expenses ADD COLUMN pay_dates date[] NOT NULL DEFAULT '{}';
