-- =====================================================================
-- 0003 · Clientes, ventas, cobros, caja, egresos y agregados analíticos
-- =====================================================================

-- ---------------------------------------------------------------------
-- Clientes y crédito (cuentas por cobrar, anticipos)
-- ---------------------------------------------------------------------

CREATE TABLE customers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name          text NOT NULL,
  phone         text,
  email         text,
  tax_id        text,
  address       jsonb NOT NULL DEFAULT '{}',
  notes         text NOT NULL DEFAULT '',
  credit_limit  numeric(14,2) NOT NULL DEFAULT 0 CHECK (credit_limit >= 0),
  balance       numeric(14,2) NOT NULL DEFAULT 0,   -- >0 el cliente debe; <0 saldo a favor (anticipo)
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id)
);
CREATE INDEX customers_name_idx ON customers USING gin (app.normalize(name) gin_trgm_ops);
CREATE INDEX customers_phone_idx ON customers (business_id, phone);
SELECT app.enable_tenant_rls('customers');

-- ---------------------------------------------------------------------
-- Mesas y cajas registradoras
-- ---------------------------------------------------------------------

CREATE TABLE dining_tables (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL,
  branch_id    uuid NOT NULL,
  name         text NOT NULL,
  area         text NOT NULL DEFAULT '',
  seats        int CHECK (seats > 0),
  is_active    boolean NOT NULL DEFAULT true,
  UNIQUE (business_id, id),
  UNIQUE (branch_id, name),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id)
);
SELECT app.enable_tenant_rls('dining_tables');

CREATE TABLE cash_registers (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL,
  branch_id    uuid NOT NULL,
  name         text NOT NULL,
  is_active    boolean NOT NULL DEFAULT true,
  UNIQUE (business_id, id),
  UNIQUE (branch_id, name),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id)
);
SELECT app.enable_tenant_rls('cash_registers');

-- Turno de caja: apertura con fondo -> movimientos -> cortes -> cierre.
CREATE TABLE cash_sessions (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL,
  branch_id      uuid NOT NULL,
  register_id    uuid NOT NULL,
  folio          bigint NOT NULL,
  status         text NOT NULL DEFAULT 'abierta' CHECK (status IN ('abierta','cerrada')),
  opened_by      uuid NOT NULL REFERENCES users(id),
  opened_at      timestamptz NOT NULL DEFAULT now(),
  opening_float  numeric(14,2) NOT NULL CHECK (opening_float >= 0),
  closed_by      uuid REFERENCES users(id),
  closed_at      timestamptz,
  calc_version   text NOT NULL DEFAULT 'v1',   -- los cortes cerrados nunca se recalculan
  UNIQUE (business_id, id),
  UNIQUE (business_id, folio),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, register_id) REFERENCES cash_registers(business_id, id),
  CHECK ((status = 'cerrada') = (closed_at IS NOT NULL))
);
-- Una sola sesión abierta por caja registradora.
CREATE UNIQUE INDEX cash_sessions_one_open_uq ON cash_sessions (register_id) WHERE status = 'abierta';
CREATE INDEX cash_sessions_date_idx ON cash_sessions (business_id, opened_at DESC);
SELECT app.enable_tenant_rls('cash_sessions');

-- ---------------------------------------------------------------------
-- Ventas
-- ---------------------------------------------------------------------

CREATE TABLE sales (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id      uuid NOT NULL,
  branch_id        uuid NOT NULL,
  series           text NOT NULL DEFAULT '',
  folio            bigint NOT NULL,
  client_uuid      uuid NOT NULL,        -- idempotencia: la cola sin conexión no duplica ventas
  status           text NOT NULL DEFAULT 'abierta'
                   CHECK (status IN ('abierta','por_cobrar','pagada','credito','cancelada','devuelta')),
  channel          text NOT NULL DEFAULT 'mostrador'
                   CHECK (channel IN ('mostrador','mesa','para_llevar','domicilio','pedido_especial','en_linea')),
  table_id         uuid,
  customer_id      uuid,
  seller_id        uuid REFERENCES users(id),     -- mesero / vendedor
  cashier_id       uuid REFERENCES users(id),
  cash_session_id  uuid,
  opened_at        timestamptz NOT NULL DEFAULT now(),
  closed_at        timestamptz,
  due_date         date,                          -- ventas a crédito
  delivery_at      timestamptz,                   -- pedidos especiales / domicilio
  delivery_info    jsonb NOT NULL DEFAULT '{}',   -- dirección, destinatario, mensaje de tarjeta...
  notes            text NOT NULL DEFAULT '',
  subtotal         numeric(14,2) NOT NULL DEFAULT 0,
  discount_total   numeric(14,2) NOT NULL DEFAULT 0 CHECK (discount_total >= 0),
  tax_total        numeric(14,2) NOT NULL DEFAULT 0,
  delivery_fee     numeric(14,2) NOT NULL DEFAULT 0 CHECK (delivery_fee >= 0),
  total            numeric(14,2) NOT NULL DEFAULT 0 CHECK (total >= 0),
  paid_total       numeric(14,2) NOT NULL DEFAULT 0,
  balance          numeric(14,2) GENERATED ALWAYS AS (total - paid_total) STORED,
  tip_total        numeric(14,2) NOT NULL DEFAULT 0 CHECK (tip_total >= 0),  -- no es ingreso del negocio
  cost_total       numeric(14,4) NOT NULL DEFAULT 0,
  cancel_reason    text,
  cancelled_by     uuid REFERENCES users(id),
  cancelled_at     timestamptz,
  authorized_by    uuid REFERENCES users(id),
  created_by       uuid REFERENCES users(id),
  UNIQUE (business_id, id),
  UNIQUE (business_id, series, folio),
  UNIQUE (business_id, client_uuid),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, table_id) REFERENCES dining_tables(business_id, id),
  FOREIGN KEY (business_id, customer_id) REFERENCES customers(business_id, id),
  FOREIGN KEY (business_id, cash_session_id) REFERENCES cash_sessions(business_id, id),
  CHECK (status <> 'cancelada' OR (cancel_reason IS NOT NULL AND cancelled_by IS NOT NULL))
);
CREATE INDEX sales_closed_idx ON sales (business_id, branch_id, closed_at DESC);
CREATE INDEX sales_open_idx ON sales (business_id, branch_id) WHERE status IN ('abierta','por_cobrar');
CREATE INDEX sales_customer_idx ON sales (business_id, customer_id) WHERE customer_id IS NOT NULL;
CREATE INDEX sales_session_idx ON sales (cash_session_id);
CREATE INDEX sales_delivery_idx ON sales (business_id, delivery_at) WHERE delivery_at IS NOT NULL;
SELECT app.enable_tenant_rls('sales');

CREATE TABLE sale_items (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id        uuid NOT NULL,
  sale_id            uuid NOT NULL,
  variant_id         uuid NOT NULL,
  name_snapshot      text NOT NULL,      -- el ticket histórico no cambia si cambia el catálogo
  qty                numeric(14,3) NOT NULL CHECK (qty > 0),
  unit_price         numeric(14,2) NOT NULL CHECK (unit_price >= 0),
  list_price         numeric(14,2) NOT NULL CHECK (list_price >= 0),
  price_override_by  uuid REFERENCES users(id),   -- quién autorizó un precio distinto
  discount_amount    numeric(14,2) NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
  discount_by        uuid REFERENCES users(id),
  tax_rate           numeric(7,4) NOT NULL DEFAULT 0,
  tax_included       boolean NOT NULL DEFAULT true,
  tax_amount         numeric(14,2) NOT NULL DEFAULT 0,
  line_total         numeric(14,2) NOT NULL CHECK (line_total >= 0),
  unit_cost          numeric(14,4) NOT NULL DEFAULT 0,
  notes              text NOT NULL DEFAULT '',
  status             text NOT NULL DEFAULT 'activo' CHECK (status IN ('activo','cancelado')),
  kitchen_status     text CHECK (kitchen_status IN ('pendiente','enviado','preparando','listo','entregado')),
  cancelled_by       uuid REFERENCES users(id),
  cancel_reason      text,
  created_by         uuid REFERENCES users(id),
  created_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, sale_id) REFERENCES sales(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, variant_id) REFERENCES product_variants(business_id, id),
  CHECK (unit_price = list_price OR price_override_by IS NOT NULL)
);
CREATE INDEX sale_items_sale_idx ON sale_items (sale_id);
CREATE INDEX sale_items_variant_idx ON sale_items (business_id, variant_id);
SELECT app.enable_tenant_rls('sale_items');

CREATE TABLE sale_item_modifiers (
  business_id    uuid NOT NULL,
  sale_item_id   uuid NOT NULL,
  modifier_id    uuid NOT NULL,
  name_snapshot  text NOT NULL,
  price_delta    numeric(14,2) NOT NULL DEFAULT 0,
  qty            numeric(14,3) NOT NULL DEFAULT 1 CHECK (qty > 0),
  PRIMARY KEY (sale_item_id, modifier_id),
  FOREIGN KEY (business_id, sale_item_id) REFERENCES sale_items(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, modifier_id) REFERENCES modifiers(business_id, id)
);
SELECT app.enable_tenant_rls('sale_item_modifiers');

-- ---------------------------------------------------------------------
-- Cobros. Cada fila = un pago con método, importe, usuario, fecha y referencia.
-- Pagos mixtos = varias filas para la misma venta.
-- ---------------------------------------------------------------------

CREATE TABLE payments (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id       uuid NOT NULL,
  branch_id         uuid NOT NULL,
  sale_id           uuid,
  customer_id       uuid,
  cash_session_id   uuid,
  client_uuid       uuid NOT NULL,
  kind              text NOT NULL CHECK (kind IN ('pago','anticipo','abono','propina','reembolso')),
  method            text NOT NULL CHECK (method IN ('efectivo','tarjeta','transferencia','saldo_cliente','vale','otro')),
  amount            numeric(14,2) NOT NULL CHECK (amount <> 0),   -- reembolso < 0
  tendered          numeric(14,2),           -- efectivo recibido
  change_given      numeric(14,2) NOT NULL DEFAULT 0 CHECK (change_given >= 0),
  reference         text,                    -- autorización de tarjeta, folio de transferencia
  tip_for_user_id   uuid REFERENCES users(id),
  received_by       uuid NOT NULL REFERENCES users(id),
  created_at        timestamptz NOT NULL DEFAULT now(),
  voided_at         timestamptz,
  voided_by         uuid REFERENCES users(id),
  void_reason       text,
  UNIQUE (business_id, id),
  UNIQUE (business_id, client_uuid),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, sale_id) REFERENCES sales(business_id, id),
  FOREIGN KEY (business_id, customer_id) REFERENCES customers(business_id, id),
  FOREIGN KEY (business_id, cash_session_id) REFERENCES cash_sessions(business_id, id),
  CHECK (sale_id IS NOT NULL OR customer_id IS NOT NULL),
  CHECK ((kind = 'reembolso') = (amount < 0)),
  CHECK (method <> 'efectivo' OR cash_session_id IS NOT NULL),
  CHECK (voided_at IS NULL OR (voided_by IS NOT NULL AND void_reason IS NOT NULL))
);
CREATE INDEX payments_sale_idx ON payments (sale_id);
CREATE INDEX payments_session_idx ON payments (cash_session_id);
CREATE INDEX payments_date_idx ON payments (business_id, created_at DESC);
SELECT app.enable_tenant_rls('payments');

-- Libro del cliente (solo inserción): cargos por ventas a crédito, abonos y anticipos.
CREATE TABLE customer_ledger (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL,
  customer_id  uuid NOT NULL,
  kind         text NOT NULL CHECK (kind IN ('cargo','abono','anticipo','aplicacion_anticipo','ajuste')),
  amount       numeric(14,2) NOT NULL CHECK (amount <> 0),   -- + aumenta lo que debe, - lo reduce
  sale_id      uuid,
  payment_id   uuid,
  notes        text NOT NULL DEFAULT '',
  user_id      uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (business_id, customer_id) REFERENCES customers(business_id, id),
  FOREIGN KEY (business_id, sale_id) REFERENCES sales(business_id, id),
  FOREIGN KEY (business_id, payment_id) REFERENCES payments(business_id, id)
);
CREATE INDEX customer_ledger_customer_idx ON customer_ledger (business_id, customer_id, created_at DESC);
CREATE TRIGGER customer_ledger_append_only BEFORE UPDATE OR DELETE ON customer_ledger
  FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
SELECT app.enable_tenant_rls('customer_ledger');

CREATE FUNCTION app.apply_customer_ledger() RETURNS trigger
  LANGUAGE plpgsql AS
$$ BEGIN
  UPDATE customers SET balance = balance + NEW.amount WHERE id = NEW.customer_id;
  RETURN NEW;
END $$;
CREATE TRIGGER customer_ledger_apply AFTER INSERT ON customer_ledger
  FOR EACH ROW EXECUTE FUNCTION app.apply_customer_ledger();

-- Devoluciones.
CREATE TABLE refunds (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL,
  sale_id        uuid NOT NULL,
  folio          bigint NOT NULL,
  reason         text NOT NULL,
  total          numeric(14,2) NOT NULL CHECK (total > 0),
  created_by     uuid NOT NULL REFERENCES users(id),
  authorized_by  uuid REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, folio),
  FOREIGN KEY (business_id, sale_id) REFERENCES sales(business_id, id)
);
SELECT app.enable_tenant_rls('refunds');

CREATE TABLE refund_items (
  business_id   uuid NOT NULL,
  refund_id     uuid NOT NULL,
  sale_item_id  uuid NOT NULL,
  qty           numeric(14,3) NOT NULL CHECK (qty > 0),
  amount        numeric(14,2) NOT NULL CHECK (amount >= 0),
  restock       boolean NOT NULL DEFAULT true,
  PRIMARY KEY (refund_id, sale_item_id),
  FOREIGN KEY (business_id, refund_id) REFERENCES refunds(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, sale_item_id) REFERENCES sale_items(business_id, id)
);
SELECT app.enable_tenant_rls('refund_items');

-- ---------------------------------------------------------------------
-- Egresos
-- ---------------------------------------------------------------------

CREATE TABLE expense_categories (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id     uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name            text NOT NULL,
  grp             text NOT NULL CHECK (grp IN ('operativo','compras','servicios','nomina','mantenimiento','transporte','impuestos','otros')),
  -- Las compras de mercancía/insumos ya están en el costo de venta: no se restan dos veces.
  in_cost_of_goods boolean NOT NULL DEFAULT false,
  is_active       boolean NOT NULL DEFAULT true,
  UNIQUE (business_id, id),
  UNIQUE (business_id, name)
);
SELECT app.enable_tenant_rls('expense_categories');

CREATE TABLE expenses (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id      uuid NOT NULL,
  branch_id        uuid NOT NULL,
  category_id      uuid NOT NULL,
  folio            bigint NOT NULL,
  description      text NOT NULL,
  amount           numeric(14,2) NOT NULL CHECK (amount > 0),
  method           text NOT NULL CHECK (method IN ('efectivo','tarjeta','transferencia','otro')),
  paid_at          timestamptz NOT NULL DEFAULT now(),
  responsible_id   uuid NOT NULL REFERENCES users(id),
  supplier_id      uuid,
  purchase_id      uuid,
  cash_session_id  uuid,
  receipt_asset    text,
  status           text NOT NULL DEFAULT 'registrado' CHECK (status IN ('por_autorizar','registrado','anulado')),
  authorized_by    uuid REFERENCES users(id),
  void_reason      text,
  created_by       uuid NOT NULL REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, folio),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, category_id) REFERENCES expense_categories(business_id, id),
  FOREIGN KEY (business_id, supplier_id) REFERENCES suppliers(business_id, id),
  FOREIGN KEY (business_id, purchase_id) REFERENCES purchases(business_id, id),
  FOREIGN KEY (business_id, cash_session_id) REFERENCES cash_sessions(business_id, id),
  CHECK (method <> 'efectivo' OR cash_session_id IS NOT NULL)
);
CREATE INDEX expenses_date_idx ON expenses (business_id, paid_at DESC);
CREATE INDEX expenses_category_idx ON expenses (business_id, category_id, paid_at DESC);
SELECT app.enable_tenant_rls('expenses');

-- Movimientos de efectivo del turno que no son ventas: entradas, salidas,
-- retiros (no reducen utilidad) y gastos pagados en efectivo (sí la reducen).
CREATE TABLE cash_movements (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id      uuid NOT NULL,
  cash_session_id  uuid NOT NULL,
  kind             text NOT NULL CHECK (kind IN ('entrada','salida','retiro','gasto','reintegro')),
  amount           numeric(14,2) NOT NULL CHECK (amount > 0),
  reason           text NOT NULL,
  expense_id       uuid,
  after_close      boolean NOT NULL DEFAULT false,   -- registrado después del corte (regla de pos-gomtm)
  status           text NOT NULL DEFAULT 'registrado' CHECK (status IN ('por_autorizar','registrado','rechazado','anulado')),
  user_id          uuid NOT NULL REFERENCES users(id),
  authorized_by    uuid REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, cash_session_id) REFERENCES cash_sessions(business_id, id),
  FOREIGN KEY (business_id, expense_id) REFERENCES expenses(business_id, id),
  CHECK ((kind = 'gasto') = (expense_id IS NOT NULL))
);
CREATE INDEX cash_movements_session_idx ON cash_movements (cash_session_id);
SELECT app.enable_tenant_rls('cash_movements');

-- Cortes (parciales y final). Inmutables: una corrección es un corte nuevo
-- que apunta al corregido, con motivo y autorización.
CREATE TABLE cash_counts (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id       uuid NOT NULL,
  cash_session_id   uuid NOT NULL,
  folio             bigint NOT NULL,
  kind              text NOT NULL CHECK (kind IN ('parcial','final')),
  expected_cash     numeric(14,2) NOT NULL,
  counted_cash      numeric(14,2) NOT NULL CHECK (counted_cash >= 0),
  difference        numeric(14,2) GENERATED ALWAYS AS (counted_cash - expected_cash) STORED,
  totals_by_method  jsonb NOT NULL DEFAULT '{}',   -- {"efectivo":..,"tarjeta":..} calculado al cortar
  denominations     jsonb NOT NULL DEFAULT '{}',   -- {"500":2,"200":3,...}
  notes             text NOT NULL DEFAULT '',
  corrects_id       uuid,
  correction_reason text,
  counted_by        uuid NOT NULL REFERENCES users(id),
  authorized_by     uuid REFERENCES users(id),
  counted_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, folio),
  FOREIGN KEY (business_id, cash_session_id) REFERENCES cash_sessions(business_id, id),
  FOREIGN KEY (business_id, corrects_id) REFERENCES cash_counts(business_id, id),
  CHECK (corrects_id IS NULL OR (correction_reason IS NOT NULL AND authorized_by IS NOT NULL))
);
CREATE INDEX cash_counts_session_idx ON cash_counts (cash_session_id);
CREATE TRIGGER cash_counts_append_only BEFORE UPDATE OR DELETE ON cash_counts
  FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
SELECT app.enable_tenant_rls('cash_counts');

-- ---------------------------------------------------------------------
-- Agregados para tablero y gráficas (se actualizan al registrar operaciones;
-- evitan recorrer todo el historial en cada consulta).
-- ---------------------------------------------------------------------

CREATE TABLE daily_sales_agg (
  business_id     uuid NOT NULL,
  branch_id       uuid NOT NULL,
  day             date NOT NULL,          -- en la zona horaria del negocio
  sales_count     int NOT NULL DEFAULT 0,
  gross_sales     numeric(14,2) NOT NULL DEFAULT 0,
  discounts       numeric(14,2) NOT NULL DEFAULT 0,
  net_sales       numeric(14,2) NOT NULL DEFAULT 0,
  tax             numeric(14,2) NOT NULL DEFAULT 0,
  tips            numeric(14,2) NOT NULL DEFAULT 0,
  cost_of_goods   numeric(14,4) NOT NULL DEFAULT 0,
  refunds         numeric(14,2) NOT NULL DEFAULT 0,
  expenses        numeric(14,2) NOT NULL DEFAULT 0,
  by_method       jsonb NOT NULL DEFAULT '{}',
  PRIMARY KEY (business_id, branch_id, day),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id)
);
SELECT app.enable_tenant_rls('daily_sales_agg');

CREATE TABLE hourly_sales_agg (
  business_id  uuid NOT NULL,
  branch_id    uuid NOT NULL,
  day          date NOT NULL,
  hour         smallint NOT NULL CHECK (hour BETWEEN 0 AND 23),
  sales_count  int NOT NULL DEFAULT 0,
  net_sales    numeric(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (business_id, branch_id, day, hour),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id)
);
SELECT app.enable_tenant_rls('hourly_sales_agg');

CREATE TABLE daily_product_agg (
  business_id  uuid NOT NULL,
  branch_id    uuid NOT NULL,
  day          date NOT NULL,
  variant_id   uuid NOT NULL,
  qty          numeric(14,3) NOT NULL DEFAULT 0,
  revenue      numeric(14,2) NOT NULL DEFAULT 0,
  cost         numeric(14,4) NOT NULL DEFAULT 0,
  PRIMARY KEY (business_id, branch_id, day, variant_id),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, variant_id) REFERENCES product_variants(business_id, id)
);
CREATE INDEX daily_product_agg_variant_idx ON daily_product_agg (business_id, variant_id, day);
SELECT app.enable_tenant_rls('daily_product_agg');
