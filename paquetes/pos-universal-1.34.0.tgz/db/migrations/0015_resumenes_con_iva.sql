-- ================================================================
-- 0015 · Los resúmenes diarios incluyen el importe con IVA de cada
--        producto (D-032). Los guardados antes se recalculan.
-- ================================================================
DELETE FROM op_day_rollup;
