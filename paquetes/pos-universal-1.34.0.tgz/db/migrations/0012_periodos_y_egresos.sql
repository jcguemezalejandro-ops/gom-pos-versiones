-- ================================================================
-- 0012 · Día operativo, egresos independientes de la caja y
--        pagos programados sin duplicados.
-- ================================================================

-- Un egreso puede registrarse sin estar pagado todavía.
ALTER TABLE expenses ADD COLUMN is_paid boolean NOT NULL DEFAULT true;
ALTER TABLE expenses ADD COLUMN settled_at timestamptz;
-- Vencimiento que liquida un pago de gasto fijo o nómina.
ALTER TABLE expenses ADD COLUMN scheduled_due date;

-- Lo importado como pendiente del sistema anterior conserva ese estado.
UPDATE expenses SET is_paid = false WHERE description LIKE '[Pago pendiente en pos-gomtm]%';

-- Un mismo vencimiento no se paga dos veces. Un pago anulado libera su vencimiento.
CREATE UNIQUE INDEX expenses_scheduled_due_uq ON expenses (business_id, scheduled_id, scheduled_due)
  WHERE scheduled_id IS NOT NULL AND scheduled_due IS NOT NULL AND status <> 'anulado';
CREATE INDEX expenses_scheduled_idx ON expenses (scheduled_id, paid_at DESC) WHERE scheduled_id IS NOT NULL;

-- Hora de corte del día operativo para los negocios que ya existen.
INSERT INTO business_settings (business_id, key, value)
SELECT id, 'operacion', jsonb_build_object('horaCorte', CASE WHEN business_type IN ('restaurante','hamburgueseria','cafeteria') THEN '05:00' ELSE '00:00' END)
  FROM businesses
ON CONFLICT DO NOTHING;

-- ---------------- Día operativo guardado ----------------
-- Lo ocurrido durante un turno de caja pertenece al día en que abrió ese turno, aunque pase la
-- medianoche (un turno abierto más de 36 horas deja de contar). Sin turno, se resta la hora de corte.
-- Se guarda en cada registro para filtrar por índice; calcularlo en cada consulta era lento con
-- cientos de miles de ventas.
CREATE INDEX cash_sessions_period_idx ON cash_sessions (branch_id, opened_at);

CREATE FUNCTION app.op_cut(p_business uuid) RETURNS interval
LANGUAGE sql STABLE AS
$$
  SELECT coalesce(
    (SELECT (value->>'horaCorte')::interval FROM business_settings WHERE business_id = p_business AND key = 'operacion'),
    CASE WHEN (SELECT business_type FROM businesses WHERE id = p_business) IN ('restaurante','hamburgueseria','cafeteria')
         THEN interval '5 hours' ELSE interval '0' END)
$$;

CREATE FUNCTION app.op_day(p_branch uuid, p_at timestamptz) RETURNS date
LANGUAGE sql STABLE AS
$$
  SELECT ((coalesce(
            (SELECT min(c.opened_at) FROM cash_sessions c
              WHERE c.branch_id = p_branch AND c.opened_at <= p_at
                AND p_at <= least(coalesce(c.closed_at, 'infinity'), c.opened_at + interval '36 hours')),
            p_at) AT TIME ZONE coalesce(br.timezone, b.timezone)) - app.op_cut(br.business_id))::date
    FROM branches br JOIN businesses b ON b.id = br.business_id
   WHERE br.id = p_branch
$$;

ALTER TABLE sales ADD COLUMN op_day date;
ALTER TABLE payments ADD COLUMN op_day date;
ALTER TABLE refunds ADD COLUMN op_day date;
ALTER TABLE expenses ADD COLUMN op_day date;

UPDATE sales SET op_day = app.op_day(branch_id, coalesce(closed_at, opened_at));
UPDATE payments SET op_day = app.op_day(branch_id, created_at);
UPDATE refunds f SET op_day = app.op_day(s.branch_id, f.created_at) FROM sales s WHERE s.id = f.sale_id;
UPDATE expenses SET op_day = app.op_day(branch_id, paid_at);

CREATE FUNCTION app.set_op_day() RETURNS trigger
LANGUAGE plpgsql AS
$$
BEGIN
  IF TG_TABLE_NAME = 'sales' THEN
    NEW.op_day := app.op_day(NEW.branch_id, coalesce(NEW.closed_at, NEW.opened_at));
  ELSIF TG_TABLE_NAME = 'payments' THEN
    NEW.op_day := app.op_day(NEW.branch_id, NEW.created_at);
  ELSIF TG_TABLE_NAME = 'expenses' THEN
    NEW.op_day := app.op_day(NEW.branch_id, NEW.paid_at);
  ELSE
    NEW.op_day := app.op_day((SELECT branch_id FROM sales WHERE id = NEW.sale_id), NEW.created_at);
  END IF;
  RETURN NEW;
END
$$;
CREATE TRIGGER sales_op_day BEFORE INSERT OR UPDATE OF opened_at, closed_at, branch_id ON sales FOR EACH ROW EXECUTE FUNCTION app.set_op_day();
CREATE TRIGGER payments_op_day BEFORE INSERT OR UPDATE OF created_at, branch_id ON payments FOR EACH ROW EXECUTE FUNCTION app.set_op_day();
CREATE TRIGGER refunds_op_day BEFORE INSERT OR UPDATE OF created_at ON refunds FOR EACH ROW EXECUTE FUNCTION app.set_op_day();
CREATE TRIGGER expenses_op_day BEFORE INSERT OR UPDATE OF paid_at, branch_id ON expenses FOR EACH ROW EXECUTE FUNCTION app.set_op_day();

-- Recalcula el día operativo del negocio actual (al cambiar la hora de corte).
CREATE FUNCTION app.recompute_op_days() RETURNS void
LANGUAGE sql AS
$$
  UPDATE sales SET op_day = app.op_day(branch_id, coalesce(closed_at, opened_at)) WHERE business_id = app.current_business();
  UPDATE payments SET op_day = app.op_day(branch_id, created_at) WHERE business_id = app.current_business();
  UPDATE refunds f SET op_day = app.op_day(s.branch_id, f.created_at) FROM sales s WHERE s.id = f.sale_id AND f.business_id = app.current_business();
  UPDATE expenses SET op_day = app.op_day(branch_id, paid_at) WHERE business_id = app.current_business();
$$;

CREATE INDEX sales_op_day_idx ON sales (business_id, op_day);
CREATE INDEX payments_op_day_idx ON payments (business_id, op_day);
CREATE INDEX refunds_op_day_idx ON refunds (business_id, op_day);
CREATE INDEX expenses_op_day_idx ON expenses (business_id, op_day);

-- ---------------- Resumen por día operativo ----------------
-- Un año de ventas se arma sumando los resúmenes de cada día, no recorriendo todas las ventas.
-- Lo calcula la API con la misma consulta que usa para un solo día. Los días recientes
-- (los últimos 3 según UTC) no se guardan: se calculan siempre al momento. Si cambia algo de
-- un día anterior (una devolución, un abono, un egreso con fecha pasada), su resumen se borra
-- y se vuelve a calcular en la siguiente consulta.
CREATE TABLE op_day_rollup (
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  branch_id    uuid NOT NULL,
  op_day       date NOT NULL,
  data         jsonb NOT NULL,
  computed_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, branch_id, op_day),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id) ON DELETE CASCADE
);
SELECT app.enable_tenant_rls('op_day_rollup');
GRANT SELECT, INSERT, UPDATE, DELETE ON op_day_rollup TO pos_app;

CREATE FUNCTION app.forget_op_day(p_branch uuid, p_day date) RETURNS void
LANGUAGE sql AS
$$
  DELETE FROM op_day_rollup WHERE branch_id = p_branch AND op_day = p_day
     AND p_day < (now() AT TIME ZONE 'UTC')::date - 3;
$$;

-- Borra el resumen del día al que pertenece un registro (recibido como JSON).
CREATE FUNCTION app.forget_for(p_table text, r jsonb) RETURNS void
LANGUAGE plpgsql AS
$$
BEGIN
  IF p_table IN ('sales', 'expenses') THEN
    PERFORM app.forget_op_day((r->>'branch_id')::uuid, (r->>'op_day')::date);
  ELSIF p_table IN ('sale_items', 'payments') THEN
    IF r->>'sale_id' IS NOT NULL THEN
      PERFORM app.forget_op_day(s.branch_id, s.op_day) FROM sales s WHERE s.id = (r->>'sale_id')::uuid;
    END IF;
  ELSIF p_table = 'refunds' THEN
    PERFORM app.forget_op_day(s.branch_id, (r->>'op_day')::date) FROM sales s WHERE s.id = (r->>'sale_id')::uuid;
  ELSIF p_table = 'refund_items' THEN
    PERFORM app.forget_op_day(s.branch_id, f.op_day) FROM refunds f JOIN sales s ON s.id = f.sale_id WHERE f.id = (r->>'refund_id')::uuid;
  END IF;
END
$$;

CREATE FUNCTION app.forget_rollup() RETURNS trigger
LANGUAGE plpgsql AS
$$
BEGIN
  IF TG_OP <> 'DELETE' THEN PERFORM app.forget_for(TG_TABLE_NAME, to_jsonb(NEW)); END IF;
  IF TG_OP <> 'INSERT' THEN PERFORM app.forget_for(TG_TABLE_NAME, to_jsonb(OLD)); END IF;
  RETURN NULL;
END
$$;
CREATE TRIGGER sales_rollup AFTER INSERT OR UPDATE OR DELETE ON sales FOR EACH ROW EXECUTE FUNCTION app.forget_rollup();
CREATE TRIGGER sale_items_rollup AFTER INSERT OR UPDATE OR DELETE ON sale_items FOR EACH ROW EXECUTE FUNCTION app.forget_rollup();
CREATE TRIGGER payments_rollup AFTER INSERT OR UPDATE OR DELETE ON payments FOR EACH ROW EXECUTE FUNCTION app.forget_rollup();
CREATE TRIGGER refunds_rollup AFTER INSERT OR UPDATE OR DELETE ON refunds FOR EACH ROW EXECUTE FUNCTION app.forget_rollup();
CREATE TRIGGER refund_items_rollup AFTER INSERT OR UPDATE OR DELETE ON refund_items FOR EACH ROW EXECUTE FUNCTION app.forget_rollup();
CREATE TRIGGER expenses_rollup AFTER INSERT OR UPDATE OR DELETE ON expenses FOR EACH ROW EXECUTE FUNCTION app.forget_rollup();

-- Al cambiar la hora de corte también se descartan los resúmenes.
CREATE OR REPLACE FUNCTION app.recompute_op_days() RETURNS void
LANGUAGE sql AS
$$
  UPDATE sales SET op_day = app.op_day(branch_id, coalesce(closed_at, opened_at)) WHERE business_id = app.current_business();
  UPDATE payments SET op_day = app.op_day(branch_id, created_at) WHERE business_id = app.current_business();
  UPDATE refunds f SET op_day = app.op_day(s.branch_id, f.created_at) FROM sales s WHERE s.id = f.sale_id AND f.business_id = app.current_business();
  UPDATE expenses SET op_day = app.op_day(branch_id, paid_at) WHERE business_id = app.current_business();
  DELETE FROM op_day_rollup WHERE business_id = app.current_business();
$$;

-- El precálculo de resúmenes recorre todos los negocios; RLS le impide listarlos por sí mismo.
CREATE FUNCTION app.all_business_ids() RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$ SELECT id FROM businesses WHERE status = 'activo' $$;
REVOKE EXECUTE ON FUNCTION app.all_business_ids() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.all_business_ids() TO pos_app;
