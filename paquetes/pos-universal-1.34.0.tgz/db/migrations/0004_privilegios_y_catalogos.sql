-- =====================================================================
-- 0004 · Privilegios del rol de la API (pos_app) y catálogos globales
--
-- pos_owner: dueño del esquema, ejecuta migraciones (BYPASSRLS).
-- pos_app:   rol con el que corre la API. No es dueño ni tiene BYPASSRLS,
--            por lo que TODAS las políticas RLS le aplican.
-- =====================================================================

-- Los triggers que mantienen saldos y existencias corren como dueño, para
-- que la API no tenga permiso de escribir esos campos directamente.
ALTER FUNCTION app.apply_stock_movement() SECURITY DEFINER SET search_path = public, app;
ALTER FUNCTION app.apply_customer_ledger() SECURITY DEFINER SET search_path = public, app;

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public, app TO pos_app;
REVOKE EXECUTE ON FUNCTION app.enable_tenant_rls(regclass) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.apply_stock_movement() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.apply_customer_ledger() FROM PUBLIC;

-- Catálogos globales: solo lectura.
GRANT SELECT ON business_types, modules, permissions, units TO pos_app;

-- Tablas de negocio: lectura y escritura (las restringe RLS).
GRANT SELECT, INSERT, UPDATE, DELETE ON
  businesses, branches, users, roles, role_permissions, memberships, sessions,
  business_settings, business_modules, document_sequences,
  tax_rates, categories, products, product_variants, price_tiers,
  modifier_groups, modifiers, product_modifier_groups, recipe_items,
  stock_lots, suppliers, purchases, purchase_items,
  dining_tables, cash_registers, cash_sessions, sales, sale_items, sale_item_modifiers,
  payments, refunds, refund_items, expense_categories, expenses, cash_movements,
  daily_sales_agg, hourly_sales_agg, daily_product_agg
TO pos_app;

-- Libros de solo inserción.
GRANT SELECT, INSERT ON audit_log, stock_movements, customer_ledger, cash_counts TO pos_app;

-- Existencias: solo lectura (las escribe el trigger de movimientos).
GRANT SELECT ON stock_levels TO pos_app;

-- Saldos y costos calculados: la API puede editar todo menos esas columnas.
GRANT SELECT, INSERT, DELETE ON stock_items, customers TO pos_app;
GRANT UPDATE (name, kind, unit_code, sku, min_stock, reorder_qty, tracks_lots,
              is_perishable, shelf_life_days, is_active) ON stock_items TO pos_app;
GRANT UPDATE (name, phone, email, tax_id, address, notes, credit_limit, is_active) ON customers TO pos_app;

GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO pos_app;

-- ---------------------------------------------------------------------
-- Catálogos globales
-- ---------------------------------------------------------------------

INSERT INTO units (code, name, dimension, factor_to_base, allows_decimals) VALUES
  ('pz',      'Pieza',     'unidad',   1,     false),
  ('docena',  'Docena',    'unidad',   12,    false),
  ('caja',    'Caja',      'unidad',   1,     false),
  ('paquete', 'Paquete',   'unidad',   1,     false),
  ('kg',      'Kilogramo', 'masa',     1,     true),
  ('g',       'Gramo',     'masa',     0.001, true),
  ('l',       'Litro',     'volumen',  1,     true),
  ('ml',      'Mililitro', 'volumen',  0.001, true),
  ('m',       'Metro',     'longitud', 1,     true),
  ('cm',      'Centímetro','longitud', 0.01,  true),
  ('h',       'Hora',      'tiempo',   1,     true),
  ('servicio','Servicio',  'unidad',   1,     false);

INSERT INTO business_types (key, name, description) VALUES
  ('restaurante',    'Restaurante',          'Mesas, comandas, cocina, para llevar y domicilio'),
  ('hamburgueseria', 'Hamburguesería',       'Menú con modificadores, comandas, para llevar y domicilio'),
  ('cafeteria',      'Cafetería',            'Bebidas por tamaño, modificadores y venta rápida'),
  ('floreria',       'Florería',             'Arreglos, pedidos especiales con fecha de entrega, anticipos y perecederos'),
  ('abarrotes',      'Tienda de abarrotes',  'Venta por pieza, kilo o litro, código de barras, caducidades y mayoreo'),
  ('minisuper',      'Minisúper',            'Código de barras, caducidades, compras e inventario'),
  ('boutique',       'Boutique',             'Tallas, colores, modelos e inventario por variante'),
  ('ropa',           'Tienda de ropa',       'Variantes por talla y color con código de barras'),
  ('papeleria',      'Papelería',            'Muchos artículos pequeños, código de barras y mayoreo'),
  ('ferreteria',     'Ferretería',           'Venta por pieza, metro o kilo, mayoreo y crédito a clientes'),
  ('servicios',      'Negocio de servicios', 'Servicios por hora o por trabajo, anticipos y clientes'),
  ('mayorista',      'Comercio mayorista',   'Precios por volumen, crédito a clientes y compras'),
  ('general',        'Comercio minorista',   'Configuración general de tienda');

INSERT INTO modules (key, name, description, is_core, depends_on, sort_order) VALUES
  ('nucleo',      'Núcleo',                 'Negocio, sucursales, usuarios, roles, configuración y auditoría', true,  '{}', 0),
  ('catalogo',    'Catálogo',               'Productos, categorías, precios e impuestos',                      true,  '{}', 10),
  ('ventas',      'Ventas y cobros',        'Punto de venta, tickets, pagos mixtos, cancelaciones',            true,  '{catalogo}', 20),
  ('caja',        'Caja',                   'Apertura, movimientos, cortes y cierre',                          true,  '{ventas}', 30),
  ('inventario',  'Inventario',             'Existencias, movimientos, ajustes, mermas y alertas',             false, '{catalogo}', 40),
  ('compras',     'Compras y proveedores',  'Pedidos y recepción de mercancía',                                false, '{inventario}', 50),
  ('clientes',    'Clientes y crédito',     'Clientes, ventas a crédito, abonos y anticipos',                  false, '{ventas}', 60),
  ('egresos',     'Egresos y gastos',       'Gastos operativos, servicios, nómina y otros',                    false, '{}', 70),
  ('reportes',    'Reportes',               'Reportes y exportación a Excel, PDF y CSV',                       false, '{}', 80),
  ('analitica',   'Inteligencia comercial', 'Gráficas, tendencias y alertas automáticas',                      false, '{reportes}', 90),
  ('variantes',   'Variantes',              'Tallas, colores, tamaños y presentaciones',                       false, '{catalogo}', 100),
  ('modificadores','Modificadores',         'Complementos y extras con precio',                                false, '{catalogo}', 110),
  ('recetas',     'Recetas',                'Insumos que consume cada producto',                               false, '{inventario}', 120),
  ('lotes',       'Lotes y caducidades',    'Control de caducidad y perecederos',                              false, '{inventario}', 130),
  ('mayoreo',     'Mayoreo',                'Precios por volumen',                                             false, '{catalogo}', 140),
  ('mesas',       'Mesas',                  'Plano de mesas y cuentas por mesa',                               false, '{ventas}', 150),
  ('cocina',      'Comandas',               'Envío de partidas a cocina o barra',                              false, '{ventas}', 160),
  ('domicilio',   'Servicio a domicilio',   'Pedidos con dirección, tarifa y repartidor',                      false, '{ventas}', 170),
  ('pedidos',     'Pedidos especiales',     'Pedidos con fecha de entrega, personalización y anticipo',        false, '{ventas,clientes}', 180),
  ('propinas',    'Propinas',               'Registro y reparto de propinas',                                  false, '{ventas}', 190),
  ('sucursales',  'Multisucursal',          'Varias sucursales y traspasos',                                   false, '{}', 200);

INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('configuracion.ver',      'nucleo', 'Ver la configuración del negocio', false),
  ('configuracion.editar',   'nucleo', 'Cambiar la configuración del negocio', true),
  ('negocio.modulos',        'nucleo', 'Activar o desactivar módulos', true),
  ('sucursales.gestionar',   'nucleo', 'Crear y editar sucursales', true),
  ('usuarios.ver',           'nucleo', 'Ver usuarios', false),
  ('usuarios.gestionar',     'nucleo', 'Dar de alta, editar y desactivar usuarios', true),
  ('roles.gestionar',        'nucleo', 'Crear roles y cambiar permisos', true),
  ('auditoria.ver',          'nucleo', 'Consultar la bitácora de auditoría', false),
  ('catalogo.ver',           'catalogo', 'Ver productos y precios', false),
  ('catalogo.editar',        'catalogo', 'Crear y editar productos, categorías y precios', false),
  ('catalogo.costos',        'catalogo', 'Ver y editar costos', false),
  ('ventas.crear',           'ventas', 'Registrar ventas y pedidos', false),
  ('ventas.ver_propias',     'ventas', 'Consultar sus propias ventas', false),
  ('ventas.ver_todas',       'ventas', 'Consultar todas las ventas', false),
  ('ventas.descuento',       'ventas', 'Aplicar descuentos', true),
  ('ventas.precio_manual',   'ventas', 'Cambiar el precio de una partida', true),
  ('ventas.cancelar_partida','ventas', 'Cancelar partidas ya registradas', true),
  ('ventas.cancelar',        'ventas', 'Cancelar ventas completas', true),
  ('ventas.devolver',        'ventas', 'Registrar devoluciones', true),
  ('ventas.reimprimir',      'ventas', 'Reimprimir tickets', false),
  ('cobros.cobrar',          'ventas', 'Cobrar ventas', false),
  ('cobros.anular',          'ventas', 'Anular un pago registrado', true),
  ('caja.abrir',             'caja', 'Abrir caja con fondo inicial', false),
  ('caja.cerrar',            'caja', 'Hacer el corte final y cerrar caja', false),
  ('caja.corte_parcial',     'caja', 'Hacer cortes parciales', false),
  ('caja.movimientos',       'caja', 'Registrar entradas y salidas de efectivo', true),
  ('caja.retiro',            'caja', 'Registrar retiros de efectivo', true),
  ('caja.historial',         'caja', 'Consultar turnos y cortes anteriores', false),
  ('caja.corregir_corte',    'caja', 'Corregir un corte cerrado', true),
  ('inventario.ver',         'inventario', 'Ver existencias y movimientos', false),
  ('inventario.ajustar',     'inventario', 'Ajustar existencias', true),
  ('inventario.merma',       'inventario', 'Registrar mermas', true),
  ('inventario.traspasar',   'inventario', 'Traspasar entre sucursales', false),
  ('inventario.conteo',      'inventario', 'Hacer conteos físicos', false),
  ('compras.ver',            'compras', 'Ver compras', false),
  ('compras.crear',          'compras', 'Crear pedidos de compra', false),
  ('compras.recibir',        'compras', 'Recibir mercancía', false),
  ('proveedores.gestionar',  'compras', 'Crear y editar proveedores', false),
  ('clientes.ver',           'clientes', 'Ver clientes', false),
  ('clientes.gestionar',     'clientes', 'Crear y editar clientes', false),
  ('clientes.credito',       'clientes', 'Vender a crédito y cambiar límites', true),
  ('egresos.ver',            'egresos', 'Ver egresos', false),
  ('egresos.registrar',      'egresos', 'Registrar egresos', false),
  ('egresos.autorizar',      'egresos', 'Autorizar egresos pendientes', true),
  ('egresos.anular',         'egresos', 'Anular egresos', true),
  ('reportes.ver',           'reportes', 'Consultar reportes operativos', false),
  ('reportes.financieros',   'reportes', 'Consultar ganancias, costos y estados financieros', false),
  ('reportes.exportar',      'reportes', 'Exportar a Excel, PDF y CSV', false),
  ('analitica.ver',          'analitica', 'Ver gráficas y alertas', false),
  ('mesas.gestionar',        'mesas', 'Configurar mesas y áreas', false),
  ('cocina.ver',             'cocina', 'Ver y actualizar comandas', false),
  ('domicilio.gestionar',    'domicilio', 'Gestionar entregas a domicilio', false),
  ('pedidos.gestionar',      'pedidos', 'Gestionar pedidos especiales', false),
  ('propinas.ver',           'propinas', 'Ver y repartir propinas', false);
