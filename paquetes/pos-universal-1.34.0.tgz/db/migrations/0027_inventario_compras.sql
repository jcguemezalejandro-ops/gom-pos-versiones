-- ================================================================
-- 0027 · Datos de compra del inventario (D-058, docs/inventario-compras.md)
--
--   · suppliers: días de entrega, días de crédito y pedido mínimo.
--   · stock_items: marca, proveedor principal y existencia máxima (pedir hasta).
--   · supplier_presentations: formas de comprar un insumo (bote, caja...) con su
--     contenido en la unidad del insumo y sus precios de menudeo y mayoreo.
-- No modifica datos existentes: solo agrega columnas con valor por omisión y una tabla.
-- ================================================================

ALTER TABLE suppliers
  ADD COLUMN delivery_days text[] NOT NULL DEFAULT '{}'
    CHECK (delivery_days <@ ARRAY['lun','mar','mie','jue','vie','sab','dom']::text[]),
  ADD COLUMN credit_days int NOT NULL DEFAULT 0 CHECK (credit_days BETWEEN 0 AND 365),
  ADD COLUMN min_order numeric(14,2) NOT NULL DEFAULT 0 CHECK (min_order >= 0);

ALTER TABLE stock_items
  ADD COLUMN brand text,
  ADD COLUMN supplier_id uuid,
  ADD COLUMN max_stock numeric(14,3) NOT NULL DEFAULT 0 CHECK (max_stock >= 0),
  ADD CONSTRAINT stock_items_supplier_fk FOREIGN KEY (business_id, supplier_id) REFERENCES suppliers(business_id, id),
  ADD CONSTRAINT stock_items_max_gt_min CHECK (max_stock = 0 OR max_stock > min_stock);
GRANT UPDATE (brand, supplier_id, max_stock) ON stock_items TO pos_app;

CREATE TABLE supplier_presentations (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id     uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  stock_item_id   uuid NOT NULL,
  supplier_id     uuid,
  brand           text,
  name            text NOT NULL CHECK (length(trim(name)) > 0),
  content         numeric(14,3) NOT NULL CHECK (content > 0),     -- en la unidad del insumo
  price           numeric(14,2) CHECK (price >= 0),                -- menudeo, por presentación
  wholesale_price numeric(14,2) CHECK (wholesale_price >= 0),
  wholesale_min   int CHECK (wholesale_min > 1),
  is_default      boolean NOT NULL DEFAULT false,
  barcode         text,
  is_active       boolean NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, supplier_id) REFERENCES suppliers(business_id, id),
  CHECK ((wholesale_price IS NULL) = (wholesale_min IS NULL))
);
-- La importación une presentaciones por insumo, proveedor, nombre y contenido.
CREATE UNIQUE INDEX supplier_presentations_key ON supplier_presentations
  (business_id, stock_item_id, coalesce(supplier_id, '00000000-0000-0000-0000-000000000000'::uuid), app.normalize(name), content);
CREATE UNIQUE INDEX supplier_presentations_default ON supplier_presentations (stock_item_id) WHERE is_default AND is_active;
SELECT app.enable_tenant_rls('supplier_presentations');
GRANT SELECT, INSERT, UPDATE, DELETE ON supplier_presentations TO pos_app;
