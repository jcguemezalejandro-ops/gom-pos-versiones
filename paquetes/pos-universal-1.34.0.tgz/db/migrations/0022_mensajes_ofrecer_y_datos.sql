-- ================================================================
-- 0022 · Avisos que se ofrecen al ocurrir el evento y "Pedir datos" (D-049)
--
-- Solo amplía reglas; no borra ni cambia registros.
--   · message_templates.mode: nuevo modo "ofrecer" (cuando ocurre el evento, el sistema
--     muestra el aviso listo para enviarlo con un toque). Las plantillas ya guardadas
--     conservan su modo.
--   · Nuevo mensaje "solicitar_datos": pide al cliente nombre, dirección, referencias y
--     ubicación por WhatsApp. No pertenece a una venta: se registra con el teléfono.
-- ================================================================

ALTER TABLE message_templates DROP CONSTRAINT message_templates_event_check;
ALTER TABLE message_templates ADD CONSTRAINT message_templates_event_check
  CHECK (event IN ('pedido_confirmado','en_preparacion','pedido_listo','en_camino','entregado','pago_confirmado','cancelado','solicitar_datos'));
ALTER TABLE message_templates DROP CONSTRAINT message_templates_mode_check;
ALTER TABLE message_templates ADD CONSTRAINT message_templates_mode_check
  CHECK (mode IN ('ofrecer','manual','desactivado'));

ALTER TABLE message_log DROP CONSTRAINT message_log_event_check;
ALTER TABLE message_log ADD CONSTRAINT message_log_event_check
  CHECK (event IN ('pedido_confirmado','en_preparacion','pedido_listo','en_camino','entregado','pago_confirmado','cancelado','solicitar_datos'));
ALTER TABLE message_log ALTER COLUMN sale_id DROP NOT NULL;
-- Los avisos de pedido siempre tienen venta; la solicitud de datos siempre tiene teléfono.
ALTER TABLE message_log ADD CONSTRAINT message_log_origen_check
  CHECK ((event = 'solicitar_datos' AND to_phone IS NOT NULL) OR (event <> 'solicitar_datos' AND sale_id IS NOT NULL));
CREATE INDEX message_log_phone_idx ON message_log (business_id, to_phone, created_at DESC) WHERE event = 'solicitar_datos';
