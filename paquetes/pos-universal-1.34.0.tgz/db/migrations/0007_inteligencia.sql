-- =====================================================================
-- 0007 · Inteligencia comercial (Fase 5)
--  * Devoluciones sin IVA y costo recuperado en los agregados, para que la
--    utilidad no cuente como ingreso lo que se devolvió.
--  * Aviso en tiempo real (NOTIFY) al confirmar operaciones: el tablero se
--    actualiza solo. NOTIFY se entrega únicamente si la transacción se confirma.
--  * Reconstrucción de agregados desde los registros originales (recuperación
--    ante fallos e importación de datos históricos).
-- =====================================================================

ALTER TABLE daily_sales_agg
  ADD COLUMN refunds_net  numeric(14,2) NOT NULL DEFAULT 0,   -- devoluciones sin impuestos
  ADD COLUMN refunds_cost numeric(14,4) NOT NULL DEFAULT 0;   -- costo de mercancía reingresada

CREATE FUNCTION app.notify_operation(p_branch uuid, p_kind text) RETURNS void
LANGUAGE sql AS
$$ SELECT pg_notify('pos_operaciones', app.current_business()::text || ':' || coalesce(p_branch::text, '') || ':' || p_kind) $$;

CREATE OR REPLACE FUNCTION app.aggregate_amount(p_branch uuid, p_at timestamptz, p_field text, p_amount numeric) RETURNS void
LANGUAGE plpgsql AS
$$
DECLARE
  d date := app.local_ts(p_branch, p_at)::date;
BEGIN
  IF p_field NOT IN ('refunds', 'refunds_net', 'refunds_cost', 'expenses', 'cost_of_goods') THEN
    RAISE EXCEPTION 'Campo no permitido: %', p_field;
  END IF;
  EXECUTE format(
    'INSERT INTO daily_sales_agg AS a (business_id, branch_id, day, %1$I) VALUES (app.current_business(), $1, $2, $3)
     ON CONFLICT (business_id, branch_id, day) DO UPDATE SET %1$I = a.%1$I + EXCLUDED.%1$I', p_field)
  USING p_branch, d, p_amount;
  PERFORM app.notify_operation(p_branch, p_field);
END
$$;

-- Registra una devolución completa en los agregados (bruto, neto sin impuestos y costo reingresado).
CREATE FUNCTION app.aggregate_refund(p_refund uuid, p_sign int) RETURNS void
LANGUAGE plpgsql AS
$$
DECLARE
  r record;
BEGIN
  SELECT s.branch_id, f.created_at, f.total,
         coalesce(sum(round(ri.amount * (si.line_total - si.tax_amount) / nullif(si.line_total, 0), 2)), 0) AS net,
         coalesce(sum(CASE WHEN ri.restock AND v.stock_item_id IS NOT NULL THEN round(ri.qty * si.unit_cost, 4) ELSE 0 END), 0) AS cost
    INTO r
    FROM refunds f JOIN sales s ON s.id = f.sale_id
    JOIN refund_items ri ON ri.refund_id = f.id
    JOIN sale_items si ON si.id = ri.sale_item_id
    JOIN product_variants v ON v.id = si.variant_id
   WHERE f.id = p_refund
   GROUP BY s.branch_id, f.created_at, f.total;
  IF NOT FOUND THEN RETURN; END IF;
  PERFORM app.aggregate_amount(r.branch_id, r.created_at, 'refunds', p_sign * r.total);
  PERFORM app.aggregate_amount(r.branch_id, r.created_at, 'refunds_net', p_sign * r.net);
  PERFORM app.aggregate_amount(r.branch_id, r.created_at, 'refunds_cost', p_sign * r.cost);
END
$$;

-- Añade el aviso a los agregados de ventas y pagos.
CREATE OR REPLACE FUNCTION app.aggregate_payment(p_payment uuid, p_sign int) RETURNS void
LANGUAGE plpgsql AS
$$
DECLARE
  pm payments%ROWTYPE;
  d date;
BEGIN
  SELECT * INTO pm FROM payments WHERE id = p_payment;
  PERFORM app.notify_operation(pm.branch_id, 'pago');
  IF pm.kind = 'propina' OR pm.method = 'saldo_cliente' THEN RETURN; END IF;
  d := app.local_ts(pm.branch_id, pm.created_at)::date;
  INSERT INTO daily_sales_agg AS a (business_id, branch_id, day, by_method)
  VALUES (pm.business_id, pm.branch_id, d, jsonb_build_object(pm.method, p_sign * pm.amount))
  ON CONFLICT (business_id, branch_id, day) DO UPDATE SET
    by_method = a.by_method || jsonb_build_object(pm.method,
                 coalesce((a.by_method ->> pm.method)::numeric, 0) + p_sign * pm.amount);
END
$$;

CREATE FUNCTION app.after_sale_close() RETURNS trigger
LANGUAGE plpgsql AS
$$ BEGIN PERFORM app.notify_operation(NEW.branch_id, 'venta'); RETURN NEW; END $$;
CREATE TRIGGER sales_notify AFTER UPDATE OF status ON sales
  FOR EACH ROW WHEN (OLD.status IS DISTINCT FROM NEW.status) EXECUTE FUNCTION app.after_sale_close();

-- Reconstruye los agregados del negocio actual para un rango de días locales.
CREATE FUNCTION app.rebuild_aggregates(p_from date, p_to date) RETURNS int
LANGUAGE plpgsql AS
$$
DECLARE
  x record;
  n int := 0;
BEGIN
  IF app.current_business() IS NULL THEN RAISE EXCEPTION 'Sin negocio en contexto'; END IF;
  DELETE FROM daily_sales_agg   WHERE day BETWEEN p_from AND p_to;
  DELETE FROM hourly_sales_agg  WHERE day BETWEEN p_from AND p_to;
  DELETE FROM daily_product_agg WHERE day BETWEEN p_from AND p_to;

  FOR x IN SELECT id FROM sales
            WHERE status IN ('pagada', 'credito', 'devuelta') AND closed_at IS NOT NULL
              AND app.local_ts(branch_id, closed_at)::date BETWEEN p_from AND p_to LOOP
    PERFORM app.aggregate_sale(x.id, 1); n := n + 1;
  END LOOP;
  FOR x IN SELECT id FROM payments
            WHERE voided_at IS NULL AND app.local_ts(branch_id, created_at)::date BETWEEN p_from AND p_to LOOP
    PERFORM app.aggregate_payment(x.id, 1);
  END LOOP;
  FOR x IN SELECT e.branch_id, e.paid_at, e.amount FROM expenses e JOIN expense_categories k ON k.id = e.category_id
            WHERE e.status <> 'anulado' AND NOT k.in_cost_of_goods
              AND app.local_ts(e.branch_id, e.paid_at)::date BETWEEN p_from AND p_to LOOP
    PERFORM app.aggregate_amount(x.branch_id, x.paid_at, 'expenses', x.amount);
  END LOOP;
  FOR x IN SELECT f.id FROM refunds f JOIN sales s ON s.id = f.sale_id
            WHERE app.local_ts(s.branch_id, f.created_at)::date BETWEEN p_from AND p_to LOOP
    PERFORM app.aggregate_refund(x.id, 1);
  END LOOP;
  RETURN n;
END
$$;
