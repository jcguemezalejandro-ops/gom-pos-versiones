-- ================================================================
-- 0029 · Revaluar el costo promedio al corregir una recepción (D-064)
--
-- El costo promedio solo lo escribe el trigger de movimientos (0004): la API no tiene
-- permiso sobre esa columna. Corregir el costo de una compra ya recibida cambia el valor
-- del inventario sin cambiar la cantidad, y un movimiento no puede tener cantidad 0.
-- Esta función, del dueño del esquema, suma una diferencia de valor a un insumo del
-- negocio actual y nada más. Si no hay existencia, el costo queda en p_sin_existencia.
-- No modifica datos existentes.
-- ================================================================

CREATE FUNCTION app.revaluar_insumo(p_insumo uuid, p_valor numeric, p_sin_existencia numeric) RETURNS numeric
  LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, app AS
$$
DECLARE
  q numeric;
  r numeric;
BEGIN
  IF app.current_business() IS NULL THEN RAISE EXCEPTION 'Sin negocio activo'; END IF;
  SELECT coalesce(sum(qty), 0) INTO q FROM stock_levels
   WHERE stock_item_id = p_insumo AND business_id = app.current_business();
  UPDATE stock_items
     SET avg_cost = CASE WHEN q <= 0 THEN greatest(0, p_sin_existencia)
                         ELSE greatest(0, round((q * avg_cost + p_valor) / q, 4)) END
   WHERE id = p_insumo AND business_id = app.current_business()
   RETURNING avg_cost INTO r;
  IF r IS NULL THEN RAISE EXCEPTION 'Insumo no encontrado'; END IF;
  RETURN r;
END
$$;
REVOKE EXECUTE ON FUNCTION app.revaluar_insumo(uuid, numeric, numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.revaluar_insumo(uuid, numeric, numeric) TO pos_app;
