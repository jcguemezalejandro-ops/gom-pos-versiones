-- =====================================================================
-- 0005 · Autenticación, sesiones y administración segura de usuarios
--
-- Algunas operaciones ocurren antes de conocer el negocio (iniciar sesión,
-- validar una cookie). Se resuelven con funciones SECURITY DEFINER pequeñas
-- y de propósito único; la API no obtiene acceso general a las tablas.
-- =====================================================================

ALTER TABLE users
  ADD COLUMN must_change_password boolean NOT NULL DEFAULT false,
  ADD COLUMN recovery_hash text;          -- código de recuperación (hash), se muestra una sola vez

-- Desde el contexto de un negocio, los usuarios de ese negocio solo se LEEN.
-- Los cambios a usuarios de otros pasan por funciones con reglas explícitas.
DROP POLICY users_same_business ON users;
CREATE POLICY users_same_business ON users FOR SELECT
  USING (EXISTS (SELECT 1 FROM memberships m
                 WHERE m.user_id = users.id AND m.business_id = app.current_business()));

-- ---------------------------------------------------------------------
-- Inicio de sesión
-- ---------------------------------------------------------------------

CREATE FUNCTION app.auth_lookup(p_login text)
RETURNS TABLE (id uuid, password_hash text, is_active boolean, locked_until timestamptz, must_change_password boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$
  SELECT u.id, u.password_hash, u.is_active, u.locked_until, u.must_change_password
    FROM users u
   WHERE lower(u.username) = lower(trim(p_login))
      OR (u.email IS NOT NULL AND lower(u.email) = lower(trim(p_login)))
   LIMIT 1
$$;

-- Registra el resultado de un intento. 5 fallos seguidos bloquean 15 minutos.
CREATE FUNCTION app.auth_register_attempt(p_user uuid, p_ok boolean) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  IF p_ok THEN
    UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = now() WHERE id = p_user;
  ELSE
    UPDATE users
       SET failed_attempts = failed_attempts + 1,
           locked_until = CASE WHEN failed_attempts + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END
     WHERE id = p_user;
  END IF;
END
$$;

-- Valida el token de una cookie (por su hash) y renueva la actividad.
-- Devuelve vacío si no existe, está revocada o expiró (absoluto o por inactividad).
CREATE FUNCTION app.auth_session(p_token_hash text, p_idle_minutes int)
RETURNS TABLE (user_id uuid, business_id uuid, branch_id uuid, must_change_password boolean)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  RETURN QUERY
  UPDATE sessions s SET last_seen_at = now()
    FROM users u
   WHERE s.token_hash = p_token_hash
     AND u.id = s.user_id AND u.is_active
     AND s.revoked_at IS NULL
     AND s.expires_at > now()
     AND s.last_seen_at > now() - make_interval(mins => p_idle_minutes)
  RETURNING s.user_id, s.business_id, s.branch_id, u.must_change_password;
END
$$;

-- Recuperación con código: valida en la API (hash argon2) y aquí solo se aplica.
CREATE FUNCTION app.auth_recovery_lookup(p_login text)
RETURNS TABLE (id uuid, recovery_hash text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$
  SELECT u.id, u.recovery_hash FROM users u
   WHERE (lower(u.username) = lower(trim(p_login)) OR lower(u.email) = lower(trim(p_login)))
     AND u.is_active AND u.recovery_hash IS NOT NULL
   LIMIT 1
$$;

CREATE FUNCTION app.auth_recover(p_user uuid, p_new_hash text, p_new_recovery_hash text) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  UPDATE users SET password_hash = p_new_hash, recovery_hash = p_new_recovery_hash,
                   password_changed_at = now(), must_change_password = false,
                   failed_attempts = 0, locked_until = NULL
   WHERE id = p_user;
  UPDATE sessions SET revoked_at = now() WHERE user_id = p_user AND revoked_at IS NULL;
END
$$;

-- ¿Existe ya algún negocio? (modo "primer uso" de un servidor local)
CREATE FUNCTION app.platform_has_businesses() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$ SELECT EXISTS (SELECT 1 FROM businesses) $$;

-- ---------------------------------------------------------------------
-- Administración de usuarios desde un negocio (requieren app.business_id)
-- ---------------------------------------------------------------------

-- Restablece la contraseña de un usuario del negocio actual. Si la persona
-- también pertenece a otro negocio, se rechaza: un negocio no puede cambiar
-- el acceso que una persona tiene en otro.
CREATE FUNCTION app.admin_reset_password(p_user uuid, p_new_hash text) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, app AS
$$
DECLARE
  biz uuid := app.current_business();
BEGIN
  IF biz IS NULL THEN RAISE EXCEPTION 'Sin negocio en contexto' USING ERRCODE = 'insufficient_privilege'; END IF;
  IF NOT EXISTS (SELECT 1 FROM memberships WHERE user_id = p_user AND business_id = biz) THEN
    RAISE EXCEPTION 'El usuario no pertenece a este negocio' USING ERRCODE = 'insufficient_privilege';
  END IF;
  IF EXISTS (SELECT 1 FROM memberships WHERE user_id = p_user AND business_id <> biz) THEN
    RAISE EXCEPTION 'El usuario también trabaja en otro negocio: debe cambiar su contraseña él mismo'
      USING ERRCODE = 'insufficient_privilege';
  END IF;
  UPDATE users SET password_hash = p_new_hash, must_change_password = true, password_changed_at = now(),
                   failed_attempts = 0, locked_until = NULL
   WHERE id = p_user;
  UPDATE sessions SET revoked_at = now() WHERE user_id = p_user AND revoked_at IS NULL;
END
$$;

-- Cierra las sesiones de un usuario del negocio actual (solo las de este negocio).
CREATE FUNCTION app.admin_revoke_sessions(p_user uuid) RETURNS int
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, app AS
$$
DECLARE
  biz uuid := app.current_business();
  n int;
BEGIN
  IF biz IS NULL OR NOT EXISTS (SELECT 1 FROM memberships WHERE user_id = p_user AND business_id = biz) THEN
    RAISE EXCEPTION 'El usuario no pertenece a este negocio' USING ERRCODE = 'insufficient_privilege';
  END IF;
  UPDATE sessions SET revoked_at = now()
   WHERE user_id = p_user AND business_id = biz AND revoked_at IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END
$$;

-- Cambia nombre/correo/activo de un usuario del negocio actual (mismas reglas).
CREATE FUNCTION app.admin_update_user(p_user uuid, p_full_name text, p_email text) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, app AS
$$
DECLARE
  biz uuid := app.current_business();
BEGIN
  IF biz IS NULL OR NOT EXISTS (SELECT 1 FROM memberships WHERE user_id = p_user AND business_id = biz) THEN
    RAISE EXCEPTION 'El usuario no pertenece a este negocio' USING ERRCODE = 'insufficient_privilege';
  END IF;
  IF EXISTS (SELECT 1 FROM memberships WHERE user_id = p_user AND business_id <> biz) THEN
    RAISE EXCEPTION 'El usuario también trabaja en otro negocio: debe actualizar sus datos él mismo'
      USING ERRCODE = 'insufficient_privilege';
  END IF;
  UPDATE users SET full_name = coalesce(p_full_name, full_name), email = p_email WHERE id = p_user;
END
$$;

-- Datos básicos de los negocios y roles de las membresías propias (para elegir
-- negocio al iniciar sesión, cuando aún no hay negocio en contexto).
CREATE FUNCTION app.business_summary(p_business uuid)
RETURNS TABLE (slug text, trade_name text, business_type text, status text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$
  SELECT b.slug, b.trade_name, b.business_type, b.status FROM businesses b
   WHERE b.id = p_business
     AND EXISTS (SELECT 1 FROM memberships m WHERE m.business_id = b.id AND m.user_id = app.current_user_id())
$$;

CREATE FUNCTION app.role_summary(p_business uuid, p_role uuid)
RETURNS TABLE (name text, is_system boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$
  SELECT r.name, r.is_system FROM roles r
   WHERE r.id = p_role AND r.business_id = p_business
     AND EXISTS (SELECT 1 FROM memberships m WHERE m.business_id = p_business AND m.user_id = app.current_user_id())
$$;

-- ¿Existe ya ese nombre de usuario en la plataforma? (para avisar antes de crear)
CREATE FUNCTION app.username_taken(p_username text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$ SELECT EXISTS (SELECT 1 FROM users WHERE lower(username) = lower(trim(p_username))) $$;

-- Solo la API puede llamar estas funciones.
DO $$
DECLARE f text;
BEGIN
  FOREACH f IN ARRAY ARRAY[
    'app.auth_lookup(text)', 'app.auth_register_attempt(uuid, boolean)', 'app.auth_session(text, int)',
    'app.auth_recovery_lookup(text)', 'app.auth_recover(uuid, text, text)', 'app.platform_has_businesses()',
    'app.admin_reset_password(uuid, text)', 'app.admin_revoke_sessions(uuid)',
    'app.admin_update_user(uuid, text, text)', 'app.username_taken(text)',
    'app.business_summary(uuid)', 'app.role_summary(uuid, uuid)']
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO pos_app', f);
  END LOOP;
END $$;

-- La API puede actualizar solo estas columnas de su propio usuario (users_self).
REVOKE UPDATE ON users FROM pos_app;
GRANT UPDATE (full_name, email, password_hash, password_changed_at, must_change_password, recovery_hash) ON users TO pos_app;

CREATE INDEX sessions_business_idx ON sessions (business_id, user_id) WHERE revoked_at IS NULL;
