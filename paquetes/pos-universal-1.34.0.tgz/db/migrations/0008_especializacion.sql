-- =====================================================================
-- 0008 · Especialización por giro e importación (Fase 6)
--  * Unidades usadas por negocios de comida (bote, bolsa).
--  * Gastos programados: gastos fijos (renta, internet) y nómina con
--    vencimientos; al pagarse generan un egreso normal.
--  * Documentos heredados: copia íntegra de lo importado de otro sistema,
--    incluso lo que no tiene equivalente (nada se pierde en una migración).
-- =====================================================================

INSERT INTO units (code, name, dimension, factor_to_base, allows_decimals) VALUES
  ('bote',  'Bote',  'unidad', 1, false),
  ('bolsa', 'Bolsa', 'unidad', 1, false),
  ('orden', 'Orden', 'unidad', 1, false);

INSERT INTO modules (key, name, description, is_core, depends_on, sort_order) VALUES
  ('programados', 'Gastos programados', 'Gastos fijos y nómina con vencimientos', false, '{egresos}', 75);
INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('programados.gestionar', 'programados', 'Crear, editar y pagar gastos fijos y nómina', true);

CREATE TABLE scheduled_expenses (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id     uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  branch_id       uuid,
  kind            text NOT NULL CHECK (kind IN ('fijo', 'nomina')),
  name            text NOT NULL,                  -- "Renta", "Internet" o el nombre del empleado
  position        text,                           -- puesto (nómina)
  category_id     uuid NOT NULL,
  amount          numeric(14,2) NOT NULL CHECK (amount > 0),
  frequency       text NOT NULL CHECK (frequency IN ('semanal', 'quincenal', 'mensual', 'bimestral', 'trimestral', 'anual')),
  next_due        date NOT NULL,
  method          text NOT NULL DEFAULT 'transferencia' CHECK (method IN ('efectivo','tarjeta','transferencia','otro')),
  responsible_id  uuid REFERENCES users(id),
  responsible     text,
  notes           text NOT NULL DEFAULT '',
  is_active       boolean NOT NULL DEFAULT true,
  created_by      uuid REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, category_id) REFERENCES expense_categories(business_id, id)
);
CREATE INDEX scheduled_expenses_due_idx ON scheduled_expenses (business_id, next_due) WHERE is_active;
SELECT app.enable_tenant_rls('scheduled_expenses');

ALTER TABLE expenses ADD COLUMN scheduled_id uuid;
ALTER TABLE expenses ADD CONSTRAINT expenses_scheduled_fk FOREIGN KEY (business_id, scheduled_id) REFERENCES scheduled_expenses(business_id, id);

CREATE TABLE legacy_documents (
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  source       text NOT NULL,          -- p. ej. "pos-gomtm"
  collection   text NOT NULL,
  doc_id       text NOT NULL,
  data         jsonb NOT NULL,
  mapped_to    text,                   -- tabla/registro del sistema nuevo, si se convirtió
  note         text,                   -- por qué no se convirtió, o qué se ajustó
  imported_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, source, collection, doc_id)
);
SELECT app.enable_tenant_rls('legacy_documents');

GRANT SELECT, INSERT, UPDATE, DELETE ON scheduled_expenses TO pos_app;
GRANT SELECT, INSERT ON legacy_documents TO pos_app;

-- La importación registra la bitácora histórica con su fecha original.
-- (audit_log.at ya admite valor explícito; no se requiere cambio.)
