-- =====================================================================
-- 0001 · Núcleo multinegocio
-- Negocios, sucursales, usuarios, roles, permisos, módulos, configuración,
-- folios y auditoría. Define el mecanismo de aislamiento por negocio (RLS).
--
-- Convenciones de todo el esquema:
--   * Cada tabla de un negocio lleva business_id NOT NULL y RLS forzado.
--   * Las referencias entre tablas de negocio son llaves compuestas
--     (business_id, id): es imposible ligar un registro con el de otro negocio.
--   * Dinero NUMERIC(14,2); costos unitarios NUMERIC(14,4); cantidades NUMERIC(14,3).
--   * Fechas con zona horaria (timestamptz).
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;

CREATE SCHEMA IF NOT EXISTS app;

-- Contexto de la petición. La API fija estos valores con SET LOCAL al inicio
-- de cada transacción. Si no están fijados devuelven NULL y las políticas RLS
-- no dejan ver nada (falla cerrada).
CREATE FUNCTION app.current_business() RETURNS uuid
  LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('app.business_id', true), '')::uuid $$;

CREATE FUNCTION app.current_user_id() RETURNS uuid
  LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('app.user_id', true), '')::uuid $$;

-- Normalización para búsquedas sin acentos ni mayúsculas.
CREATE FUNCTION app.normalize(t text) RETURNS text
  LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT lower(public.unaccent('public.unaccent'::regdictionary, coalesce(t, ''))) $$;

CREATE FUNCTION app.touch_updated_at() RETURNS trigger
  LANGUAGE plpgsql AS
$$ BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

-- Activa el aislamiento estándar por negocio en una tabla.
CREATE FUNCTION app.enable_tenant_rls(tbl regclass) RETURNS void
  LANGUAGE plpgsql AS
$$
BEGIN
  EXECUTE format('ALTER TABLE %s ENABLE ROW LEVEL SECURITY', tbl);
  EXECUTE format('ALTER TABLE %s FORCE ROW LEVEL SECURITY', tbl);
  EXECUTE format(
    'CREATE POLICY tenant_isolation ON %s USING (business_id = app.current_business()) WITH CHECK (business_id = app.current_business())',
    tbl);
END
$$;

-- Bloquea UPDATE/DELETE en tablas de solo inserción (bitácoras y libros).
CREATE FUNCTION app.forbid_change() RETURNS trigger
  LANGUAGE plpgsql AS
$$ BEGIN RAISE EXCEPTION 'La tabla % es de solo inserción: registre un movimiento compensatorio', TG_TABLE_NAME
     USING ERRCODE = 'insufficient_privilege'; END $$;

-- ---------------------------------------------------------------------
-- Catálogos globales (iguales para todos los negocios, solo lectura para la API)
-- ---------------------------------------------------------------------

CREATE TABLE business_types (
  key          text PRIMARY KEY,
  name         text NOT NULL,
  description  text NOT NULL DEFAULT ''
);

CREATE TABLE modules (
  key          text PRIMARY KEY,
  name         text NOT NULL,
  description  text NOT NULL DEFAULT '',
  is_core      boolean NOT NULL DEFAULT false,   -- el núcleo no se puede apagar
  depends_on   text[] NOT NULL DEFAULT '{}',
  sort_order   int NOT NULL DEFAULT 0
);

CREATE TABLE permissions (
  key          text PRIMARY KEY CHECK (key ~ '^[a-z_]+\.[a-z_]+$'),
  module_key   text NOT NULL REFERENCES modules(key),
  description  text NOT NULL,
  is_sensitive boolean NOT NULL DEFAULT false    -- requiere autorización registrada
);

-- ---------------------------------------------------------------------
-- Negocios y sucursales
-- ---------------------------------------------------------------------

CREATE TABLE businesses (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug           text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9][a-z0-9-]{2,59}$'),
  trade_name     text NOT NULL CHECK (length(trim(trade_name)) > 0),
  legal_name     text,
  business_type  text NOT NULL REFERENCES business_types(key),
  currency       char(3) NOT NULL DEFAULT 'MXN',
  timezone       text NOT NULL DEFAULT 'America/Mexico_City',
  locale         text NOT NULL DEFAULT 'es-MX',
  phone          text,
  address        jsonb NOT NULL DEFAULT '{}',
  tax_id         text,
  fiscal_data    jsonb NOT NULL DEFAULT '{}',   -- facturación: pendiente (ver docs)
  logo_asset     text,
  theme          jsonb NOT NULL DEFAULT '{}',
  status         text NOT NULL DEFAULT 'activo' CHECK (status IN ('activo','suspendido','baja')),
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER businesses_touch BEFORE UPDATE ON businesses
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE businesses FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON businesses
  USING (id = app.current_business()) WITH CHECK (id = app.current_business());

CREATE TABLE branches (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  code           text NOT NULL CHECK (code ~ '^[A-Za-z0-9_-]{1,20}$'),
  name           text NOT NULL,
  phone          text,
  address        jsonb NOT NULL DEFAULT '{}',
  timezone       text,                           -- NULL = la del negocio
  opening_hours  jsonb NOT NULL DEFAULT '{}',    -- {"lun":[["08:00","22:00"]], ...}
  is_active      boolean NOT NULL DEFAULT true,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, code)
);
CREATE TRIGGER branches_touch BEFORE UPDATE ON branches
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
SELECT app.enable_tenant_rls('branches');

-- ---------------------------------------------------------------------
-- Usuarios (globales: una persona puede trabajar en varios negocios)
-- ---------------------------------------------------------------------

CREATE TABLE users (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email                text,
  username             text NOT NULL,
  full_name            text NOT NULL,
  password_hash        text NOT NULL,          -- argon2id / scrypt, nunca texto plano
  is_active            boolean NOT NULL DEFAULT true,
  failed_attempts      int NOT NULL DEFAULT 0,
  locked_until         timestamptz,
  password_changed_at  timestamptz NOT NULL DEFAULT now(),
  last_login_at        timestamptz,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_username_uq ON users (lower(username));
CREATE UNIQUE INDEX users_email_uq ON users (lower(email)) WHERE email IS NOT NULL;
CREATE TRIGGER users_touch BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

-- ---------------------------------------------------------------------
-- Roles, permisos y membresías
-- ---------------------------------------------------------------------

CREATE TABLE roles (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  key          text NOT NULL CHECK (key ~ '^[a-z0-9_]{2,40}$'),
  name         text NOT NULL,
  description  text NOT NULL DEFAULT '',
  is_system    boolean NOT NULL DEFAULT false,  -- propietario: no se borra ni pierde permisos
  rank         int NOT NULL DEFAULT 100,        -- menor = más autoridad (para autorizaciones)
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, key)
);
SELECT app.enable_tenant_rls('roles');

CREATE TABLE role_permissions (
  business_id     uuid NOT NULL,
  role_id         uuid NOT NULL,
  permission_key  text NOT NULL REFERENCES permissions(key),
  PRIMARY KEY (role_id, permission_key),
  FOREIGN KEY (business_id, role_id) REFERENCES roles(business_id, id) ON DELETE CASCADE
);
SELECT app.enable_tenant_rls('role_permissions');

CREATE TABLE memberships (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id         uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id             uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id             uuid NOT NULL,
  pin_hash            text,                    -- PIN corto para autorizar en caja
  branch_ids          uuid[],                  -- NULL = todas las sucursales
  extra_permissions   text[] NOT NULL DEFAULT '{}',
  denied_permissions  text[] NOT NULL DEFAULT '{}',
  is_active           boolean NOT NULL DEFAULT true,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, user_id),
  FOREIGN KEY (business_id, role_id) REFERENCES roles(business_id, id)
);
CREATE INDEX memberships_user_idx ON memberships (user_id);
CREATE TRIGGER memberships_touch BEFORE UPDATE ON memberships
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON memberships
  USING (business_id = app.current_business()) WITH CHECK (business_id = app.current_business());
-- Un usuario puede ver (solo leer) sus propias membresías para elegir negocio.
CREATE POLICY own_memberships_read ON memberships FOR SELECT
  USING (user_id = app.current_user_id());

-- Usuarios: visibles para sí mismos o para los negocios donde son miembros.
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE users FORCE ROW LEVEL SECURITY;
CREATE POLICY users_self ON users
  USING (id = app.current_user_id());
CREATE POLICY users_same_business ON users
  USING (EXISTS (SELECT 1 FROM memberships m
                 WHERE m.user_id = users.id AND m.business_id = app.current_business()));
-- Alta de usuarios: solo dentro de un negocio fijado en el contexto.
CREATE POLICY users_insert ON users FOR INSERT
  WITH CHECK (app.current_business() IS NOT NULL);

-- Sesiones (el token nunca se guarda: solo su hash SHA-256).
CREATE TABLE sessions (
  token_hash    text PRIMARY KEY,
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id   uuid REFERENCES businesses(id) ON DELETE CASCADE,
  branch_id     uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_seen_at  timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz NOT NULL,
  revoked_at    timestamptz,
  ip            inet,
  user_agent    text
);
CREATE INDEX sessions_user_idx ON sessions (user_id) WHERE revoked_at IS NULL;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions FORCE ROW LEVEL SECURITY;
CREATE POLICY sessions_own ON sessions
  USING (user_id = app.current_user_id()) WITH CHECK (user_id = app.current_user_id());

-- ---------------------------------------------------------------------
-- Configuración y módulos por negocio
-- ---------------------------------------------------------------------

CREATE TABLE business_settings (
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  key          text NOT NULL CHECK (key ~ '^[a-z_]+(\.[a-z_]+)*$'),
  value        jsonb NOT NULL,
  updated_by   uuid REFERENCES users(id),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, key)
);
SELECT app.enable_tenant_rls('business_settings');

CREATE TABLE business_modules (
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  module_key   text NOT NULL REFERENCES modules(key),
  enabled      boolean NOT NULL DEFAULT true,
  config       jsonb NOT NULL DEFAULT '{}',
  updated_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, module_key)
);
SELECT app.enable_tenant_rls('business_modules');

-- ---------------------------------------------------------------------
-- Folios: secuencias por negocio, tipo de documento y serie.
-- El UPSERT bloquea la fila: dos cajas a la vez nunca obtienen el mismo folio.
-- ---------------------------------------------------------------------

CREATE TABLE document_sequences (
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  doc_type     text NOT NULL,          -- venta, compra, corte, devolucion, gasto...
  series       text NOT NULL DEFAULT '',
  last_value   bigint NOT NULL DEFAULT 0 CHECK (last_value >= 0),
  PRIMARY KEY (business_id, doc_type, series)
);
SELECT app.enable_tenant_rls('document_sequences');

CREATE FUNCTION app.next_folio(p_doc_type text, p_series text DEFAULT '') RETURNS bigint
  LANGUAGE sql VOLATILE AS
$$
  INSERT INTO document_sequences AS s (business_id, doc_type, series, last_value)
  VALUES (app.current_business(), p_doc_type, coalesce(p_series, ''), 1)
  ON CONFLICT (business_id, doc_type, series)
  DO UPDATE SET last_value = s.last_value + 1
  RETURNING last_value
$$;

-- ---------------------------------------------------------------------
-- Auditoría: solo inserción. Ni la API ni el dueño de las tablas pueden
-- modificar o borrar registros (trigger), y la API no tiene UPDATE/DELETE.
-- ---------------------------------------------------------------------

CREATE TABLE audit_log (
  id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  business_id    uuid NOT NULL REFERENCES businesses(id) ON DELETE RESTRICT,
  branch_id      uuid,
  user_id        uuid REFERENCES users(id),
  action         text NOT NULL,          -- ej. venta.cancelar, caja.corte, usuario.permisos
  entity         text NOT NULL,
  entity_id      text,
  before         jsonb,
  after          jsonb,
  reason         text,
  authorized_by  uuid REFERENCES users(id),
  ip             inet,
  at             timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_log_business_at_idx ON audit_log (business_id, at DESC);
CREATE INDEX audit_log_entity_idx ON audit_log (business_id, entity, entity_id);
CREATE TRIGGER audit_log_append_only BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
SELECT app.enable_tenant_rls('audit_log');
