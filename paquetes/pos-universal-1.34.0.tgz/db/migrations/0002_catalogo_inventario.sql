-- =====================================================================
-- 0002 · Catálogo e inventario
-- Productos con variantes (talla/color/tamaño), unidades (pieza, kg, litro),
-- precios por volumen, modificadores, recetas, existencias por sucursal,
-- lotes con caducidad, movimientos (libro de solo inserción), proveedores
-- y compras.
-- =====================================================================

-- Unidades de medida (catálogo global).
CREATE TABLE units (
  code            text PRIMARY KEY,
  name            text NOT NULL,
  dimension       text NOT NULL CHECK (dimension IN ('unidad','masa','volumen','longitud','tiempo')),
  factor_to_base  numeric(14,6) NOT NULL CHECK (factor_to_base > 0),  -- base: pz, kg, l, m, h
  allows_decimals boolean NOT NULL DEFAULT false
);

CREATE TABLE tax_rates (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name         text NOT NULL,
  rate         numeric(7,4) NOT NULL CHECK (rate >= 0 AND rate < 1),  -- 0.1600 = 16 %
  is_included  boolean NOT NULL DEFAULT true,   -- el precio ya incluye el impuesto
  is_default   boolean NOT NULL DEFAULT false,
  is_active    boolean NOT NULL DEFAULT true,
  UNIQUE (business_id, id)
);
CREATE UNIQUE INDEX tax_rates_default_uq ON tax_rates (business_id) WHERE is_default;
SELECT app.enable_tenant_rls('tax_rates');

CREATE TABLE categories (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  parent_id    uuid,
  name         text NOT NULL,
  color        text,
  icon         text,
  sort_order   int NOT NULL DEFAULT 0,
  is_active    boolean NOT NULL DEFAULT true,
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, parent_id) REFERENCES categories(business_id, id)
);
CREATE INDEX categories_business_idx ON categories (business_id, sort_order);
SELECT app.enable_tenant_rls('categories');

-- Artículo con existencias: mercancía de reventa, ingrediente o materia prima.
CREATE TABLE stock_items (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name          text NOT NULL,
  kind          text NOT NULL CHECK (kind IN ('mercancia','ingrediente','materia_prima','empaque')),
  unit_code     text NOT NULL REFERENCES units(code),
  sku           text,
  min_stock     numeric(14,3) NOT NULL DEFAULT 0 CHECK (min_stock >= 0),
  reorder_qty   numeric(14,3) NOT NULL DEFAULT 0 CHECK (reorder_qty >= 0),
  tracks_lots   boolean NOT NULL DEFAULT false,
  is_perishable boolean NOT NULL DEFAULT false,   -- caducidad / vida útil (florería, abarrotes)
  shelf_life_days int CHECK (shelf_life_days > 0),
  avg_cost      numeric(14,4) NOT NULL DEFAULT 0 CHECK (avg_cost >= 0),
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id)
);
CREATE INDEX stock_items_name_idx ON stock_items USING gin (app.normalize(name) gin_trgm_ops);
SELECT app.enable_tenant_rls('stock_items');

CREATE TABLE products (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  category_id    uuid,
  kind           text NOT NULL DEFAULT 'simple'
                 CHECK (kind IN ('simple','variantes','preparado','servicio','combo','personalizado')),
  name           text NOT NULL CHECK (length(trim(name)) > 0),
  description    text NOT NULL DEFAULT '',
  unit_code      text NOT NULL DEFAULT 'pz' REFERENCES units(code),
  tax_rate_id    uuid,
  image_asset    text,
  attributes     jsonb NOT NULL DEFAULT '{}',   -- campos propios del giro (tipo de flor, marca...)
  variant_axes   text[] NOT NULL DEFAULT '{}',  -- p. ej. {talla,color}
  sends_to_kitchen boolean NOT NULL DEFAULT false,
  is_active      boolean NOT NULL DEFAULT true,
  sort_order     int NOT NULL DEFAULT 0,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, category_id) REFERENCES categories(business_id, id),
  FOREIGN KEY (business_id, tax_rate_id) REFERENCES tax_rates(business_id, id)
);
CREATE INDEX products_category_idx ON products (business_id, category_id, sort_order) WHERE is_active;
CREATE INDEX products_name_idx ON products USING gin (app.normalize(name) gin_trgm_ops);
CREATE TRIGGER products_touch BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
SELECT app.enable_tenant_rls('products');

-- Toda venta se hace sobre una variante. Un producto sin variantes tiene una
-- variante "predeterminada".
CREATE TABLE product_variants (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  product_id     uuid NOT NULL,
  name           text NOT NULL DEFAULT '',      -- "M / Rojo", "Grande", "" para la predeterminada
  options        jsonb NOT NULL DEFAULT '{}',   -- {"talla":"M","color":"Rojo"}
  sku            text,
  barcode        text,
  price          numeric(14,2) NOT NULL CHECK (price >= 0),
  cost           numeric(14,4) NOT NULL DEFAULT 0 CHECK (cost >= 0),  -- costo manual si no hay receta/stock
  stock_item_id  uuid,                          -- existencias propias (mercancía)
  is_default     boolean NOT NULL DEFAULT false,
  is_active      boolean NOT NULL DEFAULT true,
  sort_order     int NOT NULL DEFAULT 0,
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, product_id) REFERENCES products(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id)
);
CREATE UNIQUE INDEX product_variants_barcode_uq ON product_variants (business_id, barcode) WHERE barcode IS NOT NULL;
CREATE UNIQUE INDEX product_variants_sku_uq ON product_variants (business_id, lower(sku)) WHERE sku IS NOT NULL;
CREATE UNIQUE INDEX product_variants_default_uq ON product_variants (product_id) WHERE is_default;
CREATE INDEX product_variants_product_idx ON product_variants (business_id, product_id);
SELECT app.enable_tenant_rls('product_variants');

-- Precios por volumen (mayoreo / menudeo).
CREATE TABLE price_tiers (
  business_id  uuid NOT NULL,
  variant_id   uuid NOT NULL,
  min_qty      numeric(14,3) NOT NULL CHECK (min_qty > 0),
  price        numeric(14,2) NOT NULL CHECK (price >= 0),
  label        text NOT NULL DEFAULT 'mayoreo',
  PRIMARY KEY (variant_id, min_qty),
  FOREIGN KEY (business_id, variant_id) REFERENCES product_variants(business_id, id) ON DELETE CASCADE
);
SELECT app.enable_tenant_rls('price_tiers');

-- Modificadores y complementos (extra queso, sin cebolla, tipo de leche...).
CREATE TABLE modifier_groups (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name         text NOT NULL,
  min_select   int NOT NULL DEFAULT 0 CHECK (min_select >= 0),
  max_select   int CHECK (max_select IS NULL OR max_select >= min_select),
  UNIQUE (business_id, id)
);
SELECT app.enable_tenant_rls('modifier_groups');

CREATE TABLE modifiers (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  group_id       uuid NOT NULL,
  name           text NOT NULL,
  price_delta    numeric(14,2) NOT NULL DEFAULT 0,
  stock_item_id  uuid,
  stock_qty      numeric(14,4) NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
  is_active      boolean NOT NULL DEFAULT true,
  sort_order     int NOT NULL DEFAULT 0,
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, group_id) REFERENCES modifier_groups(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id)
);
SELECT app.enable_tenant_rls('modifiers');

CREATE TABLE product_modifier_groups (
  business_id  uuid NOT NULL,
  product_id   uuid NOT NULL,
  group_id     uuid NOT NULL,
  sort_order   int NOT NULL DEFAULT 0,
  PRIMARY KEY (product_id, group_id),
  FOREIGN KEY (business_id, product_id) REFERENCES products(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, group_id) REFERENCES modifier_groups(business_id, id) ON DELETE CASCADE
);
SELECT app.enable_tenant_rls('product_modifier_groups');

-- Recetas: insumos que consume una variante al venderse (con % de merma).
CREATE TABLE recipe_items (
  business_id    uuid NOT NULL,
  variant_id     uuid NOT NULL,
  stock_item_id  uuid NOT NULL,
  qty            numeric(14,4) NOT NULL CHECK (qty > 0),
  waste_pct      numeric(5,2) NOT NULL DEFAULT 0 CHECK (waste_pct >= 0 AND waste_pct < 100),
  PRIMARY KEY (variant_id, stock_item_id),
  FOREIGN KEY (business_id, variant_id) REFERENCES product_variants(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id)
);
SELECT app.enable_tenant_rls('recipe_items');

-- Existencias actuales por sucursal. Las mantiene el trigger de movimientos;
-- la API nunca las edita directamente.
CREATE TABLE stock_levels (
  business_id    uuid NOT NULL,
  branch_id      uuid NOT NULL,
  stock_item_id  uuid NOT NULL,
  qty            numeric(14,3) NOT NULL DEFAULT 0,
  updated_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (branch_id, stock_item_id),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id)
);
CREATE INDEX stock_levels_item_idx ON stock_levels (business_id, stock_item_id);
SELECT app.enable_tenant_rls('stock_levels');

CREATE TABLE stock_lots (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id     uuid NOT NULL,
  branch_id       uuid NOT NULL,
  stock_item_id   uuid NOT NULL,
  lot_code        text,
  expires_on      date,
  qty_remaining   numeric(14,3) NOT NULL DEFAULT 0 CHECK (qty_remaining >= 0),
  received_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id)
);
CREATE INDEX stock_lots_expiry_idx ON stock_lots (business_id, expires_on) WHERE qty_remaining > 0;
SELECT app.enable_tenant_rls('stock_lots');

-- Libro de movimientos de inventario (solo inserción). qty con signo:
-- positivo entra, negativo sale. Las correcciones son movimientos nuevos.
CREATE TABLE stock_movements (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL,
  branch_id      uuid NOT NULL,
  stock_item_id  uuid NOT NULL,
  lot_id         uuid,
  kind           text NOT NULL CHECK (kind IN ('compra','venta','devolucion','ajuste','merma',
                                               'traspaso_entrada','traspaso_salida','reversion','inicial','produccion')),
  qty            numeric(14,3) NOT NULL CHECK (qty <> 0),
  unit_cost      numeric(14,4) CHECK (unit_cost >= 0),
  reason         text,
  ref_type       text,           -- venta, compra, conteo...
  ref_id         uuid,
  user_id        uuid REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id),
  FOREIGN KEY (business_id, lot_id) REFERENCES stock_lots(business_id, id)
);
CREATE INDEX stock_movements_item_idx ON stock_movements (business_id, stock_item_id, created_at DESC);
CREATE INDEX stock_movements_ref_idx ON stock_movements (business_id, ref_type, ref_id);
CREATE TRIGGER stock_movements_append_only BEFORE UPDATE OR DELETE ON stock_movements
  FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
SELECT app.enable_tenant_rls('stock_movements');

-- Aplica cada movimiento: existencias por sucursal y costo promedio ponderado.
CREATE FUNCTION app.apply_stock_movement() RETURNS trigger
  LANGUAGE plpgsql AS
$$
DECLARE
  total_before numeric;
BEGIN
  IF NEW.qty > 0 AND NEW.unit_cost IS NOT NULL AND NEW.kind IN ('compra','inicial','ajuste','produccion') THEN
    SELECT coalesce(sum(qty), 0) INTO total_before
      FROM stock_levels WHERE stock_item_id = NEW.stock_item_id;
    UPDATE stock_items
       SET avg_cost = CASE WHEN total_before <= 0 THEN NEW.unit_cost
                           ELSE round((total_before * avg_cost + NEW.qty * NEW.unit_cost) / (total_before + NEW.qty), 4) END
     WHERE id = NEW.stock_item_id;
  END IF;

  INSERT INTO stock_levels (business_id, branch_id, stock_item_id, qty, updated_at)
  VALUES (NEW.business_id, NEW.branch_id, NEW.stock_item_id, NEW.qty, now())
  ON CONFLICT (branch_id, stock_item_id)
  DO UPDATE SET qty = stock_levels.qty + EXCLUDED.qty, updated_at = now();

  IF NEW.lot_id IS NOT NULL THEN
    UPDATE stock_lots SET qty_remaining = qty_remaining + NEW.qty WHERE id = NEW.lot_id;
  END IF;
  RETURN NEW;
END
$$;
CREATE TRIGGER stock_movements_apply AFTER INSERT ON stock_movements
  FOR EACH ROW EXECUTE FUNCTION app.apply_stock_movement();

-- ---------------------------------------------------------------------
-- Proveedores y compras
-- ---------------------------------------------------------------------

CREATE TABLE suppliers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name          text NOT NULL,
  contact_name  text,
  phone         text,
  email         text,
  tax_id        text,
  address       text,
  notes         text NOT NULL DEFAULT '',
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id)
);
SELECT app.enable_tenant_rls('suppliers');

CREATE TABLE purchases (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   uuid NOT NULL,
  branch_id     uuid NOT NULL,
  supplier_id   uuid,
  folio         bigint NOT NULL,
  supplier_invoice text,
  status        text NOT NULL DEFAULT 'borrador'
                CHECK (status IN ('borrador','pedido','recibida_parcial','recibida','cancelada')),
  ordered_at    timestamptz,
  received_at   timestamptz,
  subtotal      numeric(14,2) NOT NULL DEFAULT 0,
  tax_total     numeric(14,2) NOT NULL DEFAULT 0,
  total         numeric(14,2) NOT NULL DEFAULT 0,
  notes         text NOT NULL DEFAULT '',
  created_by    uuid REFERENCES users(id),
  received_by   uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, folio),
  FOREIGN KEY (business_id, branch_id) REFERENCES branches(business_id, id),
  FOREIGN KEY (business_id, supplier_id) REFERENCES suppliers(business_id, id)
);
CREATE INDEX purchases_date_idx ON purchases (business_id, created_at DESC);
SELECT app.enable_tenant_rls('purchases');

CREATE TABLE purchase_items (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id    uuid NOT NULL,
  purchase_id    uuid NOT NULL,
  stock_item_id  uuid NOT NULL,
  qty_ordered    numeric(14,3) NOT NULL CHECK (qty_ordered > 0),
  qty_received   numeric(14,3) NOT NULL DEFAULT 0 CHECK (qty_received >= 0),
  unit_cost      numeric(14,4) NOT NULL CHECK (unit_cost >= 0),
  line_total     numeric(14,2) NOT NULL,
  lot_code       text,
  expires_on     date,
  FOREIGN KEY (business_id, purchase_id) REFERENCES purchases(business_id, id) ON DELETE CASCADE,
  FOREIGN KEY (business_id, stock_item_id) REFERENCES stock_items(business_id, id)
);
CREATE INDEX purchase_items_purchase_idx ON purchase_items (purchase_id);
SELECT app.enable_tenant_rls('purchase_items');
