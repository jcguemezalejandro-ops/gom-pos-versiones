-- ================================================================
-- 0018 · Envíos a domicilio: repartidores y seguimiento (D-037)
--
-- Repartidores propios (con WhatsApp) o plataformas de reparto (Didi, Uber…).
-- Cada pedido a domicilio puede tener un envío: a quién se asignó, cuándo salió y cuándo se entregó.
-- El mensaje de WhatsApp lo arma el servidor; la pantalla solo lo abre (un toque para enviar).
-- La ubicación del cliente vive en sales.delivery_info->>'ubicacion' (enlace de mapas o coordenadas).
-- ================================================================

CREATE TABLE couriers (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name         text NOT NULL CHECK (length(trim(name)) > 0),
  kind         text NOT NULL DEFAULT 'propio' CHECK (kind IN ('propio','plataforma')),
  phone        text,                                        -- WhatsApp del repartidor propio
  is_active    boolean NOT NULL DEFAULT true,
  sort_order   int NOT NULL DEFAULT 0,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, name),
  CHECK (kind = 'plataforma' OR phone IS NOT NULL)
);
SELECT app.enable_tenant_rls('couriers');
GRANT SELECT, INSERT ON couriers TO pos_app;
GRANT UPDATE (name, kind, phone, is_active, sort_order) ON couriers TO pos_app;

CREATE TABLE deliveries (
  sale_id       uuid PRIMARY KEY,
  business_id   uuid NOT NULL,
  courier_id    uuid,
  status        text NOT NULL DEFAULT 'asignado' CHECK (status IN ('asignado','en_camino','entregado')),
  pays_with     numeric(14,2) CHECK (pays_with IS NULL OR pays_with >= 0),   -- "paga con" para llevar cambio
  assigned_at   timestamptz NOT NULL DEFAULT now(),
  assigned_by   uuid NOT NULL REFERENCES users(id),
  departed_at   timestamptz,
  delivered_at  timestamptz,
  notes         text NOT NULL DEFAULT '',
  FOREIGN KEY (business_id, sale_id) REFERENCES sales(business_id, id),
  FOREIGN KEY (business_id, courier_id) REFERENCES couriers(business_id, id)
);
CREATE INDEX deliveries_status_idx ON deliveries (business_id, status);
SELECT app.enable_tenant_rls('deliveries');
GRANT SELECT, INSERT ON deliveries TO pos_app;
GRANT UPDATE (courier_id, status, pays_with, assigned_at, assigned_by, departed_at, delivered_at, notes) ON deliveries TO pos_app;
