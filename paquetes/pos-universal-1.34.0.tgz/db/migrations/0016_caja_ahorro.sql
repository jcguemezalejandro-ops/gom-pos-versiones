-- ================================================================
-- 0016 · Caja de Ahorro y Préstamos (D-034, docs/caja-ahorro.md)
--
-- Giro nuevo `caja_ahorro`, que no usa ventas, catálogo ni caja registradora.
-- El dinero se lleva en un libro mayor de doble partida de solo inserción:
-- cada asiento suma cero y una corrección es un asiento de reversión.
--
-- Convención de signo de ah_partidas.monto: positivo = cargo (debe), negativo = abono (haber).
--   efectivo          activo: dinero que la caja tiene en mano o en banco
--   cartera           activo: capital prestado por cobrar (por préstamo)
--   socio_disponible  pasivo: ahorro del socio que no está prestado (por socio)
--   socio_prestado    pasivo: ahorro del socio que está prestado (por socio)
--   fondo_disponible  capital: fondo colectivo interno sin prestar
--   fondo_prestado    capital: fondo colectivo interno prestado (aportaciones atrasadas)
--   gestores          pasivo: participación de gestores por pagar (por gestor o sin asignar)
-- Identidad que se concilia: efectivo + cartera = −(todas las demás).
-- Nada de esto toca las tablas de ventas, caja ni egresos del POS.
-- ================================================================

-- Núcleo por giro: si core_modules tiene valor, solo esos módulos del núcleo quedan activos.
ALTER TABLE business_types ADD COLUMN core_modules text[];

INSERT INTO business_types (key, name, description, core_modules) VALUES
  ('caja_ahorro', 'Caja de Ahorro y Préstamos', 'Socios, aportaciones catorcenales, préstamos internos y externos, intereses y repartos', '{nucleo}');

INSERT INTO modules (key, name, description, is_core, depends_on, sort_order) VALUES
  ('ahorro', 'Caja de ahorro', 'Socios, aportaciones, préstamos, intereses, gestores y repartos', false, '{}', 210);

INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('ahorro.ver',        'ahorro', 'Ver socios, préstamos, saldos y reportes de la caja de ahorro', false),
  ('ahorro.socios',     'ahorro', 'Dar de alta, editar y dar de baja socios', true),
  ('ahorro.aportar',    'ahorro', 'Registrar aportaciones de socios', false),
  ('ahorro.prestar',    'ahorro', 'Otorgar préstamos internos y externos', true),
  ('ahorro.cobrar',     'ahorro', 'Registrar pagos de préstamos', false),
  ('ahorro.autorizar',  'ahorro', 'Autorizar diferimientos, incobrables, reversos, aportaciones extraordinarias y cierres', true),
  ('ahorro.gestores',   'ahorro', 'Pagar participaciones a gestores y registrar egresos de la caja', true),
  ('ahorro.configurar', 'ahorro', 'Cambiar tasas, aportaciones y el ciclo de la caja de ahorro', true);

-- Parámetros de la caja. Una fila por negocio; también sirve como candado del fondo colectivo.
-- Las tasas se copian a cada préstamo al otorgarlo: cambiarlas no altera préstamos existentes.
CREATE TABLE ah_config (
  business_id        uuid PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  aport_inicial      numeric(14,2) NOT NULL DEFAULT 2000 CHECK (aport_inicial >= 0),
  aport_ordinaria    numeric(14,2) NOT NULL DEFAULT 600  CHECK (aport_ordinaria >= 0),
  tasa_interna       numeric(6,4)  NOT NULL DEFAULT 0.05 CHECK (tasa_interna BETWEEN 0 AND 1),
  tasa_externa       numeric(6,4)  NOT NULL DEFAULT 0.10 CHECK (tasa_externa BETWEEN 0 AND 1),
  parte_prestamista  numeric(6,4)  NOT NULL DEFAULT 0.05 CHECK (parte_prestamista BETWEEN 0 AND 1), -- puntos de la tasa externa para el prestamista
  recargo            numeric(6,4)  NOT NULL DEFAULT 0.02 CHECK (recargo BETWEEN 0 AND 1),           -- puntos extra por catorcena vencida (5 % → 7 %)
  parte_gestores     numeric(6,4)  NOT NULL DEFAULT 0.05 CHECK (parte_gestores BETWEEN 0 AND 1),     -- fracción del interés interno cobrado
  dias_catorcena     int NOT NULL DEFAULT 14 CHECK (dias_catorcena BETWEEN 7 AND 31),
  updated_by         uuid REFERENCES users(id),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  CHECK (parte_prestamista <= tasa_externa)
);
SELECT app.enable_tenant_rls('ah_config');
GRANT SELECT, INSERT ON ah_config TO pos_app;
GRANT UPDATE (aport_inicial, aport_ordinaria, tasa_interna, tasa_externa, parte_prestamista, recargo, parte_gestores, updated_by, updated_at) ON ah_config TO pos_app;

-- Ciclo anual: catorcenas desde `inicio`; el cierre es `cierre` (después de la última catorcena completa).
CREATE TABLE ah_ciclos (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  inicio       date NOT NULL,
  cierre       date NOT NULL,
  estado       text NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','cerrado')),
  cerrado_por  uuid REFERENCES users(id),
  cerrado_at   timestamptz,
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  CHECK (cierre > inicio),
  CHECK ((estado = 'cerrado') = (cerrado_at IS NOT NULL))
);
CREATE UNIQUE INDEX ah_ciclos_abierto_uq ON ah_ciclos (business_id) WHERE estado = 'abierto';
SELECT app.enable_tenant_rls('ah_ciclos');
GRANT SELECT, INSERT ON ah_ciclos TO pos_app;
GRANT UPDATE (estado, cerrado_por, cerrado_at) ON ah_ciclos TO pos_app;

CREATE TABLE ah_socios (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  numero        int NOT NULL CHECK (numero > 0),
  nombre        text NOT NULL CHECK (length(trim(nombre)) > 0),
  telefono      text,
  nota          text NOT NULL DEFAULT '',
  ingreso       date NOT NULL,
  estado        text NOT NULL DEFAULT 'activo' CHECK (estado IN ('activo','baja')),
  baja_fecha    date,
  baja_motivo   text,
  created_by    uuid NOT NULL REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, numero),
  CHECK ((estado = 'baja') = (baja_fecha IS NOT NULL))
);
SELECT app.enable_tenant_rls('ah_socios');
GRANT SELECT, INSERT ON ah_socios TO pos_app;
GRANT UPDATE (nombre, telefono, nota, estado, baja_fecha, baja_motivo) ON ah_socios TO pos_app;

CREATE TABLE ah_externos (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  nombre       text NOT NULL CHECK (length(trim(nombre)) > 0),
  telefono     text,
  nota         text NOT NULL DEFAULT '',
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id)
);
SELECT app.enable_tenant_rls('ah_externos');
GRANT SELECT, INSERT ON ah_externos TO pos_app;
GRANT UPDATE (nombre, telefono, nota) ON ah_externos TO pos_app;

-- Préstamo. El vencimiento original nunca cambia; los diferimientos van en su propia tabla.
--   interno     socio → socio. Interés de la caja: gestores y fondo interno.
--   externo     socio → persona externa. Interés: prestamista y reparto entre socios activos.
--   aportacion  la caja presta al socio la aportación que no pagó a tiempo (prestamista = fondo).
CREATE TABLE ah_prestamos (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id        uuid NOT NULL,
  folio              int NOT NULL CHECK (folio > 0),
  tipo               text NOT NULL CHECK (tipo IN ('interno','externo','aportacion')),
  ciclo_id           uuid NOT NULL,
  prestamista_id     uuid,                 -- socio; NULL = fondo de la caja
  prestatario_id     uuid,                 -- socio que debe
  externo_id         uuid,                 -- persona externa que debe
  gestor_id          uuid REFERENCES users(id),
  capital            numeric(14,2) NOT NULL CHECK (capital > 0),
  tasa               numeric(6,4) NOT NULL CHECK (tasa BETWEEN 0 AND 1),
  recargo            numeric(6,4) NOT NULL CHECK (recargo BETWEEN 0 AND 1),
  parte_prestamista  numeric(6,4) NOT NULL CHECK (parte_prestamista BETWEEN 0 AND 1),
  parte_gestores     numeric(6,4) NOT NULL CHECK (parte_gestores BETWEEN 0 AND 1),
  dias_catorcena     int NOT NULL CHECK (dias_catorcena BETWEEN 7 AND 31),
  fecha              date NOT NULL,        -- desembolso
  vence_original     date NOT NULL,
  periodo            int,                  -- catorcena de la aportación atrasada
  incobrable_fecha   date,
  incobrable_por     uuid REFERENCES users(id),
  nota               text NOT NULL DEFAULT '',
  created_by         uuid NOT NULL REFERENCES users(id),
  created_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, folio),
  FOREIGN KEY (business_id, ciclo_id) REFERENCES ah_ciclos(business_id, id),
  FOREIGN KEY (business_id, prestamista_id) REFERENCES ah_socios(business_id, id),
  FOREIGN KEY (business_id, prestatario_id) REFERENCES ah_socios(business_id, id),
  FOREIGN KEY (business_id, externo_id) REFERENCES ah_externos(business_id, id),
  CHECK (vence_original > fecha),
  CHECK (tipo <> 'interno'    OR (prestamista_id IS NOT NULL AND prestatario_id IS NOT NULL AND externo_id IS NULL AND prestamista_id <> prestatario_id)),
  CHECK (tipo <> 'externo'    OR (prestamista_id IS NOT NULL AND prestatario_id IS NULL AND externo_id IS NOT NULL)),
  CHECK (tipo <> 'aportacion' OR (prestamista_id IS NULL AND prestatario_id IS NOT NULL AND externo_id IS NULL AND periodo IS NOT NULL)),
  CHECK ((incobrable_fecha IS NULL) = (incobrable_por IS NULL)),
  CHECK (incobrable_fecha IS NULL OR tipo = 'externo')
);
CREATE UNIQUE INDEX ah_prestamos_aportacion_uq ON ah_prestamos (business_id, ciclo_id, prestatario_id, periodo) WHERE tipo = 'aportacion';
SELECT app.enable_tenant_rls('ah_prestamos');
GRANT SELECT, INSERT ON ah_prestamos TO pos_app;
GRANT UPDATE (incobrable_fecha, incobrable_por, nota) ON ah_prestamos TO pos_app;

-- Diferimientos autorizados. Cada uno mueve el vencimiento vigente; el original queda intacto.
CREATE TABLE ah_diferimientos (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id      uuid NOT NULL,
  prestamo_id      uuid NOT NULL,
  vence_anterior   date NOT NULL,
  vence_nuevo      date NOT NULL,
  catorcenas       int NOT NULL CHECK (catorcenas BETWEEN 1 AND 26),
  capital_pendiente numeric(14,2) NOT NULL,
  interes_pendiente numeric(14,2) NOT NULL,
  motivo           text NOT NULL CHECK (length(trim(motivo)) >= 3),
  estado           text NOT NULL DEFAULT 'autorizado' CHECK (estado = 'autorizado'),
  autorizado_por   uuid NOT NULL REFERENCES users(id),
  registrado_por   uuid NOT NULL REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, prestamo_id) REFERENCES ah_prestamos(business_id, id),
  CHECK (vence_nuevo > vence_anterior)
);
SELECT app.enable_tenant_rls('ah_diferimientos');
GRANT SELECT, INSERT ON ah_diferimientos TO pos_app;
CREATE TRIGGER ah_diferimientos_inmutable BEFORE UPDATE OR DELETE ON ah_diferimientos FOR EACH ROW EXECUTE FUNCTION app.forbid_change();

-- Asiento del libro mayor.
CREATE TABLE ah_asientos (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL,
  folio        int NOT NULL CHECK (folio > 0),
  fecha        date NOT NULL,
  tipo         text NOT NULL CHECK (tipo IN (
                 'aportacion_inicial','aportacion_ordinaria','aportacion_extraordinaria','aportacion_prestamo',
                 'desembolso','pago','incobrable','pago_gestor','egreso','reparto_fondo','devolucion','reversion')),
  socio_id     uuid,
  prestamo_id  uuid,
  periodo      int,                        -- catorcena de una aportación
  clave        uuid,                       -- idempotencia: el mismo envío no se registra dos veces
  reverses_id  uuid,
  detalle      jsonb NOT NULL DEFAULT '{}',
  nota         text NOT NULL DEFAULT '',
  autorizado_por uuid REFERENCES users(id),
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, folio),
  UNIQUE (business_id, clave),
  FOREIGN KEY (business_id, socio_id) REFERENCES ah_socios(business_id, id),
  FOREIGN KEY (business_id, prestamo_id) REFERENCES ah_prestamos(business_id, id),
  FOREIGN KEY (business_id, reverses_id) REFERENCES ah_asientos(business_id, id),
  CHECK ((tipo = 'reversion') = (reverses_id IS NOT NULL))
);
CREATE UNIQUE INDEX ah_asientos_reverses_uq ON ah_asientos (reverses_id) WHERE reverses_id IS NOT NULL;
CREATE INDEX ah_asientos_fecha_idx ON ah_asientos (business_id, fecha);
CREATE INDEX ah_asientos_prestamo_idx ON ah_asientos (business_id, prestamo_id) WHERE prestamo_id IS NOT NULL;
SELECT app.enable_tenant_rls('ah_asientos');
GRANT SELECT, INSERT ON ah_asientos TO pos_app;
CREATE TRIGGER ah_asientos_inmutable BEFORE UPDATE OR DELETE ON ah_asientos FOR EACH ROW EXECUTE FUNCTION app.forbid_change();

CREATE TABLE ah_partidas (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  business_id  uuid NOT NULL,
  asiento_id   uuid NOT NULL,
  cuenta       text NOT NULL CHECK (cuenta IN ('efectivo','cartera','socio_disponible','socio_prestado','fondo_disponible','fondo_prestado','gestores')),
  socio_id     uuid,
  prestamo_id  uuid,
  gestor_id    uuid REFERENCES users(id),
  concepto     text NOT NULL,
  monto        numeric(14,2) NOT NULL CHECK (monto <> 0),
  FOREIGN KEY (business_id, asiento_id) REFERENCES ah_asientos(business_id, id),
  FOREIGN KEY (business_id, socio_id) REFERENCES ah_socios(business_id, id),
  FOREIGN KEY (business_id, prestamo_id) REFERENCES ah_prestamos(business_id, id),
  CHECK (cuenta NOT IN ('socio_disponible','socio_prestado') OR socio_id IS NOT NULL),
  CHECK (cuenta <> 'cartera' OR prestamo_id IS NOT NULL)
);
CREATE INDEX ah_partidas_asiento_idx ON ah_partidas (asiento_id);
CREATE INDEX ah_partidas_socio_idx ON ah_partidas (business_id, socio_id, cuenta) WHERE socio_id IS NOT NULL;
CREATE INDEX ah_partidas_cuenta_idx ON ah_partidas (business_id, cuenta);
SELECT app.enable_tenant_rls('ah_partidas');
GRANT SELECT, INSERT ON ah_partidas TO pos_app;
CREATE TRIGGER ah_partidas_inmutable BEFORE UPDATE OR DELETE ON ah_partidas FOR EACH ROW EXECUTE FUNCTION app.forbid_change();

-- Cada asiento debe sumar exactamente cero y tener al menos dos partidas (se revisa al confirmar).
CREATE FUNCTION app.ah_cuadra() RETURNS trigger
LANGUAGE plpgsql AS
$$
DECLARE s numeric; n int;
BEGIN
  SELECT coalesce(sum(monto), 0), count(*) INTO s, n FROM ah_partidas WHERE asiento_id = NEW.id;
  IF n < 2 OR s <> 0 THEN
    RAISE EXCEPTION 'El asiento % no cuadra (partidas: %, suma: %)', NEW.folio, n, s USING ERRCODE = 'check_violation';
  END IF;
  RETURN NULL;
END
$$;
CREATE CONSTRAINT TRIGGER ah_asiento_cuadra AFTER INSERT ON ah_asientos
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.ah_cuadra();

-- Detalle de cada pago de préstamo: cómo se reparte entre capital, interés y recargo.
CREATE TABLE ah_pagos (
  asiento_id   uuid PRIMARY KEY,
  business_id  uuid NOT NULL,
  prestamo_id  uuid NOT NULL,
  fecha        date NOT NULL,
  capital      numeric(14,2) NOT NULL CHECK (capital >= 0),
  interes      numeric(14,2) NOT NULL CHECK (interes >= 0),
  recargo      numeric(14,2) NOT NULL CHECK (recargo >= 0),
  metodo       text NOT NULL CHECK (metodo IN ('efectivo','transferencia','ahorro')),
  FOREIGN KEY (business_id, asiento_id) REFERENCES ah_asientos(business_id, id),
  FOREIGN KEY (business_id, prestamo_id) REFERENCES ah_prestamos(business_id, id),
  CHECK (capital + interes + recargo > 0)
);
CREATE INDEX ah_pagos_prestamo_idx ON ah_pagos (business_id, prestamo_id, fecha);
SELECT app.enable_tenant_rls('ah_pagos');
GRANT SELECT, INSERT ON ah_pagos TO pos_app;
CREATE TRIGGER ah_pagos_inmutable BEFORE UPDATE OR DELETE ON ah_pagos FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
