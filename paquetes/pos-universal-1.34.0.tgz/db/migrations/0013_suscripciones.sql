-- ================================================================
-- 0013 · Suscripciones: planes, estado por negocio, bitácora de
--        facturación y administradores de la plataforma.
-- Ver docs/suscripciones.md.
-- ================================================================

-- ---------------- Planes (catálogo de la plataforma) ----------------
CREATE TABLE plans (
  key            text PRIMARY KEY CHECK (key ~ '^[a-z][a-z0-9_]{1,29}$'),
  name           text NOT NULL,
  description    text NOT NULL DEFAULT '',
  price_monthly  numeric(12,2) CHECK (price_monthly >= 0),   -- nulo: precio por definir
  price_yearly   numeric(12,2) CHECK (price_yearly >= 0),
  currency       char(3) NOT NULL DEFAULT 'MXN',
  max_branches   int CHECK (max_branches > 0),               -- nulo: sin límite
  max_users      int CHECK (max_users > 0),
  max_registers  int CHECK (max_registers > 0),
  max_products   int CHECK (max_products > 0),
  modules        text[],                                     -- nulo: todos los módulos
  is_public      boolean NOT NULL DEFAULT true,              -- se ofrece a negocios nuevos
  sort_order     int NOT NULL DEFAULT 0,
  updated_at     timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON plans TO pos_app;

-- Tres planes por tamaño. Los precios se capturan en el panel de la plataforma.
INSERT INTO plans (key, name, description, max_branches, max_users, max_registers, max_products, sort_order) VALUES
  ('basico',        'Básico',        'Un local con equipo pequeño',              1, 3,    1,    300,  1),
  ('negocio',       'Negocio',       'Un local con más personal y varias cajas', 1, 10,   3,    NULL, 2),
  ('multisucursal', 'Multisucursal', 'Varias sucursales, sin límites',           NULL, NULL, NULL, NULL, 3);

-- Ajustes generales de la plataforma.
CREATE TABLE platform_settings (
  key    text PRIMARY KEY,
  value  jsonb NOT NULL
);
INSERT INTO platform_settings (key, value) VALUES
  ('suscripciones', '{"diasPrueba": 30, "diasGracia": 5, "planInicial": "negocio", "diasExportacion": 60}');
GRANT SELECT ON platform_settings TO pos_app;

-- ---------------- Administradores de la plataforma ----------------
CREATE TABLE platform_admins (
  user_id     uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now()
);
-- La API no puede leer ni escribir esta tabla: solo pregunta con app.is_platform_admin().

CREATE FUNCTION app.is_platform_admin() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS
$$ SELECT EXISTS (SELECT 1 FROM platform_admins WHERE user_id = app.current_user_id()) $$;

CREATE FUNCTION app.require_platform_admin() RETURNS void
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  IF NOT app.is_platform_admin() THEN
    RAISE EXCEPTION 'Solo para administradores de la plataforma' USING ERRCODE = '42501';
  END IF;
END
$$;

-- ---------------- Suscripción de cada negocio ----------------
CREATE TABLE subscriptions (
  business_id          uuid PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  plan_key             text NOT NULL REFERENCES plans(key),
  status               text NOT NULL CHECK (status IN ('prueba','activa','suspendida','cancelada')),
  trial_ends_at        timestamptz,
  current_period_end   timestamptz,          -- nulo en una suscripción activa: sin vencimiento (cortesía)
  cancelled_at         timestamptz,
  discount_pct         numeric(5,2) NOT NULL DEFAULT 0 CHECK (discount_pct BETWEEN 0 AND 100),
  provider             text,                 -- 'conekta' cuando se conecte el cobro
  provider_customer    text,
  provider_subscription text,
  notes                text NOT NULL DEFAULT '',
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);
SELECT app.enable_tenant_rls('subscriptions');
-- El negocio solo consulta su suscripción; los cambios pasan por funciones de la plataforma.
GRANT SELECT ON subscriptions TO pos_app;

CREATE TABLE subscription_events (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  at           timestamptz NOT NULL DEFAULT now(),
  kind         text NOT NULL,              -- alta, cambio, pago, pago_fallido, suspension, reactivacion, cancelacion
  detail       jsonb NOT NULL DEFAULT '{}',
  actor_id     uuid REFERENCES users(id),
  source       text NOT NULL DEFAULT 'plataforma'
);
CREATE INDEX subscription_events_idx ON subscription_events (business_id, at DESC);
SELECT app.enable_tenant_rls('subscription_events');
GRANT SELECT ON subscription_events TO pos_app;

-- Los negocios que ya existen quedan activos, sin vencimiento y sin límites.
INSERT INTO subscriptions (business_id, plan_key, status, notes)
SELECT id, 'multisucursal', 'activa', 'Negocio anterior a las suscripciones' FROM businesses;
INSERT INTO subscription_events (business_id, kind, detail, source)
SELECT id, 'alta', '{"plan": "multisucursal", "estado": "activa", "motivo": "negocio existente"}', 'migracion' FROM businesses;

-- Estado efectivo: aplica vencimientos y días de gracia sin necesidad de un proceso programado.
--   prueba vencida                       -> suspendida
--   activa con periodo vencido           -> vencida (días de gracia) -> suspendida
CREATE FUNCTION app.effective_status(s subscriptions) RETURNS text
LANGUAGE sql STABLE AS
$$
  SELECT CASE
    WHEN s.status = 'prueba' AND s.trial_ends_at IS NOT NULL AND s.trial_ends_at < now() THEN 'suspendida'
    WHEN s.status = 'activa' AND s.current_period_end IS NOT NULL AND s.current_period_end < now() THEN
      CASE WHEN s.current_period_end + make_interval(days => coalesce(((SELECT value->>'diasGracia' FROM platform_settings WHERE key = 'suscripciones'))::int, 5)) < now()
           THEN 'suspendida' ELSE 'vencida' END
    ELSE s.status END
$$;

-- Alta de la suscripción al crear un negocio: prueba gratis con el plan inicial.
CREATE FUNCTION app.start_subscription() RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS
$$
DECLARE
  cfg jsonb := (SELECT value FROM platform_settings WHERE key = 'suscripciones');
  b uuid := app.current_business();
BEGIN
  IF b IS NULL OR EXISTS (SELECT 1 FROM subscriptions WHERE business_id = b) THEN RETURN; END IF;
  INSERT INTO subscriptions (business_id, plan_key, status, trial_ends_at)
  VALUES (b, cfg->>'planInicial', 'prueba', now() + make_interval(days => (cfg->>'diasPrueba')::int));
  INSERT INTO subscription_events (business_id, kind, detail, actor_id, source)
  VALUES (b, 'alta', jsonb_build_object('plan', cfg->>'planInicial', 'estado', 'prueba', 'diasPrueba', (cfg->>'diasPrueba')::int), app.current_user_id(), 'registro');
END
$$;

-- ---------------- Operaciones de la plataforma ----------------
-- Todas comprueban que quien llama sea administrador de la plataforma.

CREATE FUNCTION app.platform_businesses() RETURNS TABLE (
  id uuid, nombre text, giro text, creado timestamptz, plan text, estado text, estado_guardado text,
  fin_prueba timestamptz, fin_periodo timestamptz, descuento numeric, notas text,
  sucursales int, usuarios int, cajas int, productos int, ultimo_acceso timestamptz, precio numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  PERFORM app.require_platform_admin();
  RETURN QUERY
  SELECT b.id, b.trade_name, b.business_type, b.created_at, s.plan_key, app.effective_status(s), s.status,
         s.trial_ends_at, s.current_period_end, s.discount_pct, s.notes,
         (SELECT count(*)::int FROM branches x WHERE x.business_id = b.id AND x.is_active),
         (SELECT count(*)::int FROM memberships x WHERE x.business_id = b.id AND x.is_active),
         (SELECT count(*)::int FROM cash_registers x WHERE x.business_id = b.id AND x.is_active),
         (SELECT count(*)::int FROM products x WHERE x.business_id = b.id AND x.is_active),
         (SELECT max(x.last_seen_at) FROM sessions x WHERE x.business_id = b.id),
         p.price_monthly
    FROM businesses b LEFT JOIN subscriptions s ON s.business_id = b.id LEFT JOIN plans p ON p.key = s.plan_key
   ORDER BY b.created_at DESC;
END
$$;

CREATE FUNCTION app.platform_set_subscription(
  p_business uuid, p_plan text, p_status text, p_trial_ends timestamptz, p_period_end timestamptz,
  p_discount numeric, p_notes text, p_reason text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS
$$
DECLARE
  old subscriptions%ROWTYPE;
BEGIN
  PERFORM app.require_platform_admin();
  SELECT * INTO old FROM subscriptions WHERE business_id = p_business FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'El negocio no tiene suscripción' USING ERRCODE = 'P0002'; END IF;
  UPDATE subscriptions SET plan_key = p_plan, status = p_status, trial_ends_at = p_trial_ends, current_period_end = p_period_end,
         discount_pct = p_discount, notes = p_notes, updated_at = now(),
         cancelled_at = CASE WHEN p_status = 'cancelada' THEN coalesce(old.cancelled_at, now()) ELSE NULL END
   WHERE business_id = p_business;
  INSERT INTO subscription_events (business_id, kind, detail, actor_id)
  VALUES (p_business,
          CASE WHEN p_status = old.status THEN 'cambio' WHEN p_status = 'suspendida' THEN 'suspension'
               WHEN p_status = 'cancelada' THEN 'cancelacion' WHEN old.status IN ('suspendida','cancelada') THEN 'reactivacion' ELSE 'cambio' END,
          jsonb_build_object('motivo', p_reason,
            'antes', jsonb_build_object('plan', old.plan_key, 'estado', old.status, 'finPrueba', old.trial_ends_at, 'finPeriodo', old.current_period_end, 'descuento', old.discount_pct),
            'despues', jsonb_build_object('plan', p_plan, 'estado', p_status, 'finPrueba', p_trial_ends, 'finPeriodo', p_period_end, 'descuento', p_discount)),
          app.current_user_id());
END
$$;

CREATE FUNCTION app.platform_events(p_business uuid) RETURNS TABLE (at timestamptz, kind text, detail jsonb, actor text, source text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  PERFORM app.require_platform_admin();
  RETURN QUERY SELECT e.at, e.kind, e.detail, u.full_name, e.source
    FROM subscription_events e LEFT JOIN users u ON u.id = e.actor_id
   WHERE e.business_id = p_business ORDER BY e.at DESC LIMIT 200;
END
$$;

CREATE FUNCTION app.platform_save_plan(
  p_key text, p_name text, p_description text, p_monthly numeric, p_yearly numeric,
  p_branches int, p_users int, p_registers int, p_products int, p_modules text[], p_public boolean, p_order int) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  PERFORM app.require_platform_admin();
  INSERT INTO plans (key, name, description, price_monthly, price_yearly, max_branches, max_users, max_registers, max_products, modules, is_public, sort_order)
  VALUES (p_key, p_name, p_description, p_monthly, p_yearly, p_branches, p_users, p_registers, p_products, p_modules, p_public, p_order)
  ON CONFLICT (key) DO UPDATE SET name = EXCLUDED.name, description = EXCLUDED.description, price_monthly = EXCLUDED.price_monthly,
    price_yearly = EXCLUDED.price_yearly, max_branches = EXCLUDED.max_branches, max_users = EXCLUDED.max_users,
    max_registers = EXCLUDED.max_registers, max_products = EXCLUDED.max_products, modules = EXCLUDED.modules,
    is_public = EXCLUDED.is_public, sort_order = EXCLUDED.sort_order, updated_at = now();
END
$$;

CREATE FUNCTION app.platform_save_settings(p_value jsonb) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS
$$
BEGIN
  PERFORM app.require_platform_admin();
  UPDATE platform_settings SET value = p_value WHERE key = 'suscripciones';
END
$$;

REVOKE EXECUTE ON FUNCTION app.is_platform_admin(), app.require_platform_admin(), app.start_subscription(), app.platform_businesses(),
  app.platform_set_subscription(uuid, text, text, timestamptz, timestamptz, numeric, text, text), app.platform_events(uuid),
  app.platform_save_plan(text, text, text, numeric, numeric, int, int, int, int, text[], boolean, int), app.platform_save_settings(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.is_platform_admin(), app.require_platform_admin(), app.start_subscription(), app.platform_businesses(),
  app.platform_set_subscription(uuid, text, text, timestamptz, timestamptz, numeric, text, text), app.platform_events(uuid),
  app.platform_save_plan(text, text, text, numeric, numeric, int, int, int, int, text[], boolean, int), app.platform_save_settings(jsonb) TO pos_app;
