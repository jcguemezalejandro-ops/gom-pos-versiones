-- ================================================================
-- 0014 · Arranque contable: cuentas de dinero, saldo inicial y
--        movimientos de saldo (aportaciones, retiros del dueño,
--        traspasos y ajustes). Ver D-031.
-- Nada de esto modifica la caja, sus cortes ni los egresos.
-- ================================================================

INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('saldos.gestionar', 'nucleo', 'Registrar el arranque contable y los movimientos de saldo', true);

-- Cuentas de dinero del negocio. Cada tipo tiene una cuenta principal que recibe los cobros y
-- pagos de su forma de pago; las demás cuentas solo reciben movimientos manuales y traspasos.
--   caja      ← cobros en efectivo; salen los retiros de efectivo
--   efectivo  ← retiros de efectivo; salen los egresos en "Efectivo externo"
--   banco     ← cobros y egresos con tarjeta o transferencia
--   otro      ← cobros con vale u otro; egresos "otro"
CREATE TABLE money_accounts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name         text NOT NULL CHECK (length(trim(name)) > 0),
  kind         text NOT NULL CHECK (kind IN ('caja','efectivo','banco','otro')),
  is_primary   boolean NOT NULL DEFAULT false,
  is_active    boolean NOT NULL DEFAULT true,
  sort_order   int NOT NULL DEFAULT 0,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  UNIQUE (business_id, name)
);
CREATE UNIQUE INDEX money_accounts_primary_uq ON money_accounts (business_id, kind) WHERE is_primary;
SELECT app.enable_tenant_rls('money_accounts');
GRANT SELECT, INSERT ON money_accounts TO pos_app;
GRANT UPDATE (name, is_active, sort_order) ON money_accounts TO pos_app;

-- Fecha (día operativo) en que empiezan las cuentas. Una por negocio.
CREATE TABLE accounting_start (
  business_id  uuid PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  start_day    date NOT NULL,
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);
SELECT app.enable_tenant_rls('accounting_start');
-- Se borra solo al rehacer el arranque, después de revertir todos sus saldos iniciales.
GRANT SELECT, INSERT, DELETE ON accounting_start TO pos_app;

-- Libro de solo inserción. Un error se corrige con un movimiento de reversión.
CREATE TABLE money_movements (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id     uuid NOT NULL,
  account_id      uuid NOT NULL,
  kind            text NOT NULL CHECK (kind IN ('saldo_inicial','aportacion','retiro_dueno','traspaso','ajuste','reversion')),
  amount          numeric(14,2) NOT NULL CHECK (amount <> 0),   -- positivo entra, negativo sale
  op_day          date NOT NULL,
  note            text NOT NULL DEFAULT '',
  transfer_group  uuid,                                         -- une las dos mitades de un traspaso
  reverses_id     uuid,
  created_by      uuid NOT NULL REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, account_id) REFERENCES money_accounts(business_id, id),
  FOREIGN KEY (business_id, reverses_id) REFERENCES money_movements(business_id, id),
  CHECK ((kind = 'reversion') = (reverses_id IS NOT NULL)),
  CHECK (kind <> 'traspaso' OR transfer_group IS NOT NULL)
);
-- Un movimiento se revierte una sola vez.
CREATE UNIQUE INDEX money_movements_reverses_uq ON money_movements (reverses_id) WHERE reverses_id IS NOT NULL;
CREATE INDEX money_movements_day_idx ON money_movements (business_id, op_day);
SELECT app.enable_tenant_rls('money_movements');
GRANT SELECT, INSERT ON money_movements TO pos_app;
REVOKE UPDATE, DELETE ON money_movements FROM pos_app;

-- Para el saldo de la caja: retiros, entradas y salidas, por día operativo.
CREATE INDEX cash_movements_business_idx ON cash_movements (business_id, created_at);
