-- =====================================================================
-- 0006 · Soporte de operaciones comerciales (Fase 4)
-- Agregados analíticos mantenidos en la misma transacción que la operación,
-- costo de modificadores y datos de recepción.
-- =====================================================================

-- Partidas: modificadores y descuento propio (el descuento general se reparte y se recalcula).
ALTER TABLE sale_items ADD COLUMN modifiers_total numeric(14,2) NOT NULL DEFAULT 0;
ALTER TABLE sale_items ADD COLUMN own_discount numeric(14,2) NOT NULL DEFAULT 0 CHECK (own_discount >= 0);

-- Ventas: descuento general y devoluciones. El saldo pendiente descuenta lo devuelto.
ALTER TABLE sales ADD COLUMN discount_reason text;
ALTER TABLE sales ADD COLUMN general_discount numeric(14,2) NOT NULL DEFAULT 0 CHECK (general_discount >= 0);
ALTER TABLE sales DROP COLUMN balance;
ALTER TABLE sales ADD COLUMN refunded_total numeric(14,2) NOT NULL DEFAULT 0 CHECK (refunded_total >= 0);
ALTER TABLE sales ADD COLUMN balance numeric(14,2) GENERATED ALWAYS AS (total - refunded_total - paid_total) STORED;

ALTER TABLE payments ADD COLUMN notes text NOT NULL DEFAULT '';

-- Fecha y hora locales del negocio/sucursal para un instante.
CREATE FUNCTION app.local_ts(p_branch uuid, p_at timestamptz) RETURNS timestamp
LANGUAGE sql STABLE AS
$$
  SELECT p_at AT TIME ZONE coalesce(br.timezone, b.timezone)
    FROM branches br JOIN businesses b ON b.id = br.business_id
   WHERE br.id = p_branch
$$;

-- Suma (p_sign = 1) o resta (-1) una venta cerrada en los agregados.
CREATE FUNCTION app.aggregate_sale(p_sale uuid, p_sign int) RETURNS void
LANGUAGE plpgsql AS
$$
DECLARE
  s sales%ROWTYPE;
  lt timestamp;
BEGIN
  SELECT * INTO s FROM sales WHERE id = p_sale;
  IF s.closed_at IS NULL THEN RETURN; END IF;
  lt := app.local_ts(s.branch_id, s.closed_at);

  INSERT INTO daily_sales_agg AS d (business_id, branch_id, day, sales_count, gross_sales, discounts, net_sales, tax, tips, cost_of_goods)
  VALUES (s.business_id, s.branch_id, lt::date, p_sign, p_sign * s.subtotal, p_sign * s.discount_total,
          p_sign * (s.total - s.tax_total), p_sign * s.tax_total, p_sign * s.tip_total, p_sign * s.cost_total)
  ON CONFLICT (business_id, branch_id, day) DO UPDATE SET
    sales_count   = d.sales_count + EXCLUDED.sales_count,
    gross_sales   = d.gross_sales + EXCLUDED.gross_sales,
    discounts     = d.discounts + EXCLUDED.discounts,
    net_sales     = d.net_sales + EXCLUDED.net_sales,
    tax           = d.tax + EXCLUDED.tax,
    tips          = d.tips + EXCLUDED.tips,
    cost_of_goods = d.cost_of_goods + EXCLUDED.cost_of_goods;

  INSERT INTO hourly_sales_agg AS h (business_id, branch_id, day, hour, sales_count, net_sales)
  VALUES (s.business_id, s.branch_id, lt::date, extract(hour FROM lt)::smallint, p_sign, p_sign * (s.total - s.tax_total))
  ON CONFLICT (business_id, branch_id, day, hour) DO UPDATE SET
    sales_count = h.sales_count + EXCLUDED.sales_count,
    net_sales   = h.net_sales + EXCLUDED.net_sales;

  INSERT INTO daily_product_agg AS p (business_id, branch_id, day, variant_id, qty, revenue, cost)
  SELECT s.business_id, s.branch_id, lt::date, i.variant_id,
         p_sign * sum(i.qty), p_sign * sum(i.line_total - i.tax_amount), p_sign * sum(i.unit_cost * i.qty)
    FROM sale_items i WHERE i.sale_id = p_sale AND i.status = 'activo'
   GROUP BY i.variant_id
  ON CONFLICT (business_id, branch_id, day, variant_id) DO UPDATE SET
    qty     = p.qty + EXCLUDED.qty,
    revenue = p.revenue + EXCLUDED.revenue,
    cost    = p.cost + EXCLUDED.cost;
END
$$;

-- Registra un pago en el desglose por método del día (sin propinas: no son ingreso del negocio).
CREATE FUNCTION app.aggregate_payment(p_payment uuid, p_sign int) RETURNS void
LANGUAGE plpgsql AS
$$
DECLARE
  pm payments%ROWTYPE;
  d date;
BEGIN
  SELECT * INTO pm FROM payments WHERE id = p_payment;
  IF pm.kind = 'propina' OR pm.method = 'saldo_cliente' THEN RETURN; END IF;
  d := app.local_ts(pm.branch_id, pm.created_at)::date;
  INSERT INTO daily_sales_agg AS a (business_id, branch_id, day, by_method)
  VALUES (pm.business_id, pm.branch_id, d, jsonb_build_object(pm.method, p_sign * pm.amount))
  ON CONFLICT (business_id, branch_id, day) DO UPDATE SET
    by_method = a.by_method || jsonb_build_object(pm.method,
                 coalesce((a.by_method ->> pm.method)::numeric, 0) + p_sign * pm.amount);
END
$$;

-- Devoluciones y egresos operativos del día.
CREATE FUNCTION app.aggregate_amount(p_branch uuid, p_at timestamptz, p_field text, p_amount numeric) RETURNS void
LANGUAGE plpgsql AS
$$
DECLARE
  d date := app.local_ts(p_branch, p_at)::date;
BEGIN
  IF p_field NOT IN ('refunds', 'expenses', 'cost_of_goods') THEN RAISE EXCEPTION 'Campo no permitido: %', p_field; END IF;
  EXECUTE format(
    'INSERT INTO daily_sales_agg AS a (business_id, branch_id, day, %1$I) VALUES (app.current_business(), $1, $2, $3)
     ON CONFLICT (business_id, branch_id, day) DO UPDATE SET %1$I = a.%1$I + EXCLUDED.%1$I', p_field)
  USING p_branch, d, p_amount;
END
$$;

-- Lotes: consumo por caducidad más próxima (FEFO). Bloquea las filas.
CREATE INDEX stock_lots_fefo_idx ON stock_lots (business_id, branch_id, stock_item_id, expires_on NULLS LAST, received_at)
  WHERE qty_remaining > 0;

-- El saldo de un lote solo cambia mediante movimientos de inventario.
REVOKE UPDATE, DELETE ON stock_lots FROM pos_app;
GRANT UPDATE (lot_code, expires_on) ON stock_lots TO pos_app;
