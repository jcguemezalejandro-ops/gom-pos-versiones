-- Flujo de venta en tres pasos.

-- NULL: la partida está guardada en la cuenta, pero aún no se envía a preparación.
ALTER TABLE sale_items ADD COLUMN sent_at timestamptz DEFAULT now();

-- Identifica el envío de un grupo de partidas: un reintento no las duplica.
ALTER TABLE sale_items ADD COLUMN batch_uuid uuid;
CREATE INDEX sale_items_batch_idx ON sale_items (sale_id, batch_uuid) WHERE batch_uuid IS NOT NULL;

-- Una mesa no puede tener dos cuentas abiertas, ni con solicitudes simultáneas.
CREATE UNIQUE INDEX sales_open_table_uq ON sales (table_id) WHERE status = 'abierta' AND table_id IS NOT NULL;
