-- ================================================================
-- 0021 · Historial de mensajes enviados a clientes (D-047)
--
-- Solo agrega. Cada vez que un empleado abre WhatsApp con un aviso o lo copia,
-- queda un registro (no se edita ni se borra). Sirve para:
--   · no enviar dos veces el mismo aviso sin darse cuenta (misma huella del texto);
--   · numerar las versiones cuando el pedido cambia después de avisar;
--   · el historial de comunicación del cliente.
-- "enlace" significa que se abrió WhatsApp con el mensaje: el sistema no puede saber
-- si el empleado tocó Enviar, por eso no se registra como "entregado".
-- ================================================================

CREATE TABLE message_log (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL,
  sale_id      uuid NOT NULL,
  customer_id  uuid,
  event        text NOT NULL CHECK (event IN ('pedido_confirmado','en_preparacion','pedido_listo','en_camino','entregado','pago_confirmado','cancelado')),
  channel      text NOT NULL CHECK (channel IN ('enlace','copiado')),
  version      int NOT NULL DEFAULT 1 CHECK (version >= 1),
  body         text NOT NULL CHECK (length(body) BETWEEN 1 AND 4000),
  body_hash    text NOT NULL CHECK (body_hash ~ '^[0-9a-f]{64}$'),
  to_phone     text CHECK (to_phone IS NULL OR to_phone ~ '^\+[1-9][0-9]{10,14}$'),
  is_resend    boolean NOT NULL DEFAULT false,
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (business_id, sale_id) REFERENCES sales(business_id, id),
  FOREIGN KEY (business_id, customer_id) REFERENCES customers(business_id, id)
);
CREATE INDEX message_log_sale_idx ON message_log (business_id, sale_id, event, created_at);
CREATE INDEX message_log_customer_idx ON message_log (business_id, customer_id, created_at DESC) WHERE customer_id IS NOT NULL;
SELECT app.enable_tenant_rls('message_log');
CREATE TRIGGER message_log_no_change BEFORE UPDATE OR DELETE ON message_log
  FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
GRANT SELECT, INSERT ON message_log TO pos_app;
