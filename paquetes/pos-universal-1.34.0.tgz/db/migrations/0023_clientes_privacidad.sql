-- ================================================================
-- 0023 · Privacidad de clientes (D-051)
--
-- Solo agrega; no borra datos al aplicarse.
--   · communication_consents: historial de autorizaciones del cliente, por separado para
--     avisos de su pedido y para publicidad. No se edita ni se borra: el estado vigente es
--     el último registro.
--   · customers.anonymized_at/by: cliente cuyos datos personales se eliminaron a solicitud
--     del titular (derechos ARCO). Sus ventas e importes se conservan.
--   · message_log: sigue sin poder editarse ni borrarse, con UNA excepción controlada:
--     borrar el texto y el teléfono de los mensajes de un cliente que pidió eliminar sus datos
--     (solo con app.redaccion = on, solo esas dos columnas y solo con el texto de reemplazo).
--   · Permiso clientes.anonimizar (sensible).
-- ================================================================

CREATE TABLE communication_consents (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL,
  customer_id  uuid NOT NULL,
  kind         text NOT NULL CHECK (kind IN ('avisos','publicidad')),
  granted      boolean NOT NULL,
  source       text NOT NULL CHECK (source IN ('whatsapp','verbal','escrito','sistema')),
  notes        text NOT NULL DEFAULT '' CHECK (length(notes) <= 300),
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (business_id, customer_id) REFERENCES customers(business_id, id)
);
CREATE INDEX communication_consents_idx ON communication_consents (business_id, customer_id, kind, created_at DESC);
SELECT app.enable_tenant_rls('communication_consents');
CREATE TRIGGER communication_consents_no_change BEFORE UPDATE OR DELETE ON communication_consents
  FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
GRANT SELECT, INSERT ON communication_consents TO pos_app;

ALTER TABLE customers
  ADD COLUMN anonymized_at timestamptz,
  ADD COLUMN anonymized_by uuid REFERENCES users(id);
GRANT UPDATE (anonymized_at, anonymized_by) ON customers TO pos_app;

-- Texto que sustituye a un mensaje cuyo titular pidió eliminar sus datos.
CREATE FUNCTION app.message_log_guard() RETURNS trigger
  LANGUAGE plpgsql AS
$$
BEGIN
  IF TG_OP = 'UPDATE'
     AND current_setting('app.redaccion', true) = 'on'
     AND NEW.body = '[Datos eliminados a solicitud del titular]' AND NEW.to_phone IS NULL
     AND (NEW.id, NEW.business_id, NEW.sale_id, NEW.customer_id, NEW.event, NEW.channel, NEW.version, NEW.body_hash, NEW.is_resend, NEW.created_by, NEW.created_at)
         IS NOT DISTINCT FROM
         (OLD.id, OLD.business_id, OLD.sale_id, OLD.customer_id, OLD.event, OLD.channel, OLD.version, OLD.body_hash, OLD.is_resend, OLD.created_by, OLD.created_at)
  THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'La tabla % es de solo inserción', TG_TABLE_NAME USING ERRCODE = 'insufficient_privilege';
END
$$;
DROP TRIGGER message_log_no_change ON message_log;
CREATE TRIGGER message_log_no_change BEFORE UPDATE OR DELETE ON message_log
  FOR EACH ROW EXECUTE FUNCTION app.message_log_guard();
GRANT UPDATE (body, to_phone) ON message_log TO pos_app;
-- La solicitud de datos exige teléfono, salvo cuando ya se eliminó por solicitud del titular.
ALTER TABLE message_log DROP CONSTRAINT message_log_origen_check;
ALTER TABLE message_log ADD CONSTRAINT message_log_origen_check
  CHECK ((event = 'solicitar_datos' AND (to_phone IS NOT NULL OR body = '[Datos eliminados a solicitud del titular]'))
      OR (event <> 'solicitar_datos' AND sale_id IS NOT NULL));

INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('clientes.anonimizar', 'clientes', 'Eliminar los datos personales de un cliente y aplicar la conservación de datos (ARCO)', true);
INSERT INTO role_permissions (business_id, role_id, permission_key)
SELECT r.business_id, r.id, 'clientes.anonimizar'
  FROM roles r
 WHERE r.key = 'gerente'
   AND EXISTS (SELECT 1 FROM role_permissions rp WHERE rp.role_id = r.id AND rp.permission_key = 'clientes.gestionar')
ON CONFLICT DO NOTHING;
