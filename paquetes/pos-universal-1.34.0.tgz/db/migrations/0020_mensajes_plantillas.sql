-- ================================================================
-- 0020 · Plantillas de mensajes para clientes (D-046)
--
-- Solo agrega. Una fila por evento cuando el negocio personaliza el texto o lo
-- desactiva; sin fila se usa el texto sugerido del sistema (packages/shared/src/mensajes.ts).
-- Modos: manual (el empleado lo envía) o desactivado. El envío automático requiere la
-- API oficial de WhatsApp, que este negocio decidió no tramitar (ver docs/clientes-crm.md).
-- ================================================================

CREATE TABLE message_templates (
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  event        text NOT NULL CHECK (event IN ('pedido_confirmado','en_preparacion','pedido_listo','en_camino','entregado','pago_confirmado','cancelado')),
  mode         text NOT NULL DEFAULT 'manual' CHECK (mode IN ('manual','desactivado')),
  body         text NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 2000),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  updated_by   uuid REFERENCES users(id),
  PRIMARY KEY (business_id, event)
);
SELECT app.enable_tenant_rls('message_templates');
GRANT SELECT, INSERT, DELETE ON message_templates TO pos_app;
GRANT UPDATE (mode, body, updated_at, updated_by) ON message_templates TO pos_app;

INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('mensajeria.configurar', 'clientes', 'Editar las plantillas de mensajes para clientes', false);

-- Gerentes que ya administran clientes también configuran los mensajes.
INSERT INTO role_permissions (business_id, role_id, permission_key)
SELECT r.business_id, r.id, 'mensajeria.configurar'
  FROM roles r
 WHERE r.key = 'gerente'
   AND EXISTS (SELECT 1 FROM role_permissions rp WHERE rp.role_id = r.id AND rp.permission_key = 'clientes.gestionar')
ON CONFLICT DO NOTHING;
