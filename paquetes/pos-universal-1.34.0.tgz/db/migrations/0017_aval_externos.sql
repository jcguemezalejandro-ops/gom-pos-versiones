-- ================================================================
-- 0017 · Préstamos externos con socio aval (D-036)
--
-- Cada caja elige de dónde sale el dinero de un préstamo a una persona externa:
--   ahorro_aval         del ahorro del socio aval (como hasta ahora): gana la parte del prestamista
--                       y, si el externo no paga, pierde el capital.
--   caja_aval_responde  del fondo de la caja; el aval gana la parte del prestamista y, si el externo
--                       no paga, lo cubre con su ahorro (lo que no alcance queda como deuda suya).
--   caja_aval_firma     del fondo de la caja; el aval solo garantiza: la parte del prestamista es de la
--                       caja y, si el externo no paga, la deuda pasa al aval como préstamo de la caja.
-- Y qué cubre el aval: solo el capital, o capital e intereses.
-- Los préstamos externos existentes quedan como "ahorro_aval" con cobertura de capital (lo que ya hacían).
-- ================================================================

ALTER TABLE ah_config
  ADD COLUMN externo_modo text NOT NULL DEFAULT 'ahorro_aval' CHECK (externo_modo IN ('ahorro_aval','caja_aval_responde','caja_aval_firma')),
  ADD COLUMN aval_cubre   text NOT NULL DEFAULT 'capital' CHECK (aval_cubre IN ('capital','capital_intereses'));
GRANT UPDATE (externo_modo, aval_cubre) ON ah_config TO pos_app;

ALTER TABLE ah_prestamos
  ADD COLUMN modo       text CHECK (modo IN ('ahorro_aval','caja_aval_responde','caja_aval_firma')),
  ADD COLUMN aval_cubre text CHECK (aval_cubre IN ('capital','capital_intereses')),
  ADD COLUMN aval_id    uuid,
  ADD COLUMN origen_id  uuid,          -- préstamo "aval": el préstamo externo cuya deuda pasó al aval
  ADD FOREIGN KEY (business_id, aval_id) REFERENCES ah_socios(business_id, id),
  ADD FOREIGN KEY (business_id, origen_id) REFERENCES ah_prestamos(business_id, id);

UPDATE ah_prestamos SET modo = 'ahorro_aval', aval_cubre = 'capital', aval_id = prestamista_id WHERE tipo = 'externo';

-- Tipo nuevo: "aval" = deuda que el socio aval asumió por un externo que no pagó (la presta el fondo).
ALTER TABLE ah_prestamos DROP CONSTRAINT ah_prestamos_tipo_check;
ALTER TABLE ah_prestamos ADD CONSTRAINT ah_prestamos_tipo_check CHECK (tipo IN ('interno','externo','aportacion','aval'));
ALTER TABLE ah_prestamos DROP CONSTRAINT ah_prestamos_check2;
ALTER TABLE ah_prestamos ADD CONSTRAINT ah_prestamos_externo_check CHECK (tipo <> 'externo' OR (
  prestatario_id IS NULL AND externo_id IS NOT NULL AND aval_id IS NOT NULL AND modo IS NOT NULL AND aval_cubre IS NOT NULL
  AND ((modo = 'ahorro_aval') = (prestamista_id IS NOT NULL)) AND (prestamista_id IS NULL OR prestamista_id = aval_id)));
ALTER TABLE ah_prestamos ADD CONSTRAINT ah_prestamos_aval_check CHECK (tipo <> 'aval' OR (
  prestamista_id IS NULL AND prestatario_id IS NOT NULL AND externo_id IS NULL AND origen_id IS NOT NULL));
CREATE UNIQUE INDEX ah_prestamos_origen_uq ON ah_prestamos (origen_id) WHERE origen_id IS NOT NULL;

-- Pago hecho por el aval con su ahorro.
ALTER TABLE ah_pagos DROP CONSTRAINT ah_pagos_metodo_check;
ALTER TABLE ah_pagos ADD CONSTRAINT ah_pagos_metodo_check CHECK (metodo IN ('efectivo','transferencia','ahorro','aval'));

-- Asiento nuevo: la deuda del externo pasa al aval.
ALTER TABLE ah_asientos DROP CONSTRAINT ah_asientos_tipo_check;
ALTER TABLE ah_asientos ADD CONSTRAINT ah_asientos_tipo_check CHECK (tipo IN (
  'aportacion_inicial','aportacion_ordinaria','aportacion_extraordinaria','aportacion_prestamo',
  'desembolso','pago','incobrable','aval_deuda','pago_gestor','egreso','reparto_fondo','devolucion','reversion'));
