-- Fase 8: la lista de ventas ordena por fecha de apertura; con historial grande
-- sin este índice recorría y ordenaba todas las ventas del negocio.
CREATE INDEX sales_opened_idx ON sales (business_id, opened_at DESC);
