-- ================================================================
-- 0025 · Avisos por WhatsApp de la caja de ahorro (D-054, docs/ahorro-avisos.md)
--
--   · ah_plantillas: texto y modo de cada aviso (sin fila = texto sugerido).
--   · ah_avisos: historial de lo que se abrió en WhatsApp o se copió. Solo agregar.
--   · ah_config: con cuántos días de anticipación se recuerda un pago o una aportación,
--     y cada cuántos días se vuelve a sugerir el aviso de un préstamo vencido.
--   · ah_socios / ah_externos: "recibe avisos por WhatsApp" (sí por omisión).
--   · Permiso nuevo ahorro.mensajes (editar las plantillas).
-- No modifica datos existentes: solo agrega columnas con valor por omisión y tablas nuevas.
-- ================================================================

INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('ahorro.mensajes', 'ahorro', 'Editar los avisos por WhatsApp para socios y externos de la caja de ahorro', false);

-- El administrador de la caja (quien autoriza) también edita sus avisos, como en la plantilla de roles.
INSERT INTO role_permissions (business_id, role_id, permission_key)
SELECT rp.business_id, rp.role_id, 'ahorro.mensajes'
  FROM role_permissions rp
 WHERE rp.permission_key = 'ahorro.autorizar'
ON CONFLICT DO NOTHING;

ALTER TABLE ah_config
  ADD COLUMN aviso_dias_antes   int NOT NULL DEFAULT 2 CHECK (aviso_dias_antes BETWEEN 0 AND 7),
  ADD COLUMN aviso_repetir_dias int NOT NULL DEFAULT 3 CHECK (aviso_repetir_dias BETWEEN 0 AND 30);  -- 0 = el aviso de vencido solo una vez
GRANT UPDATE (aviso_dias_antes, aviso_repetir_dias) ON ah_config TO pos_app;

ALTER TABLE ah_socios ADD COLUMN avisos boolean NOT NULL DEFAULT true;
GRANT UPDATE (avisos) ON ah_socios TO pos_app;
ALTER TABLE ah_externos ADD COLUMN avisos boolean NOT NULL DEFAULT true;
GRANT UPDATE (avisos) ON ah_externos TO pos_app;

CREATE TABLE ah_plantillas (
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  clave        text NOT NULL CHECK (clave IN ('prestamo_otorgado','pago_proximo','pago_vence_hoy','pago_vencido','pago_recibido','prestamo_diferido',
                                              'aportacion_proxima','aportacion_recibida','aportacion_atrasada','estado_cuenta','cierre_ciclo')),
  modo         text NOT NULL CHECK (modo IN ('ofrecer','manual','desactivado')),
  cuerpo       text NOT NULL CHECK (length(trim(cuerpo)) BETWEEN 1 AND 2000),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  updated_by   uuid REFERENCES users(id),
  PRIMARY KEY (business_id, clave)
);
SELECT app.enable_tenant_rls('ah_plantillas');
GRANT SELECT, INSERT, DELETE ON ah_plantillas TO pos_app;
GRANT UPDATE (modo, cuerpo, updated_at, updated_by) ON ah_plantillas TO pos_app;

CREATE TABLE ah_avisos (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL,
  clave        text NOT NULL CHECK (clave IN ('prestamo_otorgado','pago_proximo','pago_vence_hoy','pago_vencido','pago_recibido','prestamo_diferido',
                                              'aportacion_proxima','aportacion_recibida','aportacion_atrasada','estado_cuenta','cierre_ciclo')),
  referencia   text NOT NULL CHECK (length(referencia) BETWEEN 3 AND 200),   -- qué avisa: p. ej. pago_proximo:<préstamo>:<vencimiento>
  socio_id     uuid,
  externo_id   uuid,
  prestamo_id  uuid,
  asiento_id   uuid,
  canal        text NOT NULL CHECK (canal IN ('enlace','copiado')),
  cuerpo       text NOT NULL CHECK (length(cuerpo) BETWEEN 1 AND 4000),
  huella       text NOT NULL CHECK (huella ~ '^[0-9a-f]{64}$'),
  telefono     text CHECK (telefono IS NULL OR telefono ~ '^\+[1-9][0-9]{10,14}$'),
  reenvio      boolean NOT NULL DEFAULT false,
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (business_id, socio_id) REFERENCES ah_socios(business_id, id),
  FOREIGN KEY (business_id, externo_id) REFERENCES ah_externos(business_id, id),
  FOREIGN KEY (business_id, prestamo_id) REFERENCES ah_prestamos(business_id, id),
  FOREIGN KEY (business_id, asiento_id) REFERENCES ah_asientos(business_id, id),
  CHECK ((socio_id IS NULL) <> (externo_id IS NULL))
);
CREATE INDEX ah_avisos_referencia_idx ON ah_avisos (business_id, referencia, created_at DESC);
CREATE INDEX ah_avisos_socio_idx ON ah_avisos (business_id, socio_id, created_at DESC) WHERE socio_id IS NOT NULL;
CREATE INDEX ah_avisos_prestamo_idx ON ah_avisos (business_id, prestamo_id, created_at DESC) WHERE prestamo_id IS NOT NULL;
SELECT app.enable_tenant_rls('ah_avisos');
CREATE TRIGGER ah_avisos_no_change BEFORE UPDATE OR DELETE ON ah_avisos
  FOR EACH ROW EXECUTE FUNCTION app.forbid_change();
GRANT SELECT, INSERT ON ah_avisos TO pos_app;
