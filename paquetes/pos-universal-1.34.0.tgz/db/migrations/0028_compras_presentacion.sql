-- ================================================================
-- 0028 · Presentación pedida en cada partida de compra (D-059, docs/inventario-compras.md)
--
-- Las requisiciones (Fase 2) piden en presentaciones ("4 bolsas de 2.5 kg"). La cantidad
-- sigue guardándose en la unidad del insumo; esta columna solo recuerda la presentación
-- para el mensaje al proveedor y para recibir (Fase 3).
-- Si se borra la presentación, la partida conserva su cantidad y queda sin presentación.
-- No modifica datos existentes.
-- ================================================================

ALTER TABLE purchase_items
  ADD COLUMN presentation_id uuid,
  ADD CONSTRAINT purchase_items_presentation_fk FOREIGN KEY (business_id, presentation_id)
    REFERENCES supplier_presentations(business_id, id) ON DELETE SET NULL (presentation_id);
