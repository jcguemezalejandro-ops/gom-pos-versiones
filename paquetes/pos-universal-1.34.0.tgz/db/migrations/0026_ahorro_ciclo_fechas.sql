-- ================================================================
-- 0026 · Cambiar las fechas del ciclo abierto de la caja de ahorro (D-055)
--
--   · Permite actualizar inicio y cierre de ah_ciclos. Las reglas (solo el ciclo
--     abierto, el inicio solo sin movimientos, sin dejar fuera catorcenas ya
--     usadas) las aplica la API en PATCH /api/ahorro/ciclos/actual, con bitácora.
-- No modifica datos existentes.
-- ================================================================

GRANT UPDATE (inicio, cierre) ON ah_ciclos TO pos_app;
