-- ================================================================
-- 0024 · Aislamiento por negocio más rápido (D-052)
--
-- Mismo significado, distinta forma: las reglas de aislamiento comparan con
-- (SELECT app.current_business()), que PostgreSQL calcula UNA vez por consulta
-- (InitPlan) en lugar de una vez por fila. Con 40,000 ventas, una consulta típica
-- bajó de 82 ms a 24 ms. No cambia quién ve qué.
-- Solo se reescriben las reglas con la forma estándar; las demás quedan igual.
-- ================================================================

DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT schemaname, tablename, qual FROM pg_policies
     WHERE policyname = 'tenant_isolation'
       AND qual IN ('(business_id = app.current_business())', '(id = app.current_business())')
       AND with_check = qual
  LOOP
    IF r.qual = '(business_id = app.current_business())' THEN
      EXECUTE format('ALTER POLICY tenant_isolation ON %I.%I USING (business_id = (SELECT app.current_business())) WITH CHECK (business_id = (SELECT app.current_business()))', r.schemaname, r.tablename);
    ELSE
      EXECUTE format('ALTER POLICY tenant_isolation ON %I.%I USING (id = (SELECT app.current_business())) WITH CHECK (id = (SELECT app.current_business()))', r.schemaname, r.tablename);
    END IF;
  END LOOP;
END
$$;

-- Las tablas nuevas también usan la forma rápida.
CREATE OR REPLACE FUNCTION app.enable_tenant_rls(tbl regclass) RETURNS void
  LANGUAGE plpgsql AS
$$
BEGIN
  EXECUTE format('ALTER TABLE %s ENABLE ROW LEVEL SECURITY', tbl);
  EXECUTE format('ALTER TABLE %s FORCE ROW LEVEL SECURITY', tbl);
  EXECUTE format(
    'CREATE POLICY tenant_isolation ON %s USING (business_id = (SELECT app.current_business())) WITH CHECK (business_id = (SELECT app.current_business()))',
    tbl);
END
$$;
