-- ================================================================
-- 0019 · Directorio de clientes y direcciones de entrega (D-044)
--
-- Solo agrega: no borra columnas ni datos.
--   · customers: alias, WhatsApp, teléfono normalizado (E.164, calculado), etiquetas y fecha de cambio.
--     Un mismo teléfono no puede repetirse entre los clientes activos de un negocio.
--   · customer_addresses: varias direcciones por cliente, una predeterminada.
--     La dirección que ya existía en customers.address se copia como "Principal".
--   · sales.customer_address_id: qué dirección se usó. La copia histórica sigue en
--     sales.delivery_info, así que editar al cliente no cambia pedidos anteriores.
--   · Permiso clientes.exportar (para gerentes que ya gestionan clientes).
--   · El rol "Vendedor / mesero" deja de ver el directorio completo: para vender usa
--     la búsqueda limitada de /api/clientes/buscar (permiso ventas.crear).
-- ================================================================

-- Teléfono en formato internacional. 10 dígitos = México (+52). Acepta 52…, 521…, 044/045… y 01….
CREATE FUNCTION app.phone_e164(p text) RETURNS text
  LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$
  SELECT CASE
    WHEN d ~ '^[0-9]{10}$'           THEN '+52' || d
    WHEN d ~ '^(044|045)[0-9]{10}$'  THEN '+52' || right(d, 10)
    WHEN d ~ '^01[0-9]{10}$'         THEN '+52' || right(d, 10)
    WHEN d ~ '^521[0-9]{10}$'        THEN '+52' || right(d, 10)
    WHEN d ~ '^52[0-9]{10}$'         THEN '+' || d
    WHEN d ~ '^[1-9][0-9]{10,14}$'   THEN '+' || d
    ELSE NULL
  END
  FROM (SELECT regexp_replace(coalesce(p, ''), '[^0-9]', '', 'g') AS d) x
$$;

ALTER TABLE customers
  ADD COLUMN alias       text CHECK (alias IS NULL OR length(alias) <= 60),
  ADD COLUMN whatsapp    text CHECK (whatsapp IS NULL OR whatsapp ~ '^\+[1-9][0-9]{10,14}$'),
  ADD COLUMN phone_e164  text GENERATED ALWAYS AS (app.phone_e164(phone)) STORED,
  ADD COLUMN tags        text[] NOT NULL DEFAULT '{}' CHECK (cardinality(tags) <= 20),
  ADD COLUMN updated_at  timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX customers_phone_e164_uq ON customers (business_id, phone_e164)
  WHERE phone_e164 IS NOT NULL AND is_active;
CREATE INDEX customers_phone_e164_trgm ON customers USING gin (phone_e164 gin_trgm_ops);
CREATE INDEX customers_alias_idx ON customers USING gin (app.normalize(coalesce(alias, '')) gin_trgm_ops);
CREATE TRIGGER customers_touch BEFORE UPDATE ON customers
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
GRANT UPDATE (alias, whatsapp, tags) ON customers TO pos_app;

CREATE TABLE customer_addresses (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id      uuid NOT NULL,
  customer_id      uuid NOT NULL,
  label            text NOT NULL DEFAULT 'Casa' CHECK (length(trim(label)) BETWEEN 1 AND 40),
  street           text NOT NULL DEFAULT '' CHECK (length(street) <= 150),
  ext_number       text NOT NULL DEFAULT '' CHECK (length(ext_number) <= 20),
  int_number       text NOT NULL DEFAULT '' CHECK (length(int_number) <= 20),
  neighborhood     text NOT NULL DEFAULT '' CHECK (length(neighborhood) <= 100),
  postal_code      text NOT NULL DEFAULT '' CHECK (length(postal_code) <= 10),
  municipality     text NOT NULL DEFAULT '' CHECK (length(municipality) <= 100),
  state            text NOT NULL DEFAULT '' CHECK (length(state) <= 100),
  country          text NOT NULL DEFAULT 'México' CHECK (length(country) <= 60),
  reference_notes  text NOT NULL DEFAULT '' CHECK (length(reference_notes) <= 300),
  instructions     text NOT NULL DEFAULT '' CHECK (length(instructions) <= 300),
  maps_url         text NOT NULL DEFAULT '' CHECK (length(maps_url) <= 500),
  latitude         numeric(9,6) CHECK (latitude BETWEEN -90 AND 90),
  longitude        numeric(9,6) CHECK (longitude BETWEEN -180 AND 180),
  is_default       boolean NOT NULL DEFAULT false,
  is_active        boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id),
  FOREIGN KEY (business_id, customer_id) REFERENCES customers(business_id, id),
  CHECK ((latitude IS NULL) = (longitude IS NULL)),
  CHECK (length(street) + length(neighborhood) + length(maps_url) + length(reference_notes) > 0)
);
CREATE UNIQUE INDEX customer_addresses_default_uq ON customer_addresses (customer_id) WHERE is_default AND is_active;
CREATE INDEX customer_addresses_customer_idx ON customer_addresses (business_id, customer_id) WHERE is_active;
CREATE INDEX customer_addresses_neighborhood_idx ON customer_addresses (business_id, app.normalize(neighborhood)) WHERE is_active;
CREATE TRIGGER customer_addresses_touch BEFORE UPDATE ON customer_addresses
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
SELECT app.enable_tenant_rls('customer_addresses');
GRANT SELECT, INSERT ON customer_addresses TO pos_app;
GRANT UPDATE (label, street, ext_number, int_number, neighborhood, postal_code, municipality, state, country,
              reference_notes, instructions, maps_url, latitude, longitude, is_default, is_active) ON customer_addresses TO pos_app;

-- La dirección única que ya tenían algunos clientes pasa a ser su dirección "Principal".
INSERT INTO customer_addresses (business_id, customer_id, label, street, neighborhood, postal_code, municipality, state, country, reference_notes, is_default)
SELECT business_id, id, 'Principal',
       left(coalesce(address->>'calle', ''), 150), left(coalesce(address->>'colonia', ''), 100),
       left(coalesce(address->>'codigoPostal', ''), 10), left(coalesce(address->>'ciudad', ''), 100),
       left(coalesce(address->>'estado', ''), 100), left(coalesce(nullif(address->>'pais', ''), 'México'), 60),
       left(coalesce(address->>'referencias', ''), 300), true
  FROM customers
 WHERE length(coalesce(address->>'calle', '') || coalesce(address->>'colonia', '') || coalesce(address->>'referencias', '')) > 0;

ALTER TABLE sales ADD COLUMN customer_address_id uuid;
ALTER TABLE sales ADD FOREIGN KEY (business_id, customer_address_id) REFERENCES customer_addresses(business_id, id);

UPDATE modules SET name = 'Clientes', description = 'Directorio de clientes, direcciones de entrega, historial y crédito'
 WHERE key = 'clientes';

INSERT INTO permissions (key, module_key, description, is_sensitive) VALUES
  ('clientes.exportar', 'clientes', 'Exportar el directorio de clientes (datos personales)', true);

-- Gerentes que ya administran clientes pueden exportar.
INSERT INTO role_permissions (business_id, role_id, permission_key)
SELECT r.business_id, r.id, 'clientes.exportar'
  FROM roles r
 WHERE r.key = 'gerente'
   AND EXISTS (SELECT 1 FROM role_permissions rp WHERE rp.role_id = r.id AND rp.permission_key = 'clientes.gestionar')
ON CONFLICT DO NOTHING;

-- El mesero ya no consulta el directorio completo (teléfonos y domicilios de todos).
DELETE FROM role_permissions rp
 USING roles r
 WHERE r.id = rp.role_id AND r.key = 'vendedor' AND rp.permission_key = 'clientes.ver';
